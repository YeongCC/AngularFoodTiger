import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http: HttpClient) { }

  adminLogin(user_email: string,user_password: string){
    return this.http.post("api/apad/login",{user_email,user_password}).pipe(map((res:any)=>{
      return res;
    }))
  }

  adminLogincheckdetail(){
    return this.http.get("api/admin/coo").pipe(map((res:any)=>{
      return res;
    }))
  }

  adminlogout(){
    return this.http.post("api/apad/logout",{}).pipe(map((res:any)=>{
      return res;
    }))
  }

  postAdminData(data:any){
    return this.http.post("api/apad/create",data).pipe(map((res:any)=>{
      return res;
    }))
  }

  getAdminList(){
    return this.http.get("api/apad/admin/alladmins")
  }

  getAdminDataOne(id:string){
    return this.http.get("api/apad/admin/detail/"+id)
  }

  updateAdminDataOne(id:string,data:any){
    return this.http.patch("api/apad/"+id,data).pipe(map((res:any)=>{
      return res;
    }))
  }

  deleteSelectedUserOne(id:string){
    return this.http.delete("api/apad/delete/"+id).pipe(map((res:any)=>{
      return res;
    }))
  }

  /////////////////////////////////////////////////////////////


  getCustomerList(){
    return this.http.get("api/apus/user/allusers")
  }

  getCustomerDataOne(id:string){
    return this.http.get("api/apad/user/detail/"+id)
  }

  updateCustomerDataOne(id:string,data:any){
    return this.http.patch("api/apus/"+id,data).pipe(map((res:any)=>{
      return res;
    }))
  }

  ///////////////////////////////////////////////////////////////

  postMenuImage(formData: FormData): Observable<any> {
    return this.http.post<FormData>('api/menus/upload/google', formData, {
      reportProgress: true,
      observe: 'events'
    });
  }

  postMenuData(data:any){
    return this.http.post("api/menus",data).pipe(map((res:any)=>{
      return res;
    }))
  }

  getMenuList(){
    return this.http.get("api/menus")
  }

  getMenuDataOne(id:string){
    return this.http.get("api/menus/"+id)
  }

  updateMenuDataOne(id:string,data:any){
    return this.http.patch("api/menus/"+id,data).pipe(map((res:any)=>{
      return res;
    }))
  }

  deleteSelectedMenuOne(id:string){
    return this.http.delete("api/menus/delete/"+id).pipe(map((res:any)=>{
      return res;
    }))
  }

  deleteOldUpload(oldImage:string){
    return this.http.delete("api/menus/image/google/delete/"+oldImage)
  }
}
