export interface adminListData {
  user_name : string;
  user_email : string;
}
