export interface customerListData {
  user_name : string;
  user_account : string;
  user_address : string;
  user_credit : number;
}
