export interface menuListData {
  menu_image: string;
  menu_price: number;
  menu_name: string;
}
