import { HttpClient } from '@angular/common/http';
import { Injectable, Injector, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { ACLService } from '@delon/acl';
import { DA_SERVICE_TOKEN, ITokenService } from '@delon/auth';
import { ALAIN_I18N_TOKEN, MenuService, SettingsService, TitleService } from '@delon/theme';
import type { NzSafeAny } from 'ng-zorro-antd/core/types';
import { NzIconService } from 'ng-zorro-antd/icon';
import { Observable, zip, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { ApiService } from 'src/app/apiservice/api.service';
import { ICONS } from '../../../style-icons';
import { ICONS_AUTO } from '../../../style-icons-auto';

/**
 * Used for application startup
 * Generally used to get the basic data of the application, like: Menu Data, User Data, etc.
 */
@Injectable()
export class StartupService {
  constructor(
    iconSrv: NzIconService,
    private menuService: MenuService,
    private settingService: SettingsService,
    private aclService: ACLService,
    private titleService: TitleService,
    @Inject(DA_SERVICE_TOKEN) private tokenService: ITokenService,
    private httpClient: HttpClient,
    private injector: Injector,
    private api: ApiService
  ) {
    iconSrv.addIcon(...ICONS_AUTO, ...ICONS);
  }

  public user ={
    name: '',
    avatar: "./assets/tmp/img/tiger.png",
    email: ''
}

  private viaHttp(): Observable<void> {
    return this.httpClient.get('assets/tmp/app-data.json').pipe(
      catchError((res: NzSafeAny) => {
        console.warn(`StartupService.load: Network request failed`, res);
        return of({});
      }),
      map((res: NzSafeAny) => {
        const tokenData = this.tokenService.get();
        if(tokenData?.role=="superadmin"){
          this.menuService.add(res.superadminmenu);
          this.aclService.setRole("1")
        }else{
          this.menuService.add(res.adminmenu);
          this.aclService.setRole("2")
        }
        this.user.email = tokenData?.email;
        this.user.name  = tokenData?.name;
        // Application information: including site name, description, year
        this.settingService.setApp(res.app);
        // User information: including name, avatar, email address
        this.settingService.setUser(this.user);
        // ACL: Set the permissions to full, https://ng-alain.com/acl/getting-started
        // this.aclService.setFull(true);

        console.log(this.aclService.data)
        // Menu data, https://ng-alain.com/theme/menu

        // Can be set page suffix title, https://ng-alain.com/theme/title
        this.titleService.suffix = res.app.name;

      })
    );
  }

  // private viaMock(): Observable<void> {
  //   const tokenData = this.tokenService.get();
  //   if (!tokenData?.token) {
  //     this.injector.get(Router).navigateByUrl('/passport/login');
  //     // return;
  //   }
  //   // mock
  //   const app: any = {
  //     name: `InternFoodTiger`,
  //     description: `Food Tiger Admin Control Panel`
  //   };
  //   const user: any = {
  //     name: tokenData?.name,
  //     avatar: './assets/tmp/img/tiger.png',
  //     email: tokenData?.email,
  //     token: tokenData?.token
  //   };

  //   // Application information: including site name, description, year
  //   this.settingService.setApp(app);
  //   // User information: including name, avatar, email address
  //   this.settingService.setUser(user);
  //   // ACL: Set the permissions to full, https://ng-alain.com/acl/getting-started
  //   this.aclService.setFull(true);
  //   // Menu data, https://ng-alain.com/theme/menu
  //   this.aclService.setRole(tokenData?.role)
  //   console.log(this.aclService.setRole(tokenData?.role))
  //   if(tokenData?.role=="superadmin"){
  //     this.menuService.add([
  //       {
  //         text: 'Main',
  //         group: true,
  //         children: [
  //           {
  //             text: 'Dashboard',
  //             link: '/dashboard',
  //             icon: { type: 'icon', value: 'appstore' }
  //           },
  //           {
  //             text: 'Menu',
  //             link: '/Menu/MenuDetail',
  //             icon: { type: 'icon', value: 'file-markdown' }
  //           },
  //           {
  //             text: 'Order',
  //             link: '/',
  //             icon: { type: 'icon', value: 'shopping-cart' }
  //           },
  //           {
  //             text: 'Customer',
  //             link: '/Customer/CustomerUserDetail',
  //             icon: { type: 'icon', value: 'user' }
  //           },
  //           {
  //             text: 'Admin Employee',
  //             group: true,
  //             icon: { type: 'icon', value: 'team' },
  //             children: [
  //             {
  //             text: 'Admin',
  //             link: '/Admin/AdminUserDetail',
  //             icon: { type: 'icon', value: 'setting' }
  //             },
  //             {
  //               text: 'Deliver Man',
  //               link: '/',
  //               icon: { type: 'icon', value: 'car' }
  //             },
  //           ]
  //           },

  //         ]
  //       }
  //     ]);
  //   }else{
  //     this.menuService.add([
  //       {
  //         text: 'Main',
  //         group: true,
  //         children: [
  //           {
  //             text: 'Dashboard',
  //             link: '/dashboard',
  //             icon: { type: 'icon', value: 'appstore' }
  //           },
  //           {
  //             text: 'Menu',
  //             link: '/Menu/MenuDetail',
  //             icon: { type: 'icon', value: 'file-markdown' }
  //           },
  //           {
  //             text: 'Order',
  //             link: '/',
  //             icon: { type: 'icon', value: 'shopping-cart' }
  //           },
  //           {
  //             text: 'Customer',
  //             link: '/Customer/CustomerUserDetail',
  //             icon: { type: 'icon', value: 'user' }
  //           },
  //           {
  //             text: 'Admin Employee',
  //             group: true,
  //             icon: { type: 'icon', value: 'team' },
  //             children: [
  //             {
  //               text: 'Deliver Man',
  //               link: '/',
  //               icon: { type: 'icon', value: 'car' }
  //             },
  //           ]
  //           },

  //         ]
  //       }
  //     ]);
  //   }

  //   // Can be set page suffix title, https://ng-alain.com/theme/title
  //   this.titleService.suffix = app.name;

  //   return of();
  // }

  load(): Observable<void> {
    // http
    return this.viaHttp();
    // mock: Don’t use it in a production environment. ViaMock is just to simulate some data to make the scaffolding work normally
    // mock：请勿在生产环境中这么使用，viaMock 单纯只是为了模拟一些数据使脚手架一开始能正常运行
    // return this.viaHttp();
  }
}
