[Document](https://ng-alain.com/theme/blank)
