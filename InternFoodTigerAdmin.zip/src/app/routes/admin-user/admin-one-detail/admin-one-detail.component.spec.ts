import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { AdminUserAdminOneDetailComponent } from './admin-one-detail.component';

describe('AdminUserAdminOneDetailComponent', () => {
  let component: AdminUserAdminOneDetailComponent;
  let fixture: ComponentFixture<AdminUserAdminOneDetailComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminUserAdminOneDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminUserAdminOneDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
