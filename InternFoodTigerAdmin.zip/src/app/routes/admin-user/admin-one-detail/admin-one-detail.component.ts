import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/apiservice/api.service';
import { Router,ActivatedRoute } from '@angular/router';
import { _HttpClient } from '@delon/theme';

@Component({
  selector: 'app-admin-user-admin-one-detail',
  templateUrl: './admin-one-detail.component.html',
})
export class AdminUserAdminOneDetailComponent implements OnInit {
  public admindetail : any ;

  constructor(private router: Router,private api: ApiService,private activeroute: ActivatedRoute) {
  }

  ngOnInit(): void {
    this.api.getAdminDataOne(this.activeroute.snapshot.params.id).subscribe((res:any)=>{
      this.admindetail = res;
      this.admindetail = Array.of(this.admindetail);
    });
   }

   back(): void{
    this.router.navigateByUrl('/Admin/AdminUserDetail');
  }

}
