import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { AdminUserAdminUserCreateComponent } from './admin-user-create.component';

describe('AdminUserAdminUserCreateComponent', () => {
  let component: AdminUserAdminUserCreateComponent;
  let fixture: ComponentFixture<AdminUserAdminUserCreateComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminUserAdminUserCreateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminUserAdminUserCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
