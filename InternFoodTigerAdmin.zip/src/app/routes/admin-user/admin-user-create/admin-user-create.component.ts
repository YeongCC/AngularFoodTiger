import { HttpEventType } from '@angular/common/http';
import { Component } from '@angular/core';
import { _HttpClient } from '@delon/theme';
import { ApiService } from 'src/app/apiservice/api.service';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzMessageService } from 'ng-zorro-antd/message';

@Component({
  selector: 'app-admin-user-admin-user-create',
  templateUrl: './admin-user-create.component.html',
})
export class AdminUserAdminUserCreateComponent  {
  ngForm: FormGroup;
  public admindata = {
    user_name: '',
    user_email: '',
    user_password: '',
    role: '',
  };

  constructor(private router: Router, private api: ApiService,fb: FormBuilder, public msg: NzMessageService) {
    this.ngForm = fb.group({
      user_name: [null, [Validators.required,]],
      user_email: [null, [Validators.required]],
      user_password: [null, [Validators.required, Validators.minLength(10)]],
      role: [null, [Validators.required]],
    });
  }

  cancel(): void{
    this.router.navigateByUrl('/Admin/AdminUserDetail');
  }

  add(): void {
    console.log(this.admindata)
    this.api.postAdminData(this.admindata).subscribe(res=>{
      alert("done");
      this.router.navigateByUrl('/Admin/AdminUserDetail');
    },
    err=>{
      alert("fail");
    });
  }

}
