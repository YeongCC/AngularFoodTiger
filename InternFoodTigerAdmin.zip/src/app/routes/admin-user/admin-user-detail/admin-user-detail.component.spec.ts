import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { AdminUserAdminUserDetailComponent } from './admin-user-detail.component';

describe('AdminUserAdminUserDetailComponent', () => {
  let component: AdminUserAdminUserDetailComponent;
  let fixture: ComponentFixture<AdminUserAdminUserDetailComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminUserAdminUserDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminUserAdminUserDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
