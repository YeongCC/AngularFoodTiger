import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { AdminUserAdminUserEditComponent } from './admin-user-edit.component';

describe('AdminUserAdminUserEditComponent', () => {
  let component: AdminUserAdminUserEditComponent;
  let fixture: ComponentFixture<AdminUserAdminUserEditComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminUserAdminUserEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminUserAdminUserEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
