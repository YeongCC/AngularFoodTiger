import { HttpEventType } from '@angular/common/http';
import { Component } from '@angular/core';
import { ApiService } from 'src/app/apiservice/api.service';
import { Router,ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzMessageService } from 'ng-zorro-antd/message';
import { Location } from '@angular/common';

@Component({
  selector: 'app-admin-user-admin-user-edit',
  templateUrl: './admin-user-edit.component.html',
})
export class AdminUserAdminUserEditComponent {
  ngForm: FormGroup;
  public admindata = {
    user_name: '',
    user_password: '',
    role: '',
  };

  constructor(private router: Router,private api: ApiService,fb: FormBuilder, public msg: NzMessageService,private activeroute: ActivatedRoute,private _location: Location) {
    this.api.getAdminDataOne(this.activeroute.snapshot.params.id).subscribe((res:any)=>{
      this.admindata.user_name = res['user_name'];
      this.admindata.role = res['role'];
    });
    this.ngForm = fb.group({
      user_name: [null, [Validators.required,]],
      user_password: [null, [Validators.required, Validators.minLength(10)]],
      role: [null, [Validators.required]],
    });
  }

  update(): void {
    this.api.updateAdminDataOne(this.activeroute.snapshot.params.id,this.admindata).subscribe(res=>{
      alert("done");
      this.router.navigateByUrl('/Admin/AdminUserDetail');
    },
    err=>{
      alert("fail");
    });
  }

  cancel(): void{
    this._location.back();
  }

}
