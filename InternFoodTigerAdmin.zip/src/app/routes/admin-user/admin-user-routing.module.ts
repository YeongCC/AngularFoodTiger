import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminUserAdminUserDetailComponent } from './admin-user-detail/admin-user-detail.component';
import { AdminUserAdminUserCreateComponent } from './admin-user-create/admin-user-create.component';
import { AdminUserAdminUserEditComponent } from './admin-user-edit/admin-user-edit.component';
import { AdminUserAdminOneDetailComponent } from './admin-one-detail/admin-one-detail.component';


const routes: Routes = [
  { path: 'AdminUserDetail', component: AdminUserAdminUserDetailComponent },
  { path: 'AdminUserCreate', component: AdminUserAdminUserCreateComponent },
  { path: 'AdminUserEdit/:id', component: AdminUserAdminUserEditComponent },
  { path: 'AdminOneDetail/:id', component: AdminUserAdminOneDetailComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminUserRoutingModule { }
