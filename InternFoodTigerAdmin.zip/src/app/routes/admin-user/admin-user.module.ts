import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA, Type } from '@angular/core';
import { SharedModule } from '@shared';
import { AdminUserRoutingModule } from './admin-user-routing.module';
import { AdminUserAdminUserDetailComponent } from './admin-user-detail/admin-user-detail.component';
import { AdminUserAdminUserCreateComponent } from './admin-user-create/admin-user-create.component';
import { AdminUserAdminUserEditComponent } from './admin-user-edit/admin-user-edit.component';
import { MatProgressBarModule} from '@angular/material/progress-bar';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatTableExporterModule } from 'mat-table-exporter';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSortModule } from '@angular/material/sort';
import { MatInputModule} from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatIconModule} from '@angular/material/icon';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { AdminUserAdminOneDetailComponent } from './admin-one-detail/admin-one-detail.component';

const COMPONENTS: Type<void>[] = [
  AdminUserAdminUserDetailComponent,
  AdminUserAdminUserCreateComponent,
  AdminUserAdminUserEditComponent,
  AdminUserAdminOneDetailComponent];

@NgModule({
  imports: [
    SharedModule,
    AdminUserRoutingModule,
    MatProgressBarModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatTableExporterModule,
    MatButtonModule,
    NzIconModule
  ],
  declarations: COMPONENTS,
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ]
})
export class AdminUserModule { }
