import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { CustomerUserCustomerOneDetaillComponent } from './customer-one-detaill.component';

describe('CustomerUserCustomerOneDetaillComponent', () => {
  let component: CustomerUserCustomerOneDetaillComponent;
  let fixture: ComponentFixture<CustomerUserCustomerOneDetaillComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerUserCustomerOneDetaillComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerUserCustomerOneDetaillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
