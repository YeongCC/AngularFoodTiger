import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/apiservice/api.service';
import { Router,ActivatedRoute } from '@angular/router';
import { _HttpClient } from '@delon/theme';

@Component({
  selector: 'app-customer-user-customer-one-detaill',
  templateUrl: './customer-one-detaill.component.html',
})
export class CustomerUserCustomerOneDetaillComponent implements OnInit {
  public cusdetail : any ;

  constructor(private router: Router,private api: ApiService,private activeroute: ActivatedRoute) {
  }

  ngOnInit(): void {
    this.api.getCustomerDataOne(this.activeroute.snapshot.params.id).subscribe((res:any)=>{
      this.cusdetail = res;
      this.cusdetail = Array.of(this.cusdetail);
    });
  }

  back(): void {
    this.router.navigateByUrl('/Customer/CustomerUserDetail');
  }

}
