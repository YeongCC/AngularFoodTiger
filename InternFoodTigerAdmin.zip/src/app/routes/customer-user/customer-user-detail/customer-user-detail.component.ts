import { Component,ViewChild,AfterViewInit } from '@angular/core';
import { _HttpClient } from '@delon/theme';
import { ApiService } from 'src/app/apiservice/api.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { customerListData } from 'src/app/apiservice/class/customerclass';

@Component({
  selector: 'app-customer-user-customer-user-detail',
  templateUrl: './customer-user-detail.component.html',
  styleUrls: ['./customer-user-detail.component.css'],
})
export class CustomerUserCustomerUserDetailComponent implements AfterViewInit  {

  displayedColumns: string[] = ['position','user_name','user_account','actions'];
  dataSource = new MatTableDataSource<customerListData>();

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private api : ApiService) {
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort=this.sort;
    this.getALLCustomerdata();
  }

 getALLCustomerdata(){
  let resp = this.api.getCustomerList();
  resp.subscribe(report=>this.dataSource.data=report  as customerListData[])
}


  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  deleteCustomer(id:string){
    this.api.deleteSelectedUserOne(id).subscribe(res=>{
      alert("done");
      this.getALLCustomerdata();
    },
    err=>{
      alert("fail");
    });
  }

}
