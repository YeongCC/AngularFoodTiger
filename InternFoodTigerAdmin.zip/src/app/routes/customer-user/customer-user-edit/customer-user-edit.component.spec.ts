import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { CustomerUserCustomerUserEditComponent } from './customer-user-edit.component';

describe('CustomerUserCustomerUserEditComponent', () => {
  let component: CustomerUserCustomerUserEditComponent;
  let fixture: ComponentFixture<CustomerUserCustomerUserEditComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerUserCustomerUserEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerUserCustomerUserEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
