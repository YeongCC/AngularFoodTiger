import { Component, OnInit, ViewChild } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { _HttpClient } from '@delon/theme';
import { Location } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from 'src/app/apiservice/api.service';
@Component({
  selector: 'app-customer-user-customer-user-edit',
  templateUrl: './customer-user-edit.component.html',
})
export class CustomerUserCustomerUserEditComponent implements OnInit {
  ngForm: FormGroup;
  public customerdata = {
    user_name: '',
    user_address: '',
    user_credit: '',
  };

  constructor(private activeroute: ActivatedRoute,private _location: Location,private api: ApiService,fb: FormBuilder) {
    this.api.getCustomerDataOne(this.activeroute.snapshot.params.id).subscribe((res:any)=>{
      this.customerdata.user_name = res['user_name'];
      this.customerdata.user_address = res['user_address'];
      this.customerdata.user_credit = res['user_credit'];
    });
    this.ngForm = fb.group({
      user_name: [null, [Validators.required,]],
      user_address: [null, [Validators.required]],
      user_credit: [null, [Validators.required]],
    });
  }

  ngOnInit(): void { }

  cancel(): void {
    this._location.back();
  }

  update(): void {
      this.api.updateCustomerDataOne(this.activeroute.snapshot.params.id,this.customerdata).subscribe(res=>{
        alert("done");
        this._location.back();
      },
      err=>{
        alert("fail");
      });
    }

}
