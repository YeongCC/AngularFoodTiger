import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomerUserCustomerUserDetailComponent } from './customer-user-detail/customer-user-detail.component';
import { CustomerUserCustomerUserEditComponent } from './customer-user-edit/customer-user-edit.component';
import { CustomerUserCustomerOneDetaillComponent } from './customer-one-detaill/customer-one-detaill.component';

const routes: Routes = [

  { path: 'CustomerUserDetail', component: CustomerUserCustomerUserDetailComponent },
  { path: 'CustomerOneDetaill/:id', component: CustomerUserCustomerOneDetaillComponent },
  { path: 'CustomerUserEdit/:id', component: CustomerUserCustomerUserEditComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CustomerUserRoutingModule { }
