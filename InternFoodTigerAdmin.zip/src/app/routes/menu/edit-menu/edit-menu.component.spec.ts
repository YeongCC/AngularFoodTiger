import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { MenuEditMenuComponent } from './edit-menu.component';

describe('MenuEditMenuComponent', () => {
  let component: MenuEditMenuComponent;
  let fixture: ComponentFixture<MenuEditMenuComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MenuEditMenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuEditMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
