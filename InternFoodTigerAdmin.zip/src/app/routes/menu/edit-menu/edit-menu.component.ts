import { HttpEventType } from '@angular/common/http';
import { Component } from '@angular/core';
import { ApiService } from 'src/app/apiservice/api.service';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzMessageService } from 'ng-zorro-antd/message';

@Component({
  selector: 'app-menu-edit-menu',
  templateUrl: './edit-menu.component.html',
  styleUrls: ['./edit-menu.component.css'],
})
export class MenuEditMenuComponent  {
  ngForm: FormGroup;
  public menudata = {
    menu_name: '',
    menu_detail: '',
    menu_price: '',
    menu_image_path: '',
    menu_image: '',
    menu_image_input:''
  };
  url='';
  timeElapsed = Date.now();
  today = new Date(this.timeElapsed);
  stringdate =this.today.toDateString();
  imagepath : any;
  progress : number | any;
  file : File;
  oldfile : string;

  constructor(private _location: Location,private api: ApiService,fb: FormBuilder, public msg: NzMessageService,private activeroute: ActivatedRoute) {
    this.api.getMenuDataOne(this.activeroute.snapshot.params.id).subscribe((res:any)=>{
      this.menudata.menu_name = res['menu_name'];
      this.menudata.menu_detail = res['menu_detail'];
      this.menudata.menu_price = res['menu_price'];
      this.menudata.menu_image_path = res['menu_image_path'];
      this.menudata.menu_image = res['menu_image'];
      this.url = res['menu_image_path'];
      this.oldfile = res['menu_image'];
    });
    this.ngForm = fb.group({
      menu_name: [null, [Validators.required,]],
      menu_detail: [null, [Validators.required,]],
      menu_price: [null, [Validators.required]],
      menu_image: [null, [Validators.required]],
    });
  }

  onselectFile(event:any){
    var reader = new FileReader();
    this.file =  event.target.files[0];
    const allowedMimeTypes = ["image/png","image/jpeg","image/jpg"];
      if(this.file&&allowedMimeTypes.includes(this.file.type)){
        var reader = new FileReader();
        reader.onload=()=>{
          this.url=reader.result as string;
        }
        reader.readAsDataURL(this.file)
        this.menudata.menu_image_path="https://storage.googleapis.com/internfoodtigerimage/"+this.file.name;
        this.menudata.menu_image=this.file.name;
      }
      else{
        this.url="./assets/tmp/img/unknown.png"
        event.target.value = null;
        alert('Wrong format!');
      }
  }

  update(): void {
    if(this.menudata.menu_image==this.oldfile){
      this.api.updateMenuDataOne(this.activeroute.snapshot.params.id,this.menudata).subscribe(res=>{
        alert("done");
        this._location.back();
      },
      err=>{
        alert("fail");
      });
    }else{
      this.uploadUpdateUploadImage();
      this.deleteUploadfile(this.oldfile);
      this.api.updateMenuDataOne(this.activeroute.snapshot.params.id,this.menudata).subscribe(res=>{
        alert("done");
        this._location.back();
      },
      err=>{
        alert("fail");
      });
    }
  }

  cancel(): void{
    this._location.back();
  }

  deleteUploadfile(menu_image: string){
    this.api.deleteOldUpload(menu_image).subscribe(res=>{
      console.log('done')
     },
     err=>{
       console.log('fail');
     });
  }

  uploadUpdateUploadImage(){
    const formData = new FormData();
    formData.append('file', this.file);
    this.api.postMenuImage(formData).subscribe(res=>{
      switch (res.type) {
        case HttpEventType.UploadProgress:
          this.progress = Math.round(res.loaded * 100 / res.total);
          break;
        case HttpEventType.Response:
          return res;
      }
    },
    err=>{
      alert("fail");
    });
  }

}
