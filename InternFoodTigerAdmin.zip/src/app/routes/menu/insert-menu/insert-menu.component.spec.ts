import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuInsertMenuComponent } from './insert-menu.component';

describe('MenuInsertMenuComponent', () => {
  let component: MenuInsertMenuComponent;
  let fixture: ComponentFixture<MenuInsertMenuComponent>;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [MenuInsertMenuComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuInsertMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
