import { HttpEventType } from '@angular/common/http';
import { Component } from '@angular/core';
import { _HttpClient } from '@delon/theme';
import { ApiService } from 'src/app/apiservice/api.service';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzMessageService } from 'ng-zorro-antd/message';


@Component({
  selector: 'app-menu-insert-menu',
  templateUrl: './insert-menu.component.html',
  styleUrls: ['./insert-menu.component.css'],
})
export class MenuInsertMenuComponent {
  ngForm: FormGroup;
  public menudata = {
    menu_name: '',
    menu_detail: '',
    menu_price: '',
    menu_image_path: '',
    menu_image: '',
    menu_image_input: '',
  };

  constructor(private router: Router, private api: ApiService,fb: FormBuilder, public msg: NzMessageService) {
    this.ngForm = fb.group({
      menu_name: [null, [Validators.required,]],
      menu_detail: [null, [Validators.required,]],
      menu_price: [null, [Validators.required]],
      menu_image: [null, [Validators.required]],
    });
  }


  url="./assets/tmp/img/unknown.png"
  timeElapsed = Date.now();
  today = new Date(this.timeElapsed);
  stringdate =this.today.toDateString();
  imagepath: any;
  progress :number | any;
  file:File;

  onselectFile(event:any){
    var reader = new FileReader();
    this.file =  event.target.files[0];
    const allowedMimeTypes = ["image/png","image/jpeg","image/jpg"];

      if(this.file&&allowedMimeTypes.includes(this.file.type)){
        var reader = new FileReader();
        reader.onload=()=>{
          this.url=reader.result as string;
        }
        reader.readAsDataURL(this.file)
        this.menudata.menu_image_path="https://storage.googleapis.com/internfoodtigerimage/"+this.file.name;
        this.menudata.menu_image=this.file.name;
      }
      else{
        this.url="./assets/tmp/img/unknown.png"
        event.target.value = null;
        alert('Wrong format!');
      }
  }


  add(): void {
      this.uploadMenuImage();
      this.api.postMenuData(this.menudata).subscribe(res=>{
        alert("done");
        this.router.navigateByUrl('/Menu/MenuDetail');
      },
      err=>{
        alert("fail");
      });
  }

  cancel(): void{
    this.router.navigateByUrl('/Menu/MenuDetail');
  }

  uploadMenuImage(){
    const formData = new FormData();
    formData.append('file', this.file);
    this.api.postMenuImage(formData).subscribe(res=>{
      switch (res.type) {
        case HttpEventType.UploadProgress:
          this.progress = Math.round(res.loaded * 100 / res.total);
          break;
        case HttpEventType.Response:
          return res;
      }
    },
    err=>{
      alert("fail");
    });
  }

}
