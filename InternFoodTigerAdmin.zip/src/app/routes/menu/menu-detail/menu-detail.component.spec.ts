import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuMenuDetailComponent } from './menu-detail.component';

describe('MenuMenuDetailComponent', () => {
  let component: MenuMenuDetailComponent;
  let fixture: ComponentFixture<MenuMenuDetailComponent>;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [MenuMenuDetailComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuMenuDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
