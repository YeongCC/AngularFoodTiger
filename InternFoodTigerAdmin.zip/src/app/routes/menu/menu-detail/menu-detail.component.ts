import { Component,ViewChild,AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { _HttpClient } from '@delon/theme';
import { ApiService } from 'src/app/apiservice/api.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { menuListData } from 'src/app/apiservice/class/menuclass';

@Component({
  selector: 'app-menu-menu-detail',
  templateUrl: './menu-detail.component.html',
  styleUrls: ['./menu-detail.component.css'],
})
export class MenuMenuDetailComponent implements AfterViewInit  {

  displayedColumns: string[] = ['menu_image','menu_name','menu_price','actions'];
  dataSource = new MatTableDataSource<menuListData>();

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private router: Router,private api : ApiService) {
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort=this.sort;
    this.getALLMenudata();
  }

 getALLMenudata(){
  let resp = this.api.getMenuList();
  resp.subscribe(report=>this.dataSource.data=report  as menuListData[])
}

  add(): void {
    this.router.navigateByUrl('/Menu/insertMenu');
  }


  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  deleteMenu(id:string, menu_image: string){
    this.api.deleteSelectedMenuOne(id).subscribe(res=>{
      alert("done");
      this.getALLMenudata();
      this.deleteUploadfile(menu_image);
    },
    err=>{
      alert("fail");
    });
  }

  deleteUploadfile(menu_image: string){
    this.api.deleteOldUpload(menu_image).subscribe(res=>{
      console.log('done')
     },
     err=>{
       console.log('fail');
     });
  }

}


