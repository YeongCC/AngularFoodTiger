import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { MenuMenuOneDetailComponent } from './menu-one-detail.component';

describe('MenuMenuOneDetailComponent', () => {
  let component: MenuMenuOneDetailComponent;
  let fixture: ComponentFixture<MenuMenuOneDetailComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MenuMenuOneDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuMenuOneDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
