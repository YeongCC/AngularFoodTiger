import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/apiservice/api.service';
import { Router,ActivatedRoute } from '@angular/router';
import { _HttpClient } from '@delon/theme';

@Component({
  selector: 'app-menu-menu-one-detail',
  templateUrl: './menu-one-detail.component.html',
})
export class MenuMenuOneDetailComponent implements OnInit {

  constructor(private router: Router,private api: ApiService,private activeroute: ActivatedRoute) {
  }
  public menudetail : any ;

  ngOnInit(): void {
    this.api.getMenuDataOne(this.activeroute.snapshot.params.id).subscribe((res:any)=>{
      this.menudetail = res;
      this.menudetail = Array.of( this.menudetail);
    });

  }



  back(): void {
    this.router.navigateByUrl('/Menu/MenuDetail');
  }

}
