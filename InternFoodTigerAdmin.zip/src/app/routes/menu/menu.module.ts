import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA , Type } from '@angular/core';
import { SharedModule } from '@shared';

import { MenuInsertMenuComponent } from './insert-menu/insert-menu.component';
import { MenuMenuDetailComponent } from './menu-detail/menu-detail.component';
import { MenuRoutingModule } from './menu-routing.module';
import { MatProgressBarModule} from '@angular/material/progress-bar';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatTableExporterModule } from 'mat-table-exporter';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSortModule } from '@angular/material/sort';
import { MatInputModule} from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatIconModule} from '@angular/material/icon';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { MenuEditMenuComponent } from './edit-menu/edit-menu.component';
import { MenuMenuOneDetailComponent } from './menu-one-detail/menu-one-detail.component';
import { MatDialogModule } from '@angular/material/dialog';

const COMPONENTS: Array<Type<void>> = [MenuInsertMenuComponent, MenuMenuDetailComponent,
  MenuEditMenuComponent,
  MenuMenuOneDetailComponent];

@NgModule({
  imports: [
    SharedModule,
    MenuRoutingModule,
    MatProgressBarModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatTableExporterModule,
    MatButtonModule,
    MatDialogModule,
    NzIconModule],
  declarations: COMPONENTS,
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ]
})
export class MenuModule {}
