import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Inject, OnDestroy, Optional } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StartupService } from '@core';
import { ReuseTabService } from '@delon/abc/reuse-tab';
import { DA_SERVICE_TOKEN, ITokenService, SocialOpenType, SocialService } from '@delon/auth';
import { SettingsService, _HttpClient } from '@delon/theme';
import { environment } from '@env/environment';
import { NzTabChangeEvent } from 'ng-zorro-antd/tabs';
import { finalize } from 'rxjs/operators';
import { ApiService } from 'src/app/apiservice/api.service';

@Component({
  selector: 'passport-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.less'],
  providers: [SocialService],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UserLoginComponent implements OnDestroy {
  constructor(
    fb: FormBuilder,
    private router: Router,
    private settingsService: SettingsService,
    private socialService: SocialService,
    @Optional()
    @Inject(ReuseTabService)
    private reuseTabService: ReuseTabService,
    @Inject(DA_SERVICE_TOKEN) private tokenService: ITokenService,
    private startupSrv: StartupService,
    private http: _HttpClient,
    private cdr: ChangeDetectorRef,
    private api: ApiService
  ) {
    this.form = fb.group({
      user_email: [null, [Validators.required]],
      user_password: [null, [Validators.required]],
      remember: [true]
    });
  }

  // #region fields

  get user_email(): AbstractControl {
    return this.form.controls.user_email;
  }
  get user_password(): AbstractControl {
    return this.form.controls.user_password;
  }

  form: FormGroup;
  error = '';
  type = 0;
  loading = false;

  // #region get captcha

  count = 0;
  interval$: any;

  // #endregion

  switch({ index }: NzTabChangeEvent): void {
    this.type = index!;
  }

  // #endregion

  submit(): void {
    this.error = '';
    if (this.type === 0) {
      this.user_email.markAsDirty();
      this.user_email.updateValueAndValidity();
      this.user_password.markAsDirty();
      this.user_password.updateValueAndValidity();
      if (this.user_email.invalid || this.user_password.invalid) {
        return;
      }
    }

    this.api.adminLogin(this.user_email.value,this.user_password.value).subscribe(res=>{
      this.tokenService.set(res.user);
      this.cdr.detectChanges();
      res.user.expired = +new Date() + 1000 * 60 * 5;
      // setTimeout(()=>{
      //   window.location.reload();
      // }, 10);
      this.tokenService.get();
      // this.router.navigateByUrl('/');
      this.startupSrv.load().subscribe(() => {
        let url = this.tokenService.referrer!.url || '/';
        if (url.includes('/passport')) {
          url = '/';
        }
        this.router.navigateByUrl(url);

      });
    },
    err=>{
      this.error = err.error.message;
      this.cdr.detectChanges();
    }
    )

  }

  // #endregion

  ngOnDestroy(): void {
    if (this.interval$) {
      clearInterval(this.interval$);
    }
  }
}
