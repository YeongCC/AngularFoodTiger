import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  constructor(private http: HttpClient) { }

  getMenuList() {
    return this.http.get('/menus/customer/allmenu');
  }

  Veify(data: any) {
    return this.http.post('/apus/verify', data).pipe(
      map((res: any) => {
        return res;
      })
    );
  }

  SignIn(data: any) {
    return this.http.post('/apus/SignIn', data).pipe(
      map((res: any) => {
        return res;
      })
    );
  }

  SessionLogout() {
    return this.http.post('/apus/sessionLogout', {}).pipe(
      map((res: any) => {
        return res;
      })
    );
  }

  CreateNewUser(data: any) {
    return this.http.post('/apus/identity', data).pipe(
      map((res: any) => {
        return res;
      })
    );
  }

  CreateNewUserWallet(data: any) {
    return this.http.post('/wallet/new', data).pipe(
      map((res: any) => {
        return res;
      })
    );
  }

  UpdateUser(data: any) {
    return this.http.patch('/apus/identity/update', data).pipe(
      map((res: any) => {
        return res;
      })
    );
  }

  UserDetail(idToken: any, user_account: any) {
    return this.http.get('/apus/detail/' + user_account + "/" + idToken);
  }

  WalletDetail(idToken: any, user_account: any) {
    return this.http.get('/wallet/detail/' + user_account + "/" + idToken);
  }

  CreateOrderData(data: any) {
    return this.http.post('/orders/createOrder', data).pipe(
      map((res: any) => {
        return res;
      })
    );
  }

  getUserOrderDetail(user_account: any) {
    return this.http.get('/orders/detail/' + user_account);
  }

  getUserOneOrderDetail(user_account: any, orderId: any) {
    return this.http.get('/orders/detailOne/' + user_account + '/' + orderId);
  }

  paymentGateway(data: any) {
    return this.http.post('/payment-gateway/check', data).pipe(
      map((res: any) => {
        return res;
      })
    );
  }

  getPaymentResultReceipt(user_account: any) {
    return this.http.get('/wallet/result/' + user_account);
  }

  updateWalletDetail(user_account: any) {
    return this.http.get('/wallet/update/' + user_account);
  }

  getWalletProcessHistory(user_account: any) {
    return this.http.get('/wallet/user/history/' + user_account);
  }

  getWalletOneProcessHistory(user_account: any,process_wallet_id:any) {
    return this.http.get('/wallet/user/onehistory/' + user_account+"/"+process_wallet_id);
  }
}
