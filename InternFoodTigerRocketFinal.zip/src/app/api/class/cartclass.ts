import { Menu } from './menuclass';

export class CartItem {
  menuId: string;
  menu_name: string;
  menu_detail: string;
  menu_price: number;
  menu_image_path: string;
  menu_image: string;
  qty: number;

  constructor(menu: Menu) {
    this.menuId = menu.menuId;
    this.menu_detail = menu.menu_detail;
    this.menu_name = menu.menu_name;
    this.menu_price = menu.menu_price;
    this.menu_image_path = menu.menu_image_path;
    this.menu_image = menu.menu_image;
    this.qty = 1;
  }
}
