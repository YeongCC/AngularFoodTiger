export class Menu {
  menuId!: string;
  menu_name!: string;
  menu_detail!: string;
  menu_price!: number;
  menu_image_path!: string;
  menu_image!: string;
}
