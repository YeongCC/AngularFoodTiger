import { Injectable } from '@angular/core';

export interface Credentials {
  // Customize received credentials here
  user_account: string;
  user_phone:string;
  user_country_code:string;
  user_country_name:string;
  user_country_currency:string;
  token: string;
}

export interface UserDetailCredentials {
  // Customize received credentials here
  userId: string;
  user_account: string;
  user_phone: string;
  user_email: string;
  user_name: string;
  user_address: string;
}

const credentialsKey = 'credentials';
const credentialsUserKey = 'credentialsUser';
/**
 * Provides storage for authentication credentials.
 * The Credentials interface should be replaced with proper implementation.
 */
@Injectable({
  providedIn: 'root',
})
export class CredentialsService {
  private _credentials: Credentials | null = null;
  private _userdetailcredentials: UserDetailCredentials | null = null;

  constructor() {
    const savedCredentials = sessionStorage.getItem(credentialsKey) || localStorage.getItem(credentialsKey);
    if (savedCredentials) {
      this._credentials = JSON.parse(savedCredentials);
    }
    const savedUserCredentials = sessionStorage.getItem(credentialsUserKey) || localStorage.getItem(credentialsUserKey);
    if (savedUserCredentials) {
      this._userdetailcredentials = JSON.parse(savedUserCredentials);
    }
  }

  /**
   * Checks is the user is authenticated.
   * @return True if the user is authenticated.
   */
  isAuthenticated(): boolean {
    return !!this.credentials;
  }

  isUserAuthenticated(): boolean {
    return !!this.userdetailCredentials;
  }
  /**
   * Gets the user credentials.
   * @return The user credentials or null if the user is not authenticated.
   */
  get credentials(): Credentials | null {
    return this._credentials;
  }

  get userdetailCredentials(): UserDetailCredentials | null {
    return this._userdetailcredentials;
  }
  /**
   * Sets the user credentials.
   * The credentials may be persisted across sessions by setting the `remember` parameter to true.
   * Otherwise, the credentials are only persisted for the current session.
   * @param credentials The user credentials.
   * @param remember True to remember credentials across sessions.
   */
  setCredentials(credentials?: Credentials) {
    this._credentials = credentials || null;

    if (credentials) {
      const storage = localStorage;
      storage.setItem(credentialsKey, JSON.stringify(credentials));
    } else {
      sessionStorage.removeItem(credentialsKey);
      localStorage.removeItem(credentialsKey);
    }
  }

  setUserDetailCredentials(userdetailcredentials?: UserDetailCredentials) {
    this._userdetailcredentials = userdetailcredentials || null;

    if (userdetailcredentials) {
      const storage = localStorage;
      storage.setItem(credentialsUserKey, JSON.stringify(userdetailcredentials));
    } else {
      sessionStorage.removeItem(credentialsUserKey);
      localStorage.removeItem(credentialsUserKey);
    }
  }
}
