import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

export interface Credentials {
  account:string;
}

const credentialsKey = 'phonecredentials';

@Injectable({
  providedIn: 'root'
})
export class PhonecredentialService {
  private _credentials: Credentials | null = null;
  public account : any;
  public number : any;
  public code : any;
  public name : any;
  public currency : any;
  constructor() {
    const savedCredentials = sessionStorage.getItem(credentialsKey) || localStorage.getItem(credentialsKey);
    if (savedCredentials) {
      this._credentials = JSON.parse(savedCredentials);
    }
  }

  isPhoneAuthenticated(): boolean {
    return !!this.credentials;
  }

  takephone(account:any,number:any,code:any,name:any,currency:any){
    this.account = account
    this.number = number
    this.code = code
    this.name = name
    this.currency = currency
  }

  /**
   * Gets the user credentials.
   * @return The user credentials or null if the user is not authenticated.
   */
  get credentials(): Credentials | null {
    return this._credentials;
  }

  setPhoneCredentials(credentials?: Credentials) {
    this._credentials = credentials || null;
    if (credentials) {
      const storage = localStorage;
      storage.setItem(credentialsKey, JSON.stringify(credentials));
    } else {
      sessionStorage.removeItem(credentialsKey);
      localStorage.removeItem(credentialsKey);
    }
  }

  clearCredentials(): Observable<boolean>{
    this.setPhoneCredentials();
    return of(true);
  }
}
