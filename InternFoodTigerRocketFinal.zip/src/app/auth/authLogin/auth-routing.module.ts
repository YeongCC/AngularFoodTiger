import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { marker } from '@biesbjerg/ngx-translate-extract-marker';
import { DatacheckGuard } from './Guard/datacheck.guard';
import { LoginauthGuard } from './Guard/loginauth.guard';
import { LoginComponent } from './login/login.component';
import { OtpComponent } from './otp/otp.component';



const routes: Routes = [
  { path: 'login', component: LoginComponent, data: { title: marker('Login') } ,canActivate: [LoginauthGuard]},
  { path: 'verify', component: OtpComponent, data: { title: marker('Login') } ,canActivate: [DatacheckGuard]},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class AuthRoutingModule {}
