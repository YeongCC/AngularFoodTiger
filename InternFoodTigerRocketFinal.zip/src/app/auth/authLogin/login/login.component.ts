import { Component, NgZone, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Platform } from '@ionic/angular';
import firebase from 'firebase/app';
import 'firebase/auth';
import 'firebase/firestore';
import { environment } from '@env/environment';
import { UntilDestroy } from '@shared';
import { ApiService } from '@app/api/api.service';
import { PhonecredentialService } from '../Service/phonecredential.service';

var config = {
  apiKey: 'AIzaSyCH3MNvYDt0hxg4f3oJw6V7FvJJiwLWD7g',
  authDomain: 'internfoodtiger.firebaseapp.com',
  projectId: 'internfoodtiger',
  storageBucket: 'internfoodtiger.appspot.com',
  messagingSenderId: '124052662798',
  appId: '1:124052662798:web:506887b543523ff3f4aa5f',
};

@UntilDestroy()
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  version: string | null = environment.version;
  error: string | undefined;
  phoneForm!: FormGroup;
  isLoading = false;
  reCaptchaVerifier: any;
  private country = {
    code:"",
    name:"",
    currency:"",
  }
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private platform: Platform,
    private api: ApiService,
    private ngZone: NgZone,
    private phonecredntialsService: PhonecredentialService
  ) {
    this.createForm();
  }

  ngOnInit() {
    firebase.initializeApp(config);
  }

  async login() {
    this.error = '';   
    this.checkPrefix(this.phoneForm.value.prefix)
    var data ={
      prefix: this.phoneForm.value.prefix,
      number: this.phoneForm.value.number,
      code: this.country.code,
      name: this.country.name,
      currency: this.country.currency
    }
    this.api.Veify(data).subscribe(
      (res) => {
        if(res.res==false){
          this.error ='the input value is not a valid mobile number of the country'
        }else{
          this.firebaseCheck(res.account)
          this.phonecredntialsService.takephone(res.account,res.number,res.code,res.name,res.currency)
          this.router.navigate(['verify']);
        }
      }
    );
  }

  get isWeb(): boolean {
    return !this.platform.is('cordova');
  }

  private createForm() {
    this.phoneForm = this.formBuilder.group({
      prefix: '+60',
      number: ['', Validators.required],
    });
  }

  checkPrefix(prefix:any){
    if(prefix=="+60"){
      this.country.code = "MY"
      this.country.currency = "MYR"
      this.country.name = "Malaysia"
    }else if(prefix=="+70"){
      this.country.code = "SG"
      this.country.currency = "$"
      this.country.name = "Singapore"
    }
  }

  keyPress(event: any) {
    this.error = ''; 
  }

  firebaseCheck(number:any){
    this.reCaptchaVerifier = new firebase.auth.RecaptchaVerifier('sign-in-button', {
      size: 'invisible',
    });

    firebase
          .auth()
          .signInWithPhoneNumber(number, this.reCaptchaVerifier)
          .then((confirmationResult) => {
            localStorage.setItem('verificationId', JSON.stringify(confirmationResult.verificationId));
            this.phonecredntialsService.setPhoneCredentials(number);
            this.ngZone.run(() => {
              this.router.navigate(['verify']);
            });
           
          })
          .catch((error) => {
            this.error = error.message; 
            setTimeout(() => {
              window.location.reload();
            }, 5000);
          });
  }
}
