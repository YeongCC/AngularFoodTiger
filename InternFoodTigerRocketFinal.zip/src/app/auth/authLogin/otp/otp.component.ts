import { Component, NgZone, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { environment } from '@env/environment';
import { Platform } from '@ionic/angular';
import { PhonecredentialService } from '../Service/phonecredential.service';
import firebase from 'firebase/app';
import 'firebase/auth';
import 'firebase/firestore';
import { pathOr } from 'ramda';
import { ApiService } from '@app/api/api.service';
import { Router } from '@angular/router';
import { CredentialsService } from '../Service/credentials.service';
import { WalletService } from '@app/components/Service/wallet.service';

@Component({
  selector: 'app-otp',
  templateUrl: './otp.component.html',
  styleUrls: ['./otp.component.scss']
})
export class OtpComponent implements OnInit {
  version: string | null = environment.version;
  error: string | undefined;
  otpForm!: FormGroup;
  number : any;
  verify: any;
  data = {
    idToken: 'sdsd',
    type: 'idtoken'
  };

  constructor(
    private api: ApiService,
    private platform: Platform,
    private formBuilder: FormBuilder,
    private router: Router,
    private ngZone: NgZone,
    private phonecredntialsService: PhonecredentialService,
    private credentialsService: CredentialsService,
    private walletService:WalletService
  ) { 
    this.createForm();
  }

  ngOnInit(): void {
    this.number = this.phonecredntialsService.account
    this.verify = JSON.parse(localStorage.getItem('verificationId') || '{}');
  }
  get isWeb(): boolean {
    return !this.platform.is('cordova');
  }

  keyPress(event: any) {
    this.error = ''; 
  }
  
  async otp() {
    this.error = '';    
    this.otpcheck(this.verify,this.otpForm.value.otp)
  }

  private createForm() {
    this.otpForm = this.formBuilder.group({
      otp: ['', Validators.required],
    });
  }

  async otpcheck(verify:any,otp:any){
    var credential = firebase.auth.PhoneAuthProvider.credential(verify, otp);

    const result = await firebase.auth().signInWithCredential(credential).catch((error) => {
      this.error = "Error : "+error.message;
    });;
    const user = pathOr(false, ['user'], result) as firebase.User | false;
    if (user !== false) {
      const idToken = await user.getIdToken();
      localStorage.setItem('firebaseIdToken', idToken);
      this.data.idToken =idToken
      this.signin(this.data)
    }
  }

  signin(idtoken:any){
    this.api.SignIn(idtoken).subscribe(
      (res) => {
        const user = {
          user_account: this.phonecredntialsService.account,
          user_phone: this.phonecredntialsService.number,
          user_country_code:this.phonecredntialsService.code,
          user_country_name: this.phonecredntialsService.name,
          user_country_currency: this.phonecredntialsService.currency,
          token: res.user.token
        };
        this.credentialsService.setCredentials(user);
        this.phonecredntialsService.clearCredentials().subscribe(() => this.router.navigate(['/login'], { replaceUrl: true }));;
        this.getUserDetail()
        this.getWalletDetal()
        this.ngZone.run(() => {
          this.router.navigate(['/home']);
        });
      },(err) => {
        this.error = err.error;
      }
    );
  }

  getUserDetail(){
        this.api.UserDetail(this.credentialsService.credentials?.token,this.credentialsService.credentials?.user_account).subscribe((res: any) => {
          if(res){
            this.credentialsService.setUserDetailCredentials(res.user)
          }
        });
  }

  getWalletDetal(){
    this.api.WalletDetail(this.credentialsService.credentials?.token,this.credentialsService.credentials?.user_account).subscribe((res: any) => {
      if(res){
        this.walletService.setWallets(res.wallet)
      }
    });
  }

}
