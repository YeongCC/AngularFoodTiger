import { Routes, Route } from '@angular/router';
import { AuthenticationGuard } from '@app/auth/authLogin/Guard/authentication.guard';
import { AuthheaderComponent } from '../authheader/authheader.component';


export class AuthproService {
  /**
   * Creates routes using the shell component and authentication.
   * @param routes The routes to add.
   * @return The new route using shell as the base.
   */
  static childRoutes(routes: Routes): Route {
    return {
      path: 'chyk/identity',
      component: AuthheaderComponent,
      children: routes,
      canActivate: [AuthenticationGuard],
    };
  }
}
