import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-authheader',
  templateUrl: './authheader.component.html',
  styleUrls: ['./authheader.component.scss']
})
export class AuthheaderComponent implements OnInit {

  constructor(
    public alertController: AlertController,
    private router: Router,
    ) {}

  ngOnInit(): void {
  }

  async CancelConfirm() {
    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      header: 'Confirm!',
      message: 'Are you sure to cancel the identity verification process ?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
          }
        }, {
          text: 'Okay',
          handler: () => {
            this.router.navigate(['/tab/settings']);
          }
        }
      ]
    });

    await alert.present();
  }


}
