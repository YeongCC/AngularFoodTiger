import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '@app/api/api.service';
import { CredentialsService } from '@app/auth/authLogin/Service/credentials.service';
import { WalletService } from '@app/components/Service/wallet.service';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-identify-new',
  templateUrl: './identify-new.component.html',
  styleUrls: ['./identify-new.component.scss']
})
export class IdentifyNewComponent implements OnInit {
  error: string | undefined;
  basicForm!: FormGroup;
  data ={
    user_account:this.credentialsService.credentials?.user_account,
    user_name:'',
    user_phone:this.credentialsService.credentials?.user_phone,
    user_email:'',
    user_address:'',
    user_country_code:this.credentialsService.credentials?.user_country_code,
    user_country_name: this.credentialsService.credentials?.user_country_name,
    user_country_currency: this.credentialsService.credentials?.user_country_currency,
    idToken:this.credentialsService.credentials?.token
  }
  userdata:any

  constructor(
    private navCtrl: NavController,
    private router: Router,
    private formBuilder: FormBuilder,
    private api: ApiService,
    private credentialsService: CredentialsService,
    private walletService:WalletService
  ) { 
    this.createForm();
  }

  ngOnInit(): void {

  }

  basic(){
    this.data.user_name=this.basicForm.value.user_name
    this.data.user_email=this.basicForm.value.user_email
    this.data.user_address=this.basicForm.value.user_address
    this.newUser(this.data)
  }

  keyPress(event: any) {
    this.error = ''; 
  }
  
  previous(){
    this.navCtrl.navigateBack('/chyk/identity/brief');
  }

  private createForm() {
    this.basicForm = this.formBuilder.group({
      user_name: ['', Validators.required],
      user_email: ['', Validators.required],
      user_address: ['', Validators.required],
    });
  }

  newUser(data:any){
    this.api.CreateNewUser(data).subscribe(
      (res) => {
        this.credentialsService.setUserDetailCredentials(res.user)
        this.newWallet()
      },(err) => {
        this.error = err.error.message;
      });
  }

  newWallet(){
    var data ={
      user_account:this.credentialsService.credentials?.user_account,
      wallet_currency: this.credentialsService.credentials?.user_country_currency,
      idToken:this.credentialsService.credentials?.token
    }
    this.api.CreateNewUserWallet(data).subscribe(
      (res) => {
        this.walletService.setWallets(res.wallet)
        this.router.navigate(['home']);
      },(err) => {
        this.error = err.error.message;
      });
  }
}
