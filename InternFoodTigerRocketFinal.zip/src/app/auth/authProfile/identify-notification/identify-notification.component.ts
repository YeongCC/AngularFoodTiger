import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-identify-notification',
  templateUrl: './identify-notification.component.html',
  styleUrls: ['./identify-notification.component.scss']
})
export class IdentifyNotificationComponent implements OnInit {

  constructor(

    ) {}

  ngOnInit(): void {
   
  }

  
  
}
