import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '@app/api/api.service';
import { CredentialsService } from '@app/auth/authLogin/Service/credentials.service';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-identify-update',
  templateUrl: './identify-update.component.html',
  styleUrls: ['./identify-update.component.scss']
})
export class IdentifyUpdateComponent implements OnInit {
  error: string | undefined;
  basicForm!: FormGroup;
  data ={
    user_account:this.credentialsService.credentials?.user_account,
    user_name:'',
    user_address:'',
    idToken:this.credentialsService.credentials?.token,
    userId:this.credentialsService.userdetailCredentials?.userId
  }
  userdata:any

  constructor(
    private navCtrl: NavController,
    private router: Router,
    private formBuilder: FormBuilder,
    private api: ApiService,
    private credentialsService: CredentialsService,
  ) { 
    this.createForm();
  }

  ngOnInit(): void {
    console.log(this.credentialsService.userdetailCredentials)
  }

  basicUpdate(){
    this.data.user_name=this.basicForm.value.user_name
    this.data.user_address=this.basicForm.value.user_address
    this.api.UpdateUser(this.data).subscribe(
      (res) => {
        this.router.navigate(['home']);
        this.credentialsService.setUserDetailCredentials(res.user);
      },(err) => {
        this.error = err.error.message;
      });
  }

  keyPress(event: any) {
    this.error = ''; 
  }
  
  previous(){
    this.navCtrl.navigateBack('/chyk/identity/brief');
  }

  private createForm() {
    this.basicForm = this.formBuilder.group({
      user_name: [this.credentialsService.userdetailCredentials?.user_name, Validators.required],
      user_address: [this.credentialsService.userdetailCredentials?.user_address, Validators.required],
    });
  }

}
