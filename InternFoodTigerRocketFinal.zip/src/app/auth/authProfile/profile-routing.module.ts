import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CheckgotdetailGuard } from '@app/components/Guard/check-got-detail.guard';
import { marker } from '@biesbjerg/ngx-translate-extract-marker';
import { AuthproService } from './Service/authpro.service';
import { IdentifyNewComponent } from './identify-new/identify-new.component';
import { IdentifyNotificationComponent } from './identify-notification/identify-notification.component';
import { IdentifyUpdateComponent } from './identify-update/identify-update.component';
import { ProfileComponent } from './profile/profile.component';
import { ProfileguardGuard } from './Guard/profileguard.guard';




const routes: Routes = [
  AuthproService.childRoutes([
    { path: 'brief', component: IdentifyNotificationComponent, data: { title: marker('Identity') }},
    { path: 'basic', component: IdentifyNewComponent, data: { title: marker('Identity') },canActivate: [ProfileguardGuard] },
    { path: 'basic-update', component: IdentifyUpdateComponent, data: { title: marker('Identity Update') } },
  ]),
  { path: 'profile', component: ProfileComponent, data: { title: marker('Profile') } , canActivate: [CheckgotdetailGuard]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class ProfileRoutingModule {}
