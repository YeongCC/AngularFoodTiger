import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { IonicModule } from '@ionic/angular';
import { I18nModule } from '@app/i18n';
import { IdentifyNotificationComponent } from './identify-notification/identify-notification.component';
import { IdentifyUpdateComponent } from './identify-update/identify-update.component';
import { ProfileComponent } from './profile/profile.component';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { ProfileRoutingModule } from './profile-routing.module';
import { IdentifyNewComponent } from './identify-new/identify-new.component';



@NgModule({
  imports: [
    HttpClientModule,
    RouterModule,
    BrowserModule,
    CommonModule, 
    ReactiveFormsModule, 
    TranslateModule, 
    IonicModule, 
    I18nModule, 
    ProfileRoutingModule,
  ],
  declarations: [IdentifyNotificationComponent, IdentifyUpdateComponent, ProfileComponent, IdentifyNewComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
})
export class ProfileModule {}
