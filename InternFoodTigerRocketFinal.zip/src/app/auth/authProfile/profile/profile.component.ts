import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CredentialsService } from '@app/auth/authLogin/Service/credentials.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {

  public user :any = {
    user_name: '',
    user_email: '',
    user_phone: '',
    user_address: '',
  };
  constructor(private router: Router, private credentialsService: CredentialsService) {
  }

  ngOnInit(): void {
    this.user.user_name = this.credentialsService.userdetailCredentials?.user_name
    this.user.user_email = this.credentialsService.userdetailCredentials?.user_email
    this.user.user_phone = this.credentialsService.userdetailCredentials?.user_phone
    this.user.user_address = this.credentialsService.userdetailCredentials?.user_address
  }

}
