import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { IonicModule } from '@ionic/angular';
import { I18nModule } from '@app/i18n';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { AuthheaderComponent } from './authheader/authheader.component';


@NgModule({
  imports: [
    HttpClientModule,
    RouterModule,
    BrowserModule,
    CommonModule, 
    ReactiveFormsModule, 
    TranslateModule, 
    IonicModule, 
    I18nModule,
  ],
  declarations: [AuthheaderComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
})
export class ProfileHeaderModule {}
