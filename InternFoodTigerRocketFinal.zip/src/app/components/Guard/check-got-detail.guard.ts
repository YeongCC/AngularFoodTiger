import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { CredentialsService } from '@app/auth/authLogin/Service/credentials.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CheckgotdetailGuard implements CanActivate {
  constructor(private router: Router, private credentialsService: CredentialsService) {}
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      if (this.credentialsService.isUserAuthenticated()) {
        return true;
      }
  
      this.router.navigate(['/chyk/identity/basic'], { queryParams: { redirect: state.url }, replaceUrl: true });
      return false;
  }
  
}
