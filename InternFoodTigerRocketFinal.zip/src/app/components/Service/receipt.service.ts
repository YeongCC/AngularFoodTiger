import { Injectable } from '@angular/core';
import { Route, Routes } from '@angular/router';
import { AuthenticationGuard } from '@app/auth/authLogin/Guard/authentication.guard';


const receipt = 'receipt';
@Injectable({
  providedIn: 'root'
})
export class ReceiptService {
  public receiptData: any | null = null;
  constructor() { }

  static childRoutes(routes: Routes): Route {
    return {
      path: 'check',
      children: routes,
      canActivate: [AuthenticationGuard],
    };
  }

  setReceipt(data?: any) {
    this.receiptData = data || null;
    if (data) {
      const storage = localStorage;
      storage.setItem(receipt, JSON.stringify(receipt));
    } else {
      sessionStorage.removeItem(receipt);
      localStorage.removeItem(receipt);
    }
  }
}
