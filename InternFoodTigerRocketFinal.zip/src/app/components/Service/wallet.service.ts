import { Injectable } from '@angular/core';
import { Route, Routes } from '@angular/router';
import { AuthenticationGuard } from '@app/auth/authLogin/Guard/authentication.guard';

export interface WalletDetailCredentials {
  wallet_user_account_reference: string;
  wallet_balance: number;
  wallet_currency:string;
}

export interface ConfirmPayCredentials {
  wallet_amount: string;
  payement_gateway: string;
}

const walletKey = 'wallets';
const processPayKey = 'processPayKey';
const confirmpPayKey = 'confirmpPayKey';

@Injectable({
  providedIn: 'root'
})
export class WalletService {
  private _wallets: WalletDetailCredentials | null = null;
  public processPaydata: any | null = null;
  public confirmPaydata: ConfirmPayCredentials | null = null;
  constructor() {
    const savedWallets = sessionStorage.getItem(walletKey) || localStorage.getItem(walletKey);
    if (savedWallets) {
      this._wallets = JSON.parse(savedWallets);
    }
    const processConfirm = sessionStorage.getItem(confirmpPayKey) || localStorage.getItem(confirmpPayKey);
    if (processConfirm) {
      this.confirmPaydata = JSON.parse(processConfirm);
    }
   }

  static childRoutes(routes: Routes): Route {
    return {
      path: 'wallet',
      children: routes,
      canActivate: [AuthenticationGuard],
    };
  }

  isWalletAuthenticated(): boolean {
    return !!this.wallets;
  }

  get wallets(): WalletDetailCredentials | null {
    return this._wallets;
  }

  setWallets(wallets?: WalletDetailCredentials) {
    this._wallets = wallets || null;

    if (wallets) {
      const storage = localStorage;
      storage.setItem(walletKey, JSON.stringify(wallets));
    } else {
      sessionStorage.removeItem(walletKey);
      localStorage.removeItem(walletKey);
    }
  }

  setProcessPay(url?: any) {
    this.processPaydata = url || null;

    if (url) {
      const storage = localStorage;
      storage.setItem(processPayKey, JSON.stringify(url));
    } else {
      sessionStorage.removeItem(processPayKey);
      localStorage.removeItem(processPayKey);
    }
  }

  setConfirmPay(data?: ConfirmPayCredentials) {
    this.confirmPaydata = data || null;
    if (data) {
      const storage = localStorage;
      storage.setItem(confirmpPayKey, JSON.stringify(confirmpPayKey));
    } else {
      sessionStorage.removeItem(confirmpPayKey);
      localStorage.removeItem(confirmpPayKey);
    }
  }

}
