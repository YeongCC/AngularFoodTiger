import { Component, OnInit } from '@angular/core';
import { CartItem } from 'src/app/api/class/cartclass';
import { CartService } from '@app/components/Service/cart.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})
export class CartComponent implements OnInit {
  cartItems: CartItem[] = [];
  totalPrice: number = 0;
  totalQuantity: number = 0;
  constructor(
    private router: Router,
    private cartService: CartService,
    ) {}

  ngOnInit(): void {
    this.listCartDetails();
  }

  listCartDetails() {
    this.cartItems = this.cartService.cartItems;
    this.cartService.totalPrice.subscribe((data) => (this.totalPrice = data)); 
    this.cartService.totalQuantity.subscribe((data) => (this.totalQuantity = data));
    this.cartService.computeCartTotals();
    this.cartService.setItems(this.cartItems)
  }
  incrementQuantity(theCartItem: CartItem) {
    this.cartService.addToCart(theCartItem);
  }
  decrementQuantity(theCartItem: CartItem) {
    this.cartService.decrementQuantity(theCartItem);
  }
  remove(theCartItem: CartItem) {
    this.cartService.remove(theCartItem);
  }

  emptycart() {
    this.cartService.removeAllCart();
  }

  checkout(data:any,cartdata:any){
    this.cartService.setTotalPrice(data)
    this.cartService.setTotalItem(cartdata)
    this.router.navigate(['/payment/confirmDetail']);
  }
}
