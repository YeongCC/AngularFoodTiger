import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { marker } from '@biesbjerg/ngx-translate-extract-marker';
import { Shell } from '@app/shell/shell.service';
import { CartComponent } from './cart/cart.component';
import { OrderdetailComponent } from './orderdetail/orderdetail.component';
import { OrderdataService } from './Service/orderdata.service';
import { ConfirmReceiptComponent } from './confirm-receipt/confirm-receipt.component';
import { ReceiptService } from '@app/components/Service/receipt.service';
import { ReceiptComponent } from './receipt/receipt.component';
import { ReceiptOneDetailComponent } from './receipt-one-detail/receipt-one-detail.component';
import { CheckgotdetailGuard } from './Guard/check-got-detail.guard';
import { ReceiptGuard } from './Guard/receipt.guard';
import { PersonalReceiptGuard } from './Guard/personal-receipt.guard';
import { WalletService } from './Service/wallet.service';
import { WalletGuard } from './Guard/wallet.guard';
import { WalletComponent } from './wallet/wallet.component';
import { WalletReloadComponent } from './wallet-reload/wallet-reload.component';
import { WalletProcessHistoryComponent } from './wallet-process-history/wallet-process-history.component';
import { WalletProcessConfirmComponent } from './wallet-process-confirm/wallet-process-confirm.component';
import { ConfirmPayGuard } from './Guard/confirm-pay.guard';
import { WalletProcessEndComponent } from './wallet-process-end/wallet-process-end.component';
import { WalletProcessComponent } from './wallet-process/wallet-process.component';
import { WalletOneProcessHistoryComponent } from './wallet-one-process-history/wallet-one-process-history.component';

const routes: Routes = [
  Shell.childRoutes([
    { path: 'cart', component: CartComponent, data: { title: marker('Cart') } },
  ]),
  OrderdataService.childRoutes([
    { path: 'confirmDetail', component: OrderdetailComponent, data: { title: marker('Checkout') } ,
  canActivate: [CheckgotdetailGuard] },
  ]),
  ReceiptService.childRoutes([
  { path: 'receipt', component: ConfirmReceiptComponent, data: { title: marker('Receipt') } , canActivate: [ReceiptGuard]},
  { path: 'receipt/:user_account', component: ReceiptComponent, data: { title: marker('Receipt') } , canActivate: [PersonalReceiptGuard]},
  { path: 'order_receipt/:user_account/:orderId', component: ReceiptOneDetailComponent, data: { title: marker('Receipt') } , canActivate: [PersonalReceiptGuard]},
  ]),
  WalletService.childRoutes([
    { path: 'detail/:user_account', component: WalletComponent, data: { title: marker('Wallet') } , canActivate: [WalletGuard]},
    { path: 'recharge', component: WalletReloadComponent, data: { title: marker('Wallet') } , canActivate: [WalletGuard]},
    { path: 'history/:user_account', component: WalletProcessHistoryComponent, data: { title: marker('Wallet') } , canActivate: [WalletGuard]},//history
    { path: 'history/:user_account/:id', component: WalletOneProcessHistoryComponent, data: { title: marker('Wallet') } , canActivate: [WalletGuard]},//history
    { path: 'confirm', component: WalletProcessConfirmComponent, data: { title: marker('Wallet') } , canActivate: [WalletGuard,ConfirmPayGuard]},
    { path: 'process', component: WalletProcessComponent, data: { title: marker('Wallet') } , canActivate: [WalletGuard,ConfirmPayGuard]},
    { path: 'result', component: WalletProcessEndComponent, data: { title: marker('Wallet') } , canActivate: [WalletGuard,ConfirmPayGuard]},
  ]),
 
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class ComponentsRoutingModule {}
