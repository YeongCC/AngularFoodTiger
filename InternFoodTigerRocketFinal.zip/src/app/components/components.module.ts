import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { MenuComponent } from './menu/menu.component';
import { CartComponent } from './cart/cart.component';
import { ReceiptComponent } from './receipt/receipt.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { ComponentsRoutingModule } from './components-routing.module';
import { I18nModule } from '@app/i18n';
import { BrowserModule } from '@angular/platform-browser';
import { OrderdetailComponent } from './orderdetail/orderdetail.component';
import { IonicModule } from '@ionic/angular';
import { ReactiveFormsModule } from '@angular/forms';
import { ConfirmReceiptComponent } from './confirm-receipt/confirm-receipt.component';
import { ReceiptOneDetailComponent } from './receipt-one-detail/receipt-one-detail.component';
import { WalletComponent } from './wallet/wallet.component';
import { WalletReloadComponent } from './wallet-reload/wallet-reload.component';
import { WalletProcessComponent } from './wallet-process/wallet-process.component';
import { WalletProcessHistoryComponent } from './wallet-process-history/wallet-process-history.component';
import { WalletProcessConfirmComponent } from './wallet-process-confirm/wallet-process-confirm.component';
import { WalletProcessEndComponent } from './wallet-process-end/wallet-process-end.component';
import { WalletOneProcessHistoryComponent } from './wallet-one-process-history/wallet-one-process-history.component';

@NgModule({
  imports: [
    HttpClientModule,
    RouterModule,
    BrowserModule,
    CommonModule,
    TranslateModule,
    I18nModule,
    ComponentsRoutingModule,
    ReactiveFormsModule,
    IonicModule,
  ],
  declarations: [MenuComponent, CartComponent, ReceiptComponent, OrderdetailComponent, ConfirmReceiptComponent, ReceiptOneDetailComponent, WalletComponent, WalletReloadComponent, WalletProcessComponent, WalletProcessHistoryComponent, WalletProcessConfirmComponent,WalletProcessEndComponent, WalletOneProcessHistoryComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
  entryComponents: [CartComponent],
  exports: [MenuComponent],
})
export class ComponentsModule {}
