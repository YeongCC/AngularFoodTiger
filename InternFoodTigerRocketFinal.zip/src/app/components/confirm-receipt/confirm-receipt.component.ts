import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ReceiptService } from '@app/components/Service/receipt.service';

@Component({
  selector: 'app-confirm-receipt',
  templateUrl: './confirm-receipt.component.html',
  styleUrls: ['./confirm-receipt.component.scss']
})
export class ConfirmReceiptComponent implements OnInit {
  public data:any ={
    user_name : '',
    user_phone : '',
    user_address : '',
    total_price : '',
    payement_way : '',
    order_time : '',
  }
  public menu:any | undefined
  constructor(
    private router: Router,
    private receiptService: ReceiptService
  ) { 
    
  }

  ngOnInit(): void {
    this.data.user_name = this.receiptService.receiptData.user_name
    this.data.user_phone = this.receiptService.receiptData.user_phone
    this.data.user_address = this.receiptService.receiptData.user_address
    this.data.total_price = this.receiptService.receiptData.total_price
    this.data.payement_way = this.receiptService.receiptData.payement_way 
    this.data.order_time = this.receiptService.receiptData.order_time  
    for (let i = 0;i < this.receiptService.receiptData.menu.length; i++) {
      this.menu = this.receiptService.receiptData.menu[i]
    }
  }

  home(){
    this.receiptService.setReceipt()
    this.router.navigate(['/tabs/home'])
  }
}
