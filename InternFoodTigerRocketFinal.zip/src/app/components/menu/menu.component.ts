import { Component, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ApiService } from 'src/app/api/api.service';
import { CartItem } from 'src/app/api/class/cartclass';
import { CartService } from '@app/components/Service/cart.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css'],
})
export class MenuComponent implements OnInit {
  public menudata: any =[];

  constructor(private api: ApiService, private cartService: CartService) {}
  public cartItemList: any = [];
  public menuitemList = new BehaviorSubject<any>([]);

  ngOnInit(): void {
    this.api.getMenuList().subscribe((res: any) => {
      this.menudata = res;
    });
  }
  add(item: any) {
    const theCartItem = new CartItem(item);
    this.cartService.addToCart(theCartItem);
  }
}
