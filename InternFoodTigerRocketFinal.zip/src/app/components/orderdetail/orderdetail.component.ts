import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '@app/api/api.service';
import { CredentialsService } from '@app/auth/authLogin/Service/credentials.service';
import { CartService } from '@app/components/Service/cart.service';
import { ReceiptService } from '@app/components/Service/receipt.service';
import { AlertController } from '@ionic/angular';
import { WalletService } from '../Service/wallet.service';

@Component({
  selector: 'app-orderdetail',
  templateUrl: './orderdetail.component.html',
  styleUrls: ['./orderdetail.component.scss']
})
export class OrderdetailComponent implements OnInit {
  error: string | undefined;
  orderdetailForm!: FormGroup;
  public totalPrice: number | undefined;
  constructor(
    private formBuilder: FormBuilder,
    private api: ApiService,
    private router: Router,
    private credentialsService: CredentialsService,
    private cartService: CartService,
    private receiptService: ReceiptService,
    private walletService: WalletService,
    public alertController: AlertController
  ) {
    this.createForm();
  }

  ngOnInit(): void {
    this.totalPrice = (this.cartService.totalPriceMoney as unknown as number)
  }

  order() {
    var data = {
      user_name: this.orderdetailForm.value.user_name,
      user_phone: this.orderdetailForm.value.user_phone,
      user_account: this.credentialsService.userdetailCredentials?.user_account,
      user_address: this.orderdetailForm.value.user_address,
      menu: this.cartService.totalItem,
      total_price: this.totalPrice,
      payement_way: this.orderdetailForm.value.user_payement,
      amount: this.totalPrice,
      wallet_currency: this.walletService.wallets?.wallet_currency
    }
    this.checkPayementWay(data)
  }

  async payment_way() {
    const alert = await this.alertController.create({
      header: 'Radio',
      inputs: [
        {
          name: 'Cash',
          type: 'radio',
          label: 'Cash',
          value: 'Cash',
          handler: () => {
            this.orderdetailForm.value.user_payement = 'Cash'
            this.totalPrice = (this.cartService.totalPriceMoney as unknown as number)
            console.log(this.orderdetailForm.value.user_payement);
          }
        },
        {
          name: 'Wallet',
          type: 'radio',
          label: 'Wallet',
          value: 'Wallet',
          handler: () => {
            this.orderdetailForm.value.user_payement = 'Wallet'
            var discount = ((this.cartService.totalPriceMoney as unknown as number) / 100) * 10
            this.totalPrice = (this.cartService.totalPriceMoney as unknown as number) - discount
            console.log(this.orderdetailForm.value.user_payement);
          }
        }
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Ok',
          handler: () => {
            console.log('Confirm Ok');
          }
        }
      ]
    });
    await alert.present();

  }

  async checkPayementWay(data: any) {
    if (data.payement_way == "Wallet") {
      if (data.amount < data.total_price) {
        const alert = await this.alertController.create({
          header: 'Warning No Enough Money!',
          message: 'Your Want To Recharge Now ?',
          buttons: [
            {
              text: 'Cancel',
              role: 'cancel',
              cssClass: 'secondary',
              handler: (blah) => {
              }
            }, {
              text: 'Okay',
              handler: () => {
                this.router.navigate(['/wallet/recharge']);
              }
            }
          ]
        });
        await alert.present();
      } else {
        const alert = await this.alertController.create({
          header: 'Confirm',
          message: 'You Confirm Your Order ?',
          buttons: [
            {
              text: 'Cancel',
              role: 'cancel',
              cssClass: 'secondary',
              handler: (blah) => {
              }
            }, {
              text: 'Okay',
              handler: () => {
                this.createOrder(data)
              }
            }
          ]
        });
        await alert.present();

      }
    } else if (data.payement_way == "Cash") {
      const alert = await this.alertController.create({
        header: 'Confirm',
        message: 'You Confirm Your Order ?',
        buttons: [
          {
            text: 'Cancel',
            role: 'cancel',
            cssClass: 'secondary',
            handler: (blah) => {
            }
          }, {
            text: 'Okay',
            handler: () => {
              this.createOrder(data)
            }
          }
        ]
      });
      await alert.present();
    } else {
      const alert = await this.alertController.create({
        header: 'Warning !',
        message: 'Please Select PaymentWay !',
        buttons: ['Ok']
      });

      await alert.present();
    }

  }


  createOrder(data: any) {
    this.api.CreateOrderData(data).subscribe(
      (res) => {
        this.receiptService.setReceipt(res)
        this.cartService.setItems()
        this.cartService.removeAllCart()
        this.updateWallet()
        this.router.navigate(['/check/receipt'])
      }, (err) => {
        this.error = err.error.message;
      });
  }



  async updateWallet() {
   const wallet = await this.api.updateWalletDetail(this.credentialsService.credentials?.user_account).subscribe((res: any) => {
      this.walletService.setWallets(res.wallet)
    });
    return wallet
  }

  keyPress(event: any) {
    this.error = '';
  }

  private createForm() {
    this.orderdetailForm = this.formBuilder.group({
      user_name: [this.credentialsService.userdetailCredentials?.user_name, Validators.required],
      user_phone: [this.credentialsService.userdetailCredentials?.user_phone, Validators.required],
      user_address: [this.credentialsService.userdetailCredentials?.user_address, Validators.required],
      user_payement: [''],
    });
  }

}
