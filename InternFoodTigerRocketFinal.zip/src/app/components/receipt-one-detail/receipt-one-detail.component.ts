import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { ApiService } from '@app/api/api.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-receipt-one-detail',
  templateUrl: './receipt-one-detail.component.html',
  styleUrls: ['./receipt-one-detail.component.scss']
})
export class ReceiptOneDetailComponent implements OnInit {
  public receiptdata: any =[]
  public menudata: any 
  public menu:any
  constructor(
    private api: ApiService,
    private _location: Location,
    private activeroute: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.api.getUserOneOrderDetail(this.activeroute.snapshot.params.user_account,this.activeroute.snapshot.params.orderId).subscribe((res: any) => {
      this.receiptdata = res;
      this.menudata = res.menu;
      for (let i = 0;i < this.menudata.length; i++) {
        this.menu = this.menudata[i]
      }
    });
  }

  back(){
   this._location.back();
  }
}
