import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '@app/api/api.service';
import { DateTime } from 'luxon';

@Component({
  selector: 'app-receipt',
  templateUrl: './receipt.component.html',
  styleUrls: ['./receipt.component.scss'],
})
export class ReceiptComponent implements OnInit {
  public receiptdata: any =[];

  constructor(
    private api: ApiService,
    private router: Router,
    private activeroute: ActivatedRoute) {}

  ngOnInit(): void {
    this.api.getUserOrderDetail(this.activeroute.snapshot.params.user_account).subscribe((res: any) => {
      this.receiptdata = res;
      for (let i = 0;i < this.receiptdata.length; i++) {
        this.receiptdata.order_time = DateTime.fromMillis(res[i].order_time).setZone('Asia/Kuala_Lumpur').toFormat("MM/dd/yyyy");
      }
    });
  }

  detail(orderId:any){
    this.router.navigate(['/check/order_receipt/'+this.activeroute.snapshot.params.user_account+'/'+orderId]);
  }
}
