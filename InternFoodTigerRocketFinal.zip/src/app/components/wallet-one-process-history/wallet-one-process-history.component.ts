import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { ApiService } from '@app/api/api.service';
import { ActivatedRoute, Router } from '@angular/router';
import { DateTime } from 'luxon';

@Component({
  selector: 'app-wallet-one-process-history',
  templateUrl: './wallet-one-process-history.component.html',
  styleUrls: ['./wallet-one-process-history.component.scss']
})
export class WalletOneProcessHistoryComponent implements OnInit {
  public historydata: any =[];
  public time: any =[];
  constructor(
    private _location: Location,
    private api: ApiService,
    private router: Router,
    private activeroute: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.api.getWalletOneProcessHistory(this.activeroute.snapshot.params.user_account,this.activeroute.snapshot.params.id).subscribe((res: any) => {
      this.historydata = res;
      this.time = DateTime.fromMillis(res.process_wallet_created_time).setZone('Asia/Kuala_Lumpur').toFormat("MM/dd/yyyy H:mm");
    });
  }

  back(){
    this._location.back();
  }
}
