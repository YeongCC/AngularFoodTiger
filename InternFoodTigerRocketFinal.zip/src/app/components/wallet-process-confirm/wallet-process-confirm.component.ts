import { Component, OnDestroy, OnInit } from '@angular/core';
import { ApiService } from '@app/api/api.service';
import { CredentialsService } from '@app/auth/authLogin/Service/credentials.service';
import { WalletService } from '../Service/wallet.service';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { timer } from 'rxjs'
import { takeWhile } from 'rxjs/operators'

@Component({
  selector: 'app-wallet-process-confirm',
  templateUrl: './wallet-process-confirm.component.html',
  styleUrls: ['./wallet-process-confirm.component.scss']
})
export class WalletProcessConfirmComponent implements OnInit, OnDestroy {
  wallet_currency = this.walletService.wallets?.wallet_currency;
  total_pay: string | undefined;
  payment_gateway: string | undefined;
  alive: boolean = true;
  constructor(
    private api: ApiService,
    private router: Router,
    private walletService: WalletService,
    private credentialsService: CredentialsService,
    public alertController: AlertController
  ) { }

  ngOnInit(): void {
    if (this.wallet_currency == "MYR") {
      this.wallet_currency = "RM";
    }
    this.total_pay = this.walletService.confirmPaydata?.wallet_amount
    this.payment_gateway = this.walletService.confirmPaydata?.payement_gateway
    timer(60000).pipe(takeWhile(() => this.alive)).subscribe(async _ => {
      let alert = await this.alertController.create({
        header: 'Sorry',
        message: 'The Recharge Form is timeout',
        buttons: [
          {
            text: 'Ok',
            handler: () => {
              this.walletService.setConfirmPay()
              this.router.navigate(['/tabs/settings'])
            }
          }
        ]
      });

      await alert.present();

    })

  }
  ngOnDestroy() {
    this.alive = false;
  }

  async confirm() {

    var data = {
      user_account: this.credentialsService.userdetailCredentials?.user_account,
      payment_gateway: this.walletService.confirmPaydata?.payement_gateway,
      data: {
        amount: this.walletService.confirmPaydata?.wallet_amount + "00 ",
        currency: this.credentialsService.credentials?.user_country_currency,
        customer_name: this.credentialsService.userdetailCredentials?.user_account,//user account
        email: this.credentialsService.userdetailCredentials?.user_email,
        contact_number: this.credentialsService.userdetailCredentials?.user_phone,
        address: this.credentialsService.userdetailCredentials?.user_address,
        postcode: "string",
        city: "string",
        state: "string",
        country: this.credentialsService.credentials?.user_country_name,
        shipping_name: this.credentialsService.userdetailCredentials?.user_name,
        shipping_email: this.credentialsService.userdetailCredentials?.user_email,
        shipping_contact_number: this.credentialsService.userdetailCredentials?.user_phone,
        shipping_address: "string",
        shipping_postcode: "string",
        shipping_city: "string",
        shipping_state: "string",
        shipping_country: this.credentialsService.credentials?.user_country_name,
        description: "string",
      }
    }
    this.checkPaymentGateway(data)
  }

  checkPaymentGateway(data: any) {
    this.api.paymentGateway(data).subscribe(
      (res) => {
        console.log(res)
        setTimeout(() => {
          this.walletService.setProcessPay(res.url)
          this.router.navigate(['/wallet/process']);
        }, 2000);
      });
  }

  async back() {
    let alert = await this.alertController.create({
      header: 'Processing',
      message: 'Your request is being processed. If you leave this page, your request may be cancelled.',
      buttons: [
        {
          text: 'Stay',
          role: 'cancel',
          handler: () => {
          }
        }, {
          text: 'Leave',
          cssClass: 'leavebutton',
          handler: () => {
            this.walletService.setConfirmPay()
            this.router.navigate(['/wallet/detail/' + this.credentialsService.userdetailCredentials?.user_account]);
          }
        }
      ]
    });

    await alert.present();
  }
}
