import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '@app/api/api.service';
import { CredentialsService } from '@app/auth/authLogin/Service/credentials.service';
import { WalletService } from '../Service/wallet.service';
import { DateTime } from 'luxon';

@Component({
  selector: 'app-wallet-process-end',
  templateUrl: './wallet-process-end.component.html',
  styleUrls: ['./wallet-process-end.component.scss']
})
export class WalletProcessEndComponent implements OnInit {
  public result = {
    process_wallet_action: '',
    process_wallet_amount: '',
    process_wallet_created_time: '',
    process_wallet_currency: '',
    process_wallet_id: '',
    process_wallet_reference_user_account: '',
    process_wallet_refrence_Process_Result_id: '',
    process_wallet_response: '',
    reference_gateway: '',
  };
  constructor(
    private api: ApiService,
    private router: Router,
    private walletService: WalletService,
    private credentialsService: CredentialsService,
  ) { }

  ngOnInit(): void {
    this.api.getPaymentResultReceipt(this.credentialsService.userdetailCredentials?.user_account).subscribe((res: any) => {
      var data = res.shift()
      this.result.process_wallet_action = data.process_wallet_action;
      this.result.process_wallet_amount = data.process_wallet_amount;
      this.result.process_wallet_created_time = DateTime.fromMillis(data.process_wallet_created_time).setZone('Asia/Kuala_Lumpur').toFormat("MMMM dd, yyyy h:mm:ss a");
      if (data.process_wallet_currency = "MYR") {
        this.result.process_wallet_currency = "RM";
      }
      this.result.process_wallet_id = data.process_wallet_id;
      this.result.process_wallet_reference_user_account = data.process_wallet_reference_user_account;
      this.result.process_wallet_refrence_Process_Result_id = data.process_wallet_refrence_Process_Result_id;
      this.result.process_wallet_response = data.process_wallet_response;
      this.result.reference_gateway = data.reference_gateway;
    });

    this.api.updateWalletDetail(this.credentialsService.credentials?.user_account).subscribe((res: any) => {
      this.walletService.setWallets(res.wallet)
    });
  }

home(){
  this.walletService.setConfirmPay()
  this.router.navigate(['/tabs/home']);
}

}
