import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '@app/api/api.service';
import { DateTime } from 'luxon';

@Component({
  selector: 'app-wallet-process-history',
  templateUrl: './wallet-process-history.component.html',
  styleUrls: ['./wallet-process-history.component.scss']
})
export class WalletProcessHistoryComponent implements OnInit {
  public historydata: any =[];
  public time: any =[];
  constructor(
    private api: ApiService,
    private _location: Location,
    private router: Router,
    private activeroute: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.api.getWalletProcessHistory(this.activeroute.snapshot.params.user_account).subscribe((res: any) => {
      this.historydata = res;
      for (let i = 0;i < this.historydata.length; i++) {
        console.log(DateTime.fromMillis(res[i].process_wallet_created_time).setZone('Asia/Kuala_Lumpur').toFormat("MM/dd/yyyy"))
        this.historydata.process_wallet_created_time = DateTime.fromMillis(res[i].process_wallet_created_time).setZone('Asia/Kuala_Lumpur').toFormat("MM/dd/yyyy");
      }
    });
  }

  detail(process_wallet_id:any){
    this.router.navigate(['/wallet/history/'+this.activeroute.snapshot.params.user_account+'/'+process_wallet_id]);
  }

  back(){
    this._location.back();
  }

}
