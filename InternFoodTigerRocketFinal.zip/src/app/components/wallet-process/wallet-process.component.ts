import { Component, OnDestroy, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { CredentialsService } from '@app/auth/authLogin/Service/credentials.service';
import { AlertController } from '@ionic/angular';
import { WalletService } from '../Service/wallet.service';
import {timer} from 'rxjs'
import {takeWhile} from 'rxjs/operators'

@Component({
  selector: 'app-wallet-process',
  templateUrl: './wallet-process.component.html',
  styleUrls: ['./wallet-process.component.scss']
})
export class WalletProcessComponent implements OnInit,OnDestroy {
  url:any|undefined;
  alive:boolean=true;
  constructor(
    private router: Router,
    private walletService: WalletService,
    private credentialsService: CredentialsService,
    private sanitzer:DomSanitizer,
    public alertController: AlertController
  ) { }

  ngOnInit(): void {
    timer(60000).pipe(takeWhile(()=>this.alive)).subscribe(async _=>{
      let  alert = await this.alertController.create({
        header: 'Sorry',
        message: 'The Recharge Form is timeout',
        buttons: [
          {
            text: 'Ok',
            handler: () => {
              this.walletService.setConfirmPay()
              this.router.navigate(['/tabs/settings'])
            }
          }
        ]
      });
  
      await alert.present();
    
   })
    // this.url = this.sanitzer.bypassSecurityTrustResourceUrl(this.walletService.processPaydata)
    window.open(this.walletService.processPaydata, '_self');
  }
  ngOnDestroy()
  {
      this.alive=false;
  }
  async back() {
    let  alert = await this.alertController.create({
      header: 'Processing',
      message: 'Your request is being processed. If you leave this page, your request may be cancelled.',
      buttons: [
        {
          text: 'Stay',
          role: 'cancel',
          handler: () => {
          }
        }, {
          text: 'Leave',
          handler: () => {
            this.walletService.setConfirmPay()
            this.router.navigate(['/wallet/detail/'+this.credentialsService.userdetailCredentials?.user_account]);
          }
        }
      ]
    });

    await alert.present();
  }
}
