import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { WalletService } from '../Service/wallet.service';
import { CredentialsService } from '@app/auth/authLogin/Service/credentials.service';
import { ApiService } from '@app/api/api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-wallet-reload',
  templateUrl: './wallet-reload.component.html',
  styleUrls: ['./wallet-reload.component.scss']
})
export class WalletReloadComponent implements OnInit {
  rechargeForm!: FormGroup;
  wallet_amount: number | undefined
  reload_credit: number = 0.00
  total_pay: number = 0.00
  wallet_currency = this.walletService.wallets?.wallet_currency
  constructor(
    private _location: Location,
    private formBuilder: FormBuilder,
    private router: Router,
    private walletService: WalletService,
  ) {
    this.createForm();
  }

  ngOnInit(): void {
    if (this.wallet_currency == "MYR") {
      this.wallet_currency = "RM";
    }
  }

  async recharge() {
  this.walletService.setConfirmPay(this.rechargeForm.value)
  this.router.navigate(['/wallet/confirm']);
  }



  isNumberKey(event: any) {
    const pattern = /[0-9]/;
    let inputChar = String.fromCharCode(event.charCode);
    if (!pattern.test(inputChar)) {
      event.preventDefault();
    }
  }

  getvalue(value: any) {
    if (this.rechargeForm.value.wallet_amount == 1 || this.rechargeForm.value.wallet_amount <= 9999) {
      if ((value.toString().substring(0, 3) == "000")) {
        this.reload_credit = value.slice(-1);
        this.total_pay = value.slice(-1);
      } else 
      if ((value.toString().substring(0, 2) == "00")) {
        if (value.toString().length == 4) {
          this.reload_credit = value.slice(-2);
          this.total_pay = value.slice(-2);
        } else 
        if (value.toString().length == 3) {
          this.reload_credit = value.slice(-1);
          this.total_pay = value.slice(-1);
        }
      } else 
      if ((value.toString().substring(0, 1) == "0")) {
        if (value.toString().length == 4) {
          this.reload_credit = value.slice(-3);
          this.total_pay = value.slice(-3);
        } else if (value.toString().length == 3) {
          this.reload_credit = value.slice(-2);
          this.total_pay = value.slice(-2);
        } else if (value.toString().length == 2) {
          this.reload_credit = value.slice(-1);
          this.total_pay = value.slice(-1);
        } else if (value.toString().length == 1) {
          this.reload_credit = 0.00;
          this.total_pay = 0.00;
        }
      } else 
      if (value.toString().substring(0, 4) == "0000") {
        this.reload_credit = 0.00;
        this.total_pay = 0.00;
      } else 
      if(this.rechargeForm.value.wallet_amount != null){
        if(value.toString()==''){
          this.reload_credit = 0.00;
          this.total_pay = 0.00;
        }else{
          this.reload_credit = value;
          this.total_pay = value;
        }
      }
    }
  }

  b10() {
    this.wallet_amount = 10.00
    this.reload_credit = 10.00
    this.total_pay = 10.00
  }

  b20() {
    this.wallet_amount = 20.00
    this.reload_credit = 20.00
    this.total_pay = 20.00
  }

  b50() {
    this.wallet_amount = 50.00
    this.reload_credit = 50.00
    this.total_pay = 50.00
  }

  b100() {
    this.wallet_amount = 100.00
    this.reload_credit = 100.00
    this.total_pay = 100.00
  }

  b200() {
    this.wallet_amount = 200.00
    this.reload_credit = 200.00
    this.total_pay = 200.00
  }

  b500() {
    this.wallet_amount = 500.00
    this.reload_credit = 500.00
    this.total_pay = 500.00
  }

  private createForm() {
    this.rechargeForm = this.formBuilder.group({
      wallet_amount: [this.wallet_amount, Validators.required],
      payement_gateway: ['', Validators.required],
    });
  }

  back() {
    this._location.back();
  }

}
