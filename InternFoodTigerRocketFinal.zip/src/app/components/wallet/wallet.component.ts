import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { WalletService } from '../Service/wallet.service';

@Component({
  selector: 'app-wallet',
  templateUrl: './wallet.component.html',
  styleUrls: ['./wallet.component.scss']
})
export class WalletComponent implements OnInit {
   public wallet :any = {
    wallet_currency: this.walletService.wallets?.wallet_currency,
    wallet_balance: '',
    wallet_user_account_reference: '',
  };
  constructor(
    private walletService: WalletService,
    private router: Router,
    private activeroute: ActivatedRoute
  ) { }

  ngOnInit(): void {
    if(this.wallet.wallet_currency=="MYR"){
      this.wallet.wallet_currency = "RM";
    }
    this.wallet.wallet_balance = this.walletService.wallets?.wallet_balance;
  }

  history(){
    this.router.navigate(['/wallet/history/'+this.activeroute.snapshot.params.user_account]);
  }
}
