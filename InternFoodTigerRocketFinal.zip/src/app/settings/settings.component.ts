import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Platform } from '@ionic/angular';
import { ApiService } from '@app/api/api.service';
import { AuthenticationService } from '@app/auth/authLogin/Service/authentication.service';
import { CredentialsService } from '@app/auth/authLogin/Service/credentials.service';
import { WalletService } from '@app/components/Service/wallet.service';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss'],
})
export class SettingsComponent implements OnInit {
  public user:any | undefined
  public user_account:any | undefined
  constructor(
    private api: ApiService,
    private router: Router,
    private authenticationService: AuthenticationService,
    private credentialsService: CredentialsService,
    private platform: Platform,
    private walletService: WalletService,
  ) {}

  ngOnInit() {
    this.user=this.credentialsService.userdetailCredentials
    this.user_account=this.credentialsService.userdetailCredentials?.user_account
    this.walletService.setConfirmPay()
  }

  get isWeb(): boolean {
    return !this.platform.is('cordova');
  }

  get name(){
    if(this.credentialsService.userdetailCredentials==null){
      const credentials = this.credentialsService.credentials?.user_account;
      return credentials ;
    }else{
      const credentials = this.credentialsService.userdetailCredentials.user_name;
      return credentials;
    }
    
  }

  logout() {
    this.api.SessionLogout().subscribe((res) => {
      this.authenticationService.logout().subscribe(() => this.router.navigate(['/login'], { replaceUrl: true }));
    });
  }
}
