import { Component, OnInit } from '@angular/core';
import { CartService } from '@app/components/Service/cart.service';

@Component({
  selector: 'app-shell',
  templateUrl: './shell.component.html',
  styleUrls: ['./shell.component.scss'],
})
export class ShellComponent implements OnInit {
  public totalItem: number = 0;
  constructor(
    private cartService: CartService
  ) {}

  ngOnInit() {
    this.cartService.getMenuItems().subscribe((res) => {
      this.totalItem = res.length;
    });
  }
}
