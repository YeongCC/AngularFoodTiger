module.exports = {
    externals: {
        sqlite3: 'commonjs sqlite3'
    },
    target:'electron-renderer'
}