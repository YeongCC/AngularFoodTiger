"use strict";

const { app, BrowserWindow, ipcMain } = require("electron");
const path = require("path");
let waitBeforeClose = true;

const devMode = /electron/.test(path.basename(app.getPath("exe"), ".exe"));

if (devMode) {
  // Set appname and userData to indicate development environment
  app.name = app.name + "-dev";
  app.setPath("userData", app.getPath("userData") + "-dev");

  // Temporary fix for Electron 'reload' issue
  app.allowRendererProcessReuse = false;

  // Setup reload
  require("electron-reload")(path.join(__dirname, "dist"), {
    electron: path.join(__dirname, "node_modules", ".bin", "electron"),
  });
}

let mainWindow;
let secondWindow;
let createWindow = () => {
  mainWindow = new BrowserWindow({
    show: false,
    webPreferences: {
      nodeIntegration: true,
      enableRemoteModule: true,
    },
  });
  mainWindow.setMenu(null);
  mainWindow.once("ready-to-show", () => {
    mainWindow.show();
  });
  mainWindow.setBackgroundColor('#FFFFFF')
  mainWindow.maximize();
  mainWindow.loadURL("file://" + __dirname + "/dist/index.html#/cus/secondpage");
  if (devMode && process.argv.indexOf("--noDevTools") === -1) {
    mainWindow.webContents.openDevTools();
  }
  mainWindow.on("closed", () => {
    mainWindow = null;
    app.quit();
  });
};

ipcMain.on("second-page", function () {
  secondWindow = new BrowserWindow({
    show: false,
    webPreferences: {
      nodeIntegration: true,
      enableRemoteModule: true,
    },
  });
  secondWindow.setMenu(null);
  secondWindow.setBackgroundColor('#FFFFFF')
  secondWindow.once("ready-to-show", () => {
    secondWindow.show();
  });
  secondWindow.maximize();
  secondWindow.loadURL("file://" + __dirname + "/dist/index.html#/cus/secondpage");
  secondWindow.webContents.openDevTools();

  secondWindow.on("closed", () => {
    secondWindow = null;
  });
  if (!secondWindow.isVisible()) secondWindow.hide();
  else secondWindow.show();
});

ipcMain.on("test", (event, data) => {
  mainWindow.webContents.send('testdata',data);
});


app.on("ready", createWindow);

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});

app.on("activate", () => {
  if (mainWindow === null) createWindow();
});
