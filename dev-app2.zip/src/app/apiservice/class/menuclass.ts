export interface menuListData {
  imagepath: any;
  foodname: string;
}
