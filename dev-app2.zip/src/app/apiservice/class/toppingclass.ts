export interface toppingListData {
  toppingname: string;
}
