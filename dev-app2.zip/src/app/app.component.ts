import { Component, ElementRef, OnInit, Renderer2 } from '@angular/core';
import { NavigationEnd, NavigationError, RouteConfigLoadStart, Router } from '@angular/router';
import { TitleService, VERSION as VERSION_ALAIN } from '@delon/theme';
import { SaveDialogSyncOptions, remote } from 'electron';
import { NzModalService } from 'ng-zorro-antd/modal';
import { VERSION as VERSION_ZORRO } from 'ng-zorro-antd/version';
import { environment } from 'src/environments/environment';
import { Settings } from './model/settings';
import { TheDb } from './model/thedb';
import * as fs from 'fs';

@Component({
  selector: 'app-root',
  template: ` <router-outlet></router-outlet> `
})
export class AppComponent implements OnInit {
  constructor(
    el: ElementRef,
    renderer: Renderer2,
    private router: Router,
    private titleSrv: TitleService,
    private modalSrv: NzModalService
  ) {
    renderer.setAttribute(el.nativeElement, 'ng-alain-version', VERSION_ALAIN.full);
    renderer.setAttribute(el.nativeElement, 'ng-zorro-version', VERSION_ZORRO.full);

  }

  ngOnInit(): void {
    let configLoad = false;
    this.router.events.subscribe(ev => {
      if (ev instanceof RouteConfigLoadStart) {
        configLoad = true;
      }
      if (configLoad && ev instanceof NavigationError) {
        this.modalSrv.confirm({
          nzTitle: `提醒`,
          nzContent: environment.production ? `应用可能已发布新版本，请点击刷新才能生效。` : `无法加载路由：${ev.url}`,
          nzCancelDisabled: false,
          nzOkText: '刷新',
          nzCancelText: '忽略',
          nzOnOk: () => location.reload()
        });
      }
      if (ev instanceof NavigationEnd) {
        this.titleSrv.setTitle();
        this.modalSrv.closeAll();
      }
    });
    
    Settings.initialize();
    if (fs.existsSync(Settings.dbPath)) {
        this.openDb(Settings.dbPath);
    } else if (Settings.hasFixedDbLocation) {
        this.createDb(Settings.dbPath);
    } else {
        this.createDb();
    }
  }

  public openDb(filename: string) {
    TheDb.openDb(filename)
        .then(() => {
            if (!Settings.hasFixedDbLocation) {
                Settings.dbPath = filename;
                Settings.write();
            }
        })
        .catch((reason) => {
            // Handle errors
            console.log('Error occurred while opening database: ', reason);
        });
}

public async createDb(filename?: string) {
    if (!filename) {
        const options: SaveDialogSyncOptions = {
            title: 'Create file',
            defaultPath: remote.app.getPath('documents'),
            filters: [
                {
                    name: 'Database',
                    extensions: ['db'],
                },
            ],
        };
        filename = remote.dialog.showSaveDialogSync(remote.getCurrentWindow(), options);
    }

    if (!filename) {
        return;
    }

    TheDb.createDb(filename)
        .then((dbPath) => {
            if (!Settings.hasFixedDbLocation) {
                Settings.dbPath = dbPath;
                Settings.write();
            }
        })
        .catch((reason) => {
            console.log(reason);
        });
}

}
