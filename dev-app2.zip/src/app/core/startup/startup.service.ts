import { Injectable} from '@angular/core';
import { MenuService, SettingsService, TitleService } from '@delon/theme';
import { NzIconService } from 'ng-zorro-antd/icon';
import { Observable,of } from 'rxjs';
import { ICONS } from '../../../style-icons';
import { ICONS_AUTO } from '../../../style-icons-auto';

/**
 * Used for application startup
 * Generally used to get the basic data of the application, like: Menu Data, User Data, etc.
 */
@Injectable()
export class StartupService {
  constructor(
    iconSrv: NzIconService,
    private menuService: MenuService,
    private settingService: SettingsService,
    private titleService: TitleService
  ) {
    iconSrv.addIcon(...ICONS_AUTO, ...ICONS);
  }

  private viaMock(): Observable<void> {
    const app: any = {
      name: `食物下单器`,
      description: `可以下单`
    };

    this.settingService.setApp(app);


      this.menuService.add([
        {
          text: '主页',
          group: true,
          children: [
            {
              text: '仪表板',
              link: '/Function/Dashboard',
              icon: { type: 'icon', value: 'appstore' }
            },
            {
              text: '食物',
              link: '/Function/Menu/MenuDetail',
              icon: { type: 'icon', value: 'file-markdown' }
            },
            {
              text: '面的种类',
              link: '/Function/Noodle/NoodleDetail',
              icon: { type: 'icon', value: 'fork' }
            },
            {
              text: '配料',
              link: '/Function/Topping/ToppingDetail',
              icon: { type: 'icon', value: 'fork' }
            },
            {
              text: '订单',
              link: '/Function/Order/OrderDetail',
              icon: { type: 'icon', value: 'shopping-cart' }
            }
          ]
        }
      ]);
    this.titleService.suffix = app.name;

    return of();
  }

  load(): Observable<void> {
    return this.viaMock();
  }
}
