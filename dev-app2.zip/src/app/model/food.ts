import { TheDb } from "./thedb";
import { Injectable } from "@angular/core";

@Injectable({
  providedIn: "root",
})
export class Food {
  public getAllFood() {
    const sql = `SELECT id,foodname,imagepath,filetype  FROM food`;
    const values = {};
    return TheDb.selectAll(sql, values);
  }

  public getAllFoodNoodle() {
    const sql = `SELECT * FROM foodnoodle`;
    const values = {};
    return TheDb.selectAll(sql, values);
  }

  public getAllFoodTopping() {
    const sql = `SELECT * FROM foodtopping`;
    const values = {};
    return TheDb.selectAll(sql, values);
  }

  public getAllOneFoodDetail(id: any) {
    const sql = `SELECT * FROM food WHERE id = $id`;
    const values = {
      $id: id,
    };
    return TheDb.selectAll(sql, values);
  }

  public getAllOneFoodNoodleDetail(id: any) {
    const sql = `SELECT foodnoodleid FROM foodnoodle WHERE foodid = $id`;
    const values = {
      $id: id,
    };
    return TheDb.selectAll(sql, values);
  }

  public getAllOneFoodToppingDetail(id: any) {
    const sql = `SELECT foodtoppingid FROM foodtopping WHERE foodid = $id`;
    const values = {
      $id: id,
    };
    return TheDb.selectAll(sql, values);
  }

  public getAllFoodNoodleDetail(id: any) {
    const sql = `SELECT id FROM noodle WHERE id = $id`;
    const values = {
      $id: id,
    };
    return TheDb.selectAll(sql, values);
  }

  public getAllFoodToppingDetail(id: any) {
    const sql = `SELECT id FROM topping WHERE id = $id`;
    const values = {
      $id: id,
    };
    return TheDb.selectAll(sql, values);
  }

  public getAllFoodNoodleNameDetail(id: any) {
    const sql = `SELECT noodlename FROM noodle WHERE id = $id`;
    const values = {
      $id: id,
    };
    return TheDb.selectAll(sql, values);
  }

  public getAllFoodToppingNameDetail(id: any) {
    const sql = `SELECT toppingname FROM topping WHERE id = $id`;
    const values = {
      $id: id,
    };
    return TheDb.selectAll(sql, values);
  }

  public getAllNoodle() {
    const sql = `SELECT * FROM noodle`;
    const values = {};
    return TheDb.selectAll(sql, values);
  }

  public getAllTopping() {
    const sql = `SELECT * FROM topping`;
    const values = {};
    return TheDb.selectAll(sql, values);
  }

  public insertFood(food: any,image:any,filetype:any) {
    const sqlfood = `INSERT INTO food (id,foodname,dry,wet,bigprice,smallprice,normalprice,imagepath,filetype) VALUES($id,$foodname,$dry,$wet,$bigprice,$smallprice,$normalprice,$imagepath,$filetype)`;
    var dry:any;
    var wet:any;
    if(food.food_dry_wet_yes==true){
      dry = 1
      wet = 1
    }else{
      dry = 0
      wet = 0
    }

    const valuesfood = {
      $id: food.food_id,
      $foodname: food.food_name,
      $dry: dry,
      $wet: wet,
      $bigprice: food.food_big_price,
      $smallprice: food.food_small_price, 
      $normalprice: food.food_normal_price,
      $imagepath: image,
      $filetype: filetype,
    };

    TheDb.insert(sqlfood, valuesfood);

    let noodle;
    const sqlfoodnoodle = `INSERT INTO foodnoodle (foodid,foodnoodleid) VALUES($foodid,$foodnoodleid)`;
    for (noodle = 0; noodle < food.food_noodle.length; noodle++) {
      const valuesnoodle = {
        $foodid: food.food_id,
        $foodnoodleid: food.food_noodle[noodle].id,
      };
      TheDb.insert(sqlfoodnoodle, valuesnoodle);
    }

    let topping;
    const sqlfoodtopping = `INSERT INTO foodtopping (foodid,foodtoppingid) VALUES($foodid,$foodtoppingid)`;
    for (topping = 0; topping < food.food_topping.length; topping++) {
      const valuestopping = {
        $foodid: food.food_id,
        $foodtoppingid: food.food_topping[topping].id,
      };
      TheDb.insert(sqlfoodtopping, valuestopping);
    }
  }

  public async updateFood(id:any,food:any,image:any,filetype:any,noodlearray:any,toppingarray:any) {
    const sqlfood = `UPDATE food SET foodname = $foodname,dry = $dry,wet = $wet,bigprice = $bigprice,smallprice = $smallprice,normalprice = $normalprice,imagepath = $imagepath,filetype = $filetype WHERE id = $id`;
    var dry:any;
    var wet:any;
    if(food.food_dry_wet_yes==true){
      dry = 1
      wet = 1
    }else{
      dry = 0
      wet = 0
    }
    const valuesfood = {
      $id: id,
      $foodname: food.food_name,
      $dry: dry,
      $wet: wet,
      $bigprice: food.food_big_price,
      $smallprice: food.food_small_price, 
      $normalprice: food.food_normal_price,
      $imagepath: image,
      $filetype: filetype,
    };
    await TheDb.update(sqlfood, valuesfood);
    

      const sqlfooddedeletenoodle = `DELETE FROM foodnoodle WHERE foodid = $id`;
      const valuesdeletenoodle = {
        $id: id,
      };
      await TheDb.delete(sqlfooddedeletenoodle, valuesdeletenoodle)
    

      const sqlfooddeletetopping = `DELETE FROM foodtopping WHERE foodid = $id`;
      const valuesdeletetopping = {
        $id: id,
      };
      await TheDb.delete(sqlfooddeletetopping, valuesdeletetopping)
    

    let noodle;
    const sqlfoodnoodle = `INSERT INTO foodnoodle (foodid,foodnoodleid) VALUES($foodid,$foodnoodleid)`;
    for (noodle = 0; noodle < noodlearray.length; noodle++) {
      const valuesnoodle = {
        $foodid: id,
        $foodnoodleid: noodlearray[noodle].id,
      };
      await TheDb.insert(sqlfoodnoodle, valuesnoodle);
    }
    
    let topping;
    const sqlfoodtopping = `INSERT INTO foodtopping (foodid,foodtoppingid) VALUES($foodid,$foodtoppingid)`;
    for (topping = 0; topping < toppingarray.length; topping++) {
      const valuestopping = {
        $foodid: id,
        $foodtoppingid: toppingarray[topping].id,
      };
      await TheDb.insert(sqlfoodtopping, valuestopping);
    }
  }

  public delete(id: any) {
    const sqlfood = `DELETE FROM food WHERE id = $id`;
    const valuesfood = {
      $id: id,
    };
    TheDb.delete(sqlfood, valuesfood)

    const sqlfoodnoodle = `DELETE FROM foodnoodle WHERE foodid = $id`;
    const valuesnoodle = {
      $id: id,
    };
    TheDb.delete(sqlfoodnoodle, valuesnoodle)

    const sqlfoodtopping = `DELETE FROM foodtopping WHERE foodid = $id`;
    const valuestopping = {
      $id: id,
    };
    TheDb.delete(sqlfoodtopping, valuestopping)
  }
}
