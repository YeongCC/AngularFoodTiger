import { TheDb } from "./thedb";
import { Injectable } from "@angular/core";

@Injectable({
  providedIn: "root",
})
export class FoodShow {
  public getAllFood() {
    const sql = `SELECT * FROM food`;
    const values = {};
    return TheDb.selectAll(sql, values);
  }

  public getAllOneFoodDetail(id: any) {
    const sql = `SELECT * FROM food WHERE id = $id`;
    const values = {
      $id: id,
    };
    return TheDb.selectAll(sql, values);
  }
  
  public getAllOneFoodNoodleDetail(id: any) {
    const sql = `SELECT foodnoodleid FROM foodnoodle WHERE foodid = $id`;
    const values = {
      $id: id,
    };
    return TheDb.selectAll(sql, values);
  }

  public getAllOneFoodToppingDetail(id: any) {
    const sql = `SELECT foodtoppingid FROM foodtopping WHERE foodid = $id`;
    const values = {
      $id: id,
    };
    return TheDb.selectAll(sql, values);
  }
  
  public getAllTopping() {
    const sql = `SELECT * FROM topping`;
    const values = {};
    return TheDb.selectAll(sql, values);
  }

  public getAllFoodNoodleNameDetail(id: any) {
    const sql = `SELECT * FROM noodle WHERE id = $id`;
    const values = {
      $id: id,
    };
    return TheDb.selectAll(sql, values);
  }

  public getAllFoodToppingNameDetail(id: any) {
    const sql = `SELECT * FROM topping WHERE id = $id`;
    const values = {
      $id: id,
    };
    return TheDb.selectAll(sql, values);
  }
}
