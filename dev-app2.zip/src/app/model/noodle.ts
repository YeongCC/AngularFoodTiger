import { TheDb } from "./thedb";
import { Injectable } from "@angular/core";

@Injectable({
  providedIn: "root",
})
export class Noodle {

  public getAll() {
    const sql = `SELECT * FROM noodle`;
    const values = {};
    return TheDb.selectAll(sql, values)
  }

  public insert(noodle: any): Promise<void> {
    const sql = `INSERT INTO noodle (noodlename) VALUES($noodlename)`;

    const values = {
      $noodlename: noodle.noodle_name,
    };
    return TheDb.insert(sql, values).then((result) => {
      if (result.changes !== 1) {
        throw new Error(
          `Expected 1 Noodle to be inserted. Was ${result.changes}`
        );
      }
    });
  }

  public delete(id: any){
    const sql1 = `DELETE FROM noodle WHERE id = $id`;
    const values1 = {
      $id: id,
    };
    TheDb.delete(sql1, values1)

    const sql2 = `DELETE FROM foodnoodle WHERE foodnoodleid = $id`;
    const values2 = {
      $id: id,
    };
    TheDb.delete(sql2, values2)
  }

}
