import { TheDb } from "./thedb";
import { Injectable } from "@angular/core";

@Injectable({
  providedIn: "root",
})
export class Noodle {

  public getAll() {
    const sql = `SELECT * FROM noodle`;
    const values = {};
    return TheDb.selectAll(sql, values)
  }

  public insert(noodle: any): Promise<void> {
    const sql = `INSERT INTO noodle (noodlename) VALUES($noodlename)`;

    const values = {
      $noodlename: noodle.noodle_name,
    };
    return TheDb.insert(sql, values).then((result) => {
      if (result.changes !== 1) {
        throw new Error(
          `Expected 1 Noodle to be inserted. Was ${result.changes}`
        );
      }
    });
  }

  public delete(id: any): Promise<void> {
    const sql = `DELETE FROM noodle WHERE id = $id`;
    const values = {
      $id: id,
    };
    return TheDb.delete(sql, values).then((result) => {
      if (result.changes !== 1) {
        throw new Error(`Expected 1 Noodle to be deleted. Was ${result.changes}`);
      }
    });
  }

}
