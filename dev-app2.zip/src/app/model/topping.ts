import { TheDb } from "./thedb";
import { Injectable } from "@angular/core";

@Injectable({
  providedIn: "root",
})
export class Topping {
  public getAll() {
    const sql = `SELECT * FROM topping`;
    const values = {};
    return TheDb.selectAll(sql, values);
  }

  public insert(topping: any): Promise<void> {
    const sql = `INSERT INTO topping (toppingname) VALUES($toppingname)`;

    const values = {
      $toppingname: topping.topping_name,
    };
    return TheDb.insert(sql, values).then((result) => {
      if (result.changes !== 1) {
        throw new Error(
          `Expected 1 Topping to be inserted. Was ${result.changes}`
        );
      }
    });
  }

  public delete(id: any) {
    const sql1 = `DELETE FROM topping WHERE id = $id`;
    const values1 = {
      $id: id,
    };
    TheDb.delete(sql1, values1);

    const sql2 = `DELETE FROM foodtopping WHERE foodtoppingid = $id`;
    const values2 = {
      $id: id,
    };
    TheDb.delete(sql2, values2);
  }
}
