import { TheDb } from "./thedb";
import { Injectable } from "@angular/core";

@Injectable({
  providedIn: "root",
})
export class Topping {

  public getAll() {
    const sql = `SELECT * FROM topping`;
    const values = {};
    return TheDb.selectAll(sql, values)
  }

  public insert(topping: any): Promise<void> {
    const sql = `INSERT INTO topping (toppingname) VALUES($toppingname)`;

    const values = {
      $toppingname: topping.topping_name,
    };
    return TheDb.insert(sql, values).then((result) => {
      if (result.changes !== 1) {
        throw new Error(
          `Expected 1 Topping to be inserted. Was ${result.changes}`
        );
      }
    });
  }

  public delete(id: any): Promise<void> {
    const sql = `DELETE FROM topping WHERE id = $id`;
    const values = {
      $id: id,
    };
    return TheDb.delete(sql, values).then((result) => {
      if (result.changes !== 1) {
        throw new Error(`Expected 1 Topping to be deleted. Was ${result.changes}`);
      }
    });
  }

}
