import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalHelper, _HttpClient } from '@delon/theme';
import { CartItem } from 'src/app/service/class/cartclass';
import { OrderService } from '../service/order.service';

@Component({
  selector: 'app-customer-cartpage',
  templateUrl: './cartpage.component.html',
  styleUrls: ["./cartpage.component.css"],
})
export class CustomerCartpageComponent implements OnInit {
  cartItems: CartItem[] = [];
  totalPrice: any;
  totalQuantity: number = 0;

  constructor(
    private http: _HttpClient, 
    private modal: ModalHelper,
    private orderService: OrderService,
    private router: Router
    ) { }

    ngOnInit(): void {
      this.listCartDetails();
    }
  
    listCartDetails() {
      let totalPrice:any;
      this.cartItems = this.orderService.cartItems;
      this.orderService.totalPrice.subscribe((data) => (totalPrice =  data)); 
      this.orderService.totalQuantity.subscribe((data) => (this.totalQuantity = data));
      this.orderService.computeCartTotals();
      this.orderService.setItems(this.cartItems)
      this.totalPrice = parseFloat(totalPrice).toFixed(2);
    }

    menu(){
       this.router.navigateByUrl("cus/secondpage");
    }

    select(){
      this.router.navigateByUrl("cus/selectpage");
    }

    removeOne(data:any){
      this.orderService.remove(data);
    }

    remove(){
      this.orderService.removeAllCart();
    }
}
