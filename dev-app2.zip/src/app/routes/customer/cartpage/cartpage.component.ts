import { Component, OnInit } from '@angular/core';
import { ModalHelper, _HttpClient } from '@delon/theme';
import { CartItem } from 'src/app/service/class/cartclass';
import { OrderService } from '../service/order.service';

@Component({
  selector: 'app-customer-cartpage',
  templateUrl: './cartpage.component.html',
})
export class CustomerCartpageComponent implements OnInit {
  cartItems: CartItem[] = [];
  totalPrice: number = 0;
  totalQuantity: number = 0;

  constructor(
    private http: _HttpClient, 
    private modal: ModalHelper,
    private orderService: OrderService
    ) { }

    ngOnInit(): void {
      this.listCartDetails();
    }
  
    listCartDetails() {
      this.cartItems = this.orderService.cartItems;
      this.orderService.totalPrice.subscribe((data) => (this.totalPrice = data)); 
      this.orderService.totalQuantity.subscribe((data) => (this.totalQuantity = data));
      this.orderService.computeCartTotals();
      this.orderService.setItems(this.cartItems)
      console.log(this.cartItems)
      console.log(this.totalPrice)
    }

}
