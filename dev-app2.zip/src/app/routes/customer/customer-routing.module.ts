import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RoutesMainpageComponent } from './mainpage/mainpage.component';
import { RoutesSecondpageComponent } from './secondpage/secondpage.component';
import { CustomerOrderpageComponent } from './orderpage/orderpage.component';
import { CustomerCartpageComponent } from './cartpage/cartpage.component';
import { CustomerSeatpageComponent } from './seatpage/seatpage.component';
import { CustomerReceiptpageComponent } from './receiptpage/receiptpage.component';
import { CustomerSelectpageComponent } from './selectpage/selectpage.component';

const routes: Routes = [
  { path: 'mainpage', component: RoutesMainpageComponent },
  { path: 'secondpage', component: RoutesSecondpageComponent },
  { path: 'orderpage/:id', component: CustomerOrderpageComponent },
  { path: 'cartpage', component: CustomerCartpageComponent },
  { path: 'seatpage', component: CustomerSeatpageComponent },
  { path: 'receiptpage/:id', component: CustomerReceiptpageComponent },
  { path: 'selectpage', component: CustomerSelectpageComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CustomerRoutingModule { }
