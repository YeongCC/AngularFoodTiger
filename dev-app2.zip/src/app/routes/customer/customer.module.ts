import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA, Type } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatTableExporterModule } from 'mat-table-exporter';
import { SharedModule } from 'src/app/shared';
import { CustomerRoutingModule } from './customer-routing.module';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { RoutesMainpageComponent } from './mainpage/mainpage.component';
import { RoutesSecondpageComponent } from './secondpage/secondpage.component';
import { CustomerOrderpageComponent } from './orderpage/orderpage.component';
import { CustomerCartpageComponent } from './cartpage/cartpage.component';
import { CustomerSeatpageComponent } from './seatpage/seatpage.component';
import { CustomerReceiptpageComponent } from './receiptpage/receiptpage.component';
import { CustomerSelectpageComponent } from './selectpage/selectpage.component';

const COMPONENTS: Type<void>[] = [
  RoutesMainpageComponent,
  RoutesSecondpageComponent
,
  CustomerOrderpageComponent,
  CustomerCartpageComponent,
  CustomerSeatpageComponent,
  CustomerReceiptpageComponent,
  CustomerSelectpageComponent];

@NgModule({
  imports: [
    SharedModule,
    CustomerRoutingModule,
    MatProgressBarModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatTableExporterModule,
    MatButtonModule,
    MatDialogModule,
    NzIconModule
  ],
  declarations: COMPONENTS,
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
})
export class CustomerModule { }
