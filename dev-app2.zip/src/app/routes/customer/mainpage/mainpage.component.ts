import { Component, OnInit } from "@angular/core";
import { ModalHelper, _HttpClient } from "@delon/theme";
import { app, ipcRenderer, remote, ipcMain } from "electron";
@Component({
  selector: "app-routes-mainpage",
  templateUrl: "./mainpage.component.html",
})
export class RoutesMainpageComponent implements OnInit {
  data: any;
  constructor(private http: _HttpClient, private modal: ModalHelper) {}

  ngOnInit(): void {
    ipcRenderer.on("testdata", (event, message) => this.data = message);
  }

  add(): void {}
}
