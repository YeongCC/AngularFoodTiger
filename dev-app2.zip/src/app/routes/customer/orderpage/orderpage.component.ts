import { Component, OnInit } from "@angular/core";
import { DomSanitizer } from "@angular/platform-browser";
import { ActivatedRoute, Router } from "@angular/router";
import { _HttpClient } from "@delon/theme";
import { FoodShow } from "src/app/model/foodshow";
import { Location } from "@angular/common";
import { FormGroup } from "@angular/forms";
import { OrderService } from "../service/order.service";
import { CartItem } from "src/app/service/class/cartclass";
import { remote } from "electron";


@Component({
  selector: "app-customer-orderpage",
  templateUrl: "./orderpage.component.html",
  styleUrls: ["./orderpage.component.css"],
})
export class CustomerOrderpageComponent implements OnInit {
  public fooddetail: any;
  image: any;
  public foodnoodle: any;
  public foodtopping: any;
  public drywet = false;
  public price = false;
  public topping = false;
  public noodle = false;
  public checkedtoppingnamesTopping: any[] = [];
  public selectedItemsListTopping: any[] = [];
  public toppingdata: any = [];
  public toppingdata1: any = [];
  public noodledata: any = [];
  ngForm!: FormGroup;
  public orderdata = {
    foodid: "",
    foodname: "",
    drywetdata: "",
    sizedata: "",
    pricedata: "",
    noodledata: "",
    toppingdata: [],
  };
  finaltoppingdata: any;
  finalpricedatasizedata: any;

  constructor(
    private router: Router,
    private activeroute: ActivatedRoute,
    private food: FoodShow,
    private sanitizer: DomSanitizer,
    private _location: Location,
    private orderService: OrderService
  ) {}

  ngOnInit(): void {
    this.getALLFooddata();
  }

  getALLFooddata() {
    this.food
      .getAllOneFoodDetail(this.activeroute.snapshot.params["id"])
      .then(async (rows: any) => {
        this.fooddetail = await rows;
        let i;
        for (i = 0; i < rows.length; i++) {
          this.orderdata.foodid = this.fooddetail[i].id;
          this.orderdata.foodname = this.fooddetail[i].foodname;
          var u8 = await new Uint8Array(
            Buffer.from(this.fooddetail[i].imagepath)
          );
          const STRING_CHAR = await u8.reduce((data, byte) => {
            return data + String.fromCharCode(byte);
          }, "");
          let base64String = await btoa(STRING_CHAR);
          this.image = await this.sanitizer.bypassSecurityTrustUrl(
            "data:" + this.fooddetail[i].filetype + ";base64," + base64String
          );
          if (
            this.fooddetail[i].bigprice == "" &&
            this.fooddetail[i].smallprice == ""
          ) {
            this.price = await true;
          } else {
            this.price = await false;
          }
          if (this.fooddetail[i].dry == 0 && this.fooddetail[i].wet == 0) {
            this.drywet = await true;
          } else {
            this.drywet = await false;
          }
        }
      });

    this.food
      .getAllOneFoodNoodleDetail(this.activeroute.snapshot.params["id"])
      .then((rowsone: any) => {
        this.foodnoodle = rowsone;
        let i;
        if (rowsone.length == 0) {
          this.noodle = true;
        } else {
          this.noodle = false;
        }
        for (i = 0; i < rowsone.length; i++) {
          this.food
            .getAllFoodNoodleNameDetail(this.foodnoodle[i].foodnoodleid)
            .then(async (rowstwo: any) => {
              await this.noodledata.push(rowstwo.shift());
            });
        }
      });

    this.food
      .getAllOneFoodToppingDetail(this.activeroute.snapshot.params["id"])
      .then((rowsone: any) => {
        this.foodtopping = rowsone;
        let i;
        if (rowsone.length == 0) {
          this.topping = true;
        } else {
          this.topping = false;
        }
        for (i = 0; i < rowsone.length; i++) {
          this.food
            .getAllFoodToppingNameDetail(this.foodtopping[i].foodtoppingid)
            .then(async (rowstwo: any) => {
              var tdata = await rowstwo;
              for (i = 0; i < rowstwo.length; i++) {
                await this.toppingdata.push({
                  toppingname: tdata[i].toppingname,
                });
                this.toppingdata1 = await this.toppingdata;
              }
            });
        }
      });
  }

  async yesnoSelect() {
    this.checkedtoppingnamesTopping = [];
    this.selectedItemsListTopping = this.toppingdata.filter((value) => {
      return value.isChecked;
    });
    let i;

    for (i = 0; i < this.selectedItemsListTopping.length; i++) {
      this.checkedtoppingnamesTopping.push(
        this.selectedItemsListTopping[i].toppingname
      );
    }

    const matches = this.toppingdata1.filter((object) =>
      this.checkedtoppingnamesTopping.includes(object.toppingname)
    );
    this.finaltoppingdata = matches;
  }

  async confirm() {
    this.orderdata.toppingdata = await this.finaltoppingdata;
    let psarr = await JSON.parse(this.finalpricedatasizedata);
    this.orderdata.pricedata = await psarr[0];
    this.orderdata.sizedata = await psarr[1];
    const theCartItem = await new CartItem(this.orderdata);
    console.log(theCartItem);
    await this.orderService.addToCart(theCartItem);
    await this.router.navigateByUrl("cus/cartpage");
  }

  clickMethod() {
    const dialog   = remote.dialog
    let options  = {
      buttons: ["取消","确定"],
      message: "你确定吗？"
     }
    dialog.showMessageBox(options).then(res => {
      if(res.response===1){
        this.confirm()
      }
      console.log(res.response)
  }).catch(err => {
      console.log(err)
  }); 
  }

  cancel() {
    this._location.back();
  }
}

