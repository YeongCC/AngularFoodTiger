import { Component, OnInit } from "@angular/core";
import { DomSanitizer } from "@angular/platform-browser";
import { Router } from "@angular/router";
import { _HttpClient } from "@delon/theme";
import { FoodShow } from "src/app/model/foodshow";
import { LoadingService } from '@delon/abc/loading';

@Component({
  selector: "app-routes-secondpage",
  templateUrl: "./secondpage.component.html",
  styleUrls: ["./secondpage.component.css"],
})
export class RoutesSecondpageComponent implements OnInit {
  public test = "";
  public foodlist: any;
  public fooddata: any = [];

  constructor(
    private router: Router, 
    private foodshow: FoodShow,
    private sanitizer: DomSanitizer,
    private loadingSrv: LoadingService
  ) {}

  ngOnInit(): void {
    // this.show();
    this.getALLMenudata();
  }

  async getALLMenudata() {
    this.foodshow.getAllFood().then(async (rows) => {
      this.foodlist = rows;
      let i;
      for (i = 0; i < rows.length; i++) {
        var u8 = await new Uint8Array(Buffer.from(this.foodlist[i].imagepath));
        const STRING_CHAR = await u8.reduce((data, byte) => {
          return data + String.fromCharCode(byte);
        }, "");
        let base64String = await btoa(STRING_CHAR);
        let image = await this.sanitizer.bypassSecurityTrustUrl(
          "data:" + this.foodlist[i].filetype + ";base64," + base64String
        );
        let big = await "价钱（大）: RM"+  this.foodlist[i].bigprice;
        let small = await "价钱（小）: RM"+ this.foodlist[i].smallprice;
        let normal = await  "价钱: RM"+ this.foodlist[i].normalprice;
        await this.fooddata.push({
          foodid:await this.foodlist[i].id,
          foodname:await this.foodlist[i].foodname,
          imageUrl:await image,
          bigprice:await this.foodlist[i].bigprice,
          smallprice:await this.foodlist[i].smallprice ,
          normalprice:await this.foodlist[i].normalprice,
          sizebig:await big ,
          sizesmall:await small ,
          sizenormal:await normal ,
        });
      }
    });
  }

  async add(id:any) {
    this.router.navigateByUrl("cus/orderpage/"+id);
  }

  show(): void {
    this.loadingSrv.open({ delay: 1000 });
    setTimeout(() => this.loadingSrv.close(), 1000 * 3);
  }

  // async add(item:any) {
  //   // ipcRenderer.send("test", this.test);
  // }
}
