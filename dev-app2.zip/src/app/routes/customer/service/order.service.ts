import { Injectable } from '@angular/core';
import { CartItem } from 'src/app/service/class/cartclass';
import { BehaviorSubject, Subject } from 'rxjs';


const item = 'item';
@Injectable({
  providedIn: 'root',
})

export class OrderService {
  cartItems: CartItem[] = [];
  totalPrice: Subject<number> = new Subject<number>();
  totalQuantity: Subject<number> = new Subject<number>();
  public menuList = new BehaviorSubject<any>([]);
  public menuItemData: any | null = null;
  public totalPriceMoney : number | undefined
  public totalItem : any | undefined

  addToCart(theCartItem: CartItem) {
    let alreadyExistsInCart: boolean = false;
    let existingCartItem: any = undefined;
    if (this.cartItems.length > 0) {
      existingCartItem = this.cartItems.find((tempCartItem) => tempCartItem.foodid === theCartItem.foodid);
    }
    alreadyExistsInCart = existingCartItem !== undefined;
    if (alreadyExistsInCart) {
      existingCartItem.qty++;
    } else {
      this.cartItems.push(theCartItem);
      this.menuList.next(this.cartItems);
      this.setItems(this.cartItems)
    }
    this.computeCartTotals();
  }

  computeCartTotals() {
    let totalPriceValue: number = 0;
    let totalQuantityValue: number = 0;

    for (let currentCartItem of this.cartItems) {
      totalPriceValue += currentCartItem.qty * currentCartItem.pricedata;
      totalQuantityValue += currentCartItem.qty;
    }
    this.totalPrice.next(totalPriceValue);
    this.totalQuantity.next(totalQuantityValue);

    this.logCartData(totalPriceValue, totalQuantityValue);
  }

  logCartData(totalPriceValue: number, totalQuantityValue: number) {
    for (let tempCartItem of this.cartItems) {
      const subTotalPrice = tempCartItem.qty * tempCartItem.pricedata;
    }
  }

  decrementQuantity(theCartItem: CartItem) {
    theCartItem.qty--;
    if (theCartItem.qty === 0) {
      this.remove(theCartItem);
    } else {
      this.computeCartTotals();
    }
  }
  remove(theCartItem: CartItem) {
    const itemIndex = this.cartItems.findIndex((tempCartItem) => tempCartItem.foodid === theCartItem.foodid);
    if (itemIndex > -1) {
      this.cartItems.splice(itemIndex, 1);
      this.computeCartTotals();
    }
      this.cartItems.map((a: any, index: any) => {
        if (theCartItem.foodid === a.menuId) {
          this.cartItems.splice(index, 1);
        }
      });
      this.menuList.next(this.cartItems);
      this.setItems(this.cartItems)
  }

  removeAllCart() {
    this.cartItems.length = 0;
    const emptyItemList: any = [];
    this.menuList.next(emptyItemList);
    this.setItems()
  }

  getMenuItems() {
    return this.menuList.asObservable();
  }

  setTotalPrice(data:any){
    this.totalPriceMoney = data
  }

  setTotalItem(data:any){
    this.totalItem = data
  }

  setItems(data?: any) {
    this.menuItemData = data || null;
    if (data) {
      const storage = localStorage;
      storage.setItem(item, JSON.stringify(data));
    } else {
      sessionStorage.removeItem(item);
      localStorage.removeItem(item);
    }
  }
}
