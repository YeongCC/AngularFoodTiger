import { Location } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd/message';
import { Food } from 'src/app/model/food';

@Component({
  selector: 'app-menu-edit-menu',
  templateUrl: './edit-menu.component.html',
  styleUrls: ['./edit-menu.component.css']
})
export class MenuEditMenuComponent {
  ngForm!: FormGroup;
  public fooddata = {
    food_name: "",
    food_big_price: "",
    food_normal_price: "",
    food_small_price: "",
    food_dry: "",
    food_wet: "",
    food_noodle: [],
    food_topping: [],
    food_image_input: "",
  };

  public noodledata: any = [];
  public noodledata1: any = [];
  public noodledata2: any = [];
  public toppingdata: any = [];
  public toppingdata1: any = [];
  public toppingdata2: any = [];
  public checkedIDsNoodle: any[] = [];
  public selectedItemsListNoodle: any[] = [];
  public checkedIDsTopping: any[] = [];
  public selectedItemsListTopping: any[] = [];
  public noodleid: any;
  public toppingid: any;
  constructor(
    private _location: Location,
    fb: FormBuilder,
    public msg: NzMessageService,
    private activeroute: ActivatedRoute,
    private food: Food,
    private router: Router,
    private sanitizer: DomSanitizer
  ) {
    this.getALLFooddata();
    this.getALLNoodledata();
    this.getALLToppingdata();
  }
  public fooddetail: any;
  public url:any;
  public file: File;
  public imageBuffer: any;
  public bufferValue:any;
  public confirmbufferValue:any;
  public confirmfiletype:any;

  onselectFile(event: any) {
    this.file = event.target.files[0];
    const allowedMimeTypes = ["image/png", "image/jpeg", "image/jpg"];
    if (this.file && allowedMimeTypes.includes(this.file.type)) {
      this.confirmfiletype = this.file.type
      var reader = new FileReader();
      reader.readAsDataURL(this.file);
      reader.onload = () => {
        this.url = reader.result as string;
        this.imageBuffer = reader.result as string
        this.bufferValue = Buffer.from(this.imageBuffer.split(',')[1], "base64");
        this.confirmbufferValue = this.bufferValue
      };
    } else {
      this.url = "./assets/tmp/img/unknown.png";
      event.target.value = null;
      alert("格式错误!");
    }
  }

  update(): void {
    if (
      this.fooddata.food_big_price != "" &&
      this.fooddata.food_small_price != "" &&
      this.fooddata.food_normal_price == ""
    ) {
      if(this.fooddata.food_small_price>=this.fooddata.food_big_price){
        alert("价格（大、小）有问题，请检查");
      }else{
        this.fooddata.food_big_price = parseFloat(
          this.fooddata.food_big_price
        ).toFixed(2);
        this.fooddata.food_small_price = parseFloat(
          this.fooddata.food_small_price
        ).toFixed(2);
        this.processdata();
      }
    } else if (
      this.fooddata.food_normal_price != "" &&
      this.fooddata.food_big_price == "" &&
      this.fooddata.food_small_price == ""
    ) {
      this.fooddata.food_normal_price = parseFloat(
        this.fooddata.food_normal_price
      ).toFixed(2);
      this.processdata();
    } else {
      alert("填写错误，请查看价钱框 !");
    }
  }

  async processdata() {
    // this.food.updateFood(this.activeroute.snapshot.params["id"],this.fooddata,this.confirmbufferValue,this.confirmfiletype)
    // alert("更新成功 !");
    // this.router.navigateByUrl("/Function/Menu/MenuDetail");
  }

  cancel(): void {
    this._location.back();
  }

  getALLNoodledata() {
    this.food.getAllNoodle().then((rows: any) => {
      this.noodledata = rows;
      this.noodledata1 = rows;
      this.noodledata2 = rows;
    });
  }

  getALLToppingdata() {
    this.food.getAllTopping().then((rows: any) => {
      this.toppingdata = rows;
      this.toppingdata1 = rows;
      this.toppingdata2 = rows;
    });
  }

  changeSelectionNoodle() {
    this.checkedIDsNoodle = [];
    this.selectedItemsListNoodle = this.noodledata1.filter((value, index) => {
      console.log("1 "+value.isChecked)
      console.log("2 "+value)
      console.log("3 "+index)
      return value.isChecked;
    });

    let i;
    for (i = 0; i < this.selectedItemsListNoodle.length; i++) {
      this.checkedIDsNoodle.push(this.selectedItemsListNoodle[i].id);
    }
    const matches = this.noodledata2.filter((object) =>
      this.checkedIDsNoodle.includes(object.id)
    );
    this.fooddata.food_noodle = matches;
    console.log("4"+ matches)
  }

  changeSelectionTopping() {
    this.checkedIDsTopping = [];
    this.selectedItemsListTopping = this.toppingdata1.filter((value, index) => {
      console.log(value.isChecked)
      return value.isChecked;
    });
    let i;
    for (i = 0; i < this.selectedItemsListTopping.length; i++) {
      this.checkedIDsTopping.push(this.selectedItemsListTopping[i].id);
    }
    const matches = this.toppingdata2.filter((object) =>
      this.checkedIDsTopping.includes(object.id)
    );
    this.fooddata.food_topping = matches;
  }

  getALLFooddata() {
    this.food
      .getAllOneFoodDetail(this.activeroute.snapshot.params["id"])
      .then(async (rows: any) => {
        this.fooddetail = rows
        let i;
        for (i = 0; i < rows.length; i++) {
          this.fooddata.food_name=await this.fooddetail[i].foodname
          this.fooddata.food_dry=await this.fooddetail[i].dry
          this.fooddata.food_wet=await this.fooddetail[i].wet
          this.fooddata.food_big_price=await this.fooddetail[i].bigprice
          this.fooddata.food_small_price=await this.fooddetail[i].smallprice
          this.fooddata.food_normal_price=await this.fooddetail[i].normalprice
          this.confirmfiletype=await this.fooddetail[i].filetype
          var u8 = new Uint8Array(Buffer.from(this.fooddetail[i].imagepath))
          const STRING_CHAR = u8.reduce((data, byte) => {
            return data + String.fromCharCode(byte)
          }, '')
          let base64String = btoa(STRING_CHAR);
          this.confirmbufferValue = this.fooddetail[i].imagepath;
          this.url = await  this.sanitizer.bypassSecurityTrustUrl('data:' + this.fooddetail[i].filetype + ';base64,' + base64String);
        }
      })

      this.food
      .getAllOneFoodNoodleDetail(this.activeroute.snapshot.params["id"])
      .then((rowsone: any) => {
        // let i
        // for (i = 0; i < rowsone.length; i++) {}
      })


      this.food
      .getAllOneFoodToppingDetail(this.activeroute.snapshot.params["id"])
      .then((rowsone: any) => {

      })
    }
}
