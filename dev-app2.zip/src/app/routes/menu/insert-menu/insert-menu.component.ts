import { Component } from "@angular/core";
import { _HttpClient } from "@delon/theme";
import { Router } from "@angular/router";
import { FormGroup } from "@angular/forms";
import { NzMessageService } from "ng-zorro-antd/message";
import { Food } from "src/app/model/food";
import { v4 as uuidv4 } from "uuid";

@Component({
  selector: "app-menu-insert-menu",
  templateUrl: "./insert-menu.component.html",
  styleUrls: ["./insert-menu.component.css"],
})
export class MenuInsertMenuComponent {
  ngForm!: FormGroup;
  public fooddata = {
    food_id: "",
    food_name: "",
    food_big_price: "",
    food_normal_price: "",
    food_small_price: "",
    food_dry_wet_yes: "",
    food_noodle: [],
    food_topping: [],
    food_image_input: "",
  };
  
  public noodledata: any = [];
  public noodledata1: any = [];
  public noodledata2: any = [];
  public toppingdata: any = [];
  public toppingdata1: any = [];
  public toppingdata2: any = [];
  public checkedIDsNoodle: any[] = [];
  public selectedItemsListNoodle: any[] = [];
  public checkedIDsTopping: any[] = [];
  public selectedItemsListTopping: any[] = [];
  public noodleid: any;
  public toppingid: any;
  public topping = false;
  public noodle = false;
  constructor(
    private router: Router,
    public msg: NzMessageService,
    private food: Food
  ) {
    this.getALLNoodledata();
    this.getALLToppingdata();
  }

  public url = "./assets/tmp/img/unknown.png";
  public file: File;
  public imageBuffer: any;
  public bufferValue:any;

  async onselectFile(event: any) {
    this.file = event.target.files[0];
    const allowedMimeTypes = ["image/png", "image/jpeg", "image/jpg"];
    if (this.file && allowedMimeTypes.includes(this.file.type)) {
      var reader = new FileReader();
      reader.readAsDataURL(this.file);
      reader.onload = () => {
        this.url = reader.result as string;
        this.imageBuffer = reader.result as string
        this.bufferValue = Buffer.from(this.imageBuffer.split(',')[1], "base64");
      };
    } else {
      this.url = "./assets/tmp/img/unknown.png";
      event.target.value = null;
      alert("格式错误!");
    }
  }

  add(): void {
    if(this.fooddata.food_image_input===""){
      alert('请上传照片')
    }else{
      if (
        this.fooddata.food_big_price != "" &&
        this.fooddata.food_small_price != "" &&
        this.fooddata.food_normal_price == ""
      ) {
        if(this.fooddata.food_small_price>=this.fooddata.food_big_price){
          alert("价格（大、小）有问题，请检查");
        }else{
          this.fooddata.food_big_price = parseFloat(
            this.fooddata.food_big_price
          ).toFixed(2);
          this.fooddata.food_small_price = parseFloat(
            this.fooddata.food_small_price
          ).toFixed(2);
          this.processdata();
        }
      } else if (
        this.fooddata.food_normal_price != "" &&
        this.fooddata.food_big_price == "" &&
        this.fooddata.food_small_price == ""
      ) {
        this.fooddata.food_normal_price = parseFloat(
          this.fooddata.food_normal_price
        ).toFixed(2);
        this.processdata();
      } else {
        alert("填写错误，请查看价钱框 !");
      }
    }
  }

  processdata() {
    this.fooddata.food_id = uuidv4();
    this.food.insertFood(this.fooddata,this.bufferValue,this.file.type)
    alert("建立成功 !");
    this.router.navigateByUrl("/Function/Menu/MenuDetail");
  }

  cancel(): void {
    this.router.navigateByUrl("/Function/Menu/MenuDetail");
  }

  getALLNoodledata() {
    this.food.getAllNoodle().then((rows: any) => {
      if(rows.length==0){
        this.noodle = true
      }else{
        this.noodle = false
      }
      this.noodledata = rows;
      this.noodledata1 = rows;
      this.noodledata2 = rows;
    });
  }

  getALLToppingdata() {
    this.food.getAllTopping().then((rows: any) => {
      if(rows.length==0){
        this.topping = true
      }else{
        this.topping = false
      }
      this.toppingdata = rows;
      this.toppingdata1 = rows;
      this.toppingdata2 = rows;
    });
  }

  changeSelectionNoodle() {
    this.checkedIDsNoodle = [];
    this.selectedItemsListNoodle = this.noodledata1.filter((value, index) => {
      return value.isChecked;
    });
    let i;
    for (i = 0; i < this.selectedItemsListNoodle.length; i++) {
      this.checkedIDsNoodle.push(this.selectedItemsListNoodle[i].id);
    }
    const matches = this.noodledata2.filter((object) =>
      this.checkedIDsNoodle.includes(object.id)
    );
    this.fooddata.food_noodle = matches;
  }

  changeSelectionTopping() {
    this.checkedIDsTopping = [];
    this.selectedItemsListTopping = this.toppingdata1.filter((value, index) => {
      return value.isChecked;
    });
    let i;
    for (i = 0; i < this.selectedItemsListTopping.length; i++) {
      this.checkedIDsTopping.push(this.selectedItemsListTopping[i].id);
    }
    const matches = this.toppingdata2.filter((object) =>
      this.checkedIDsTopping.includes(object.id)
    );
    this.fooddata.food_topping = matches;
  }
}
