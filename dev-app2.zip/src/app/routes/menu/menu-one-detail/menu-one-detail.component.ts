import { Component, OnInit } from "@angular/core";
import { DomSanitizer } from "@angular/platform-browser";
import { Router, ActivatedRoute } from "@angular/router";
import { _HttpClient } from "@delon/theme";
import { Food } from "src/app/model/food";

@Component({
  selector: "app-menu-menu-one-detail",
  templateUrl: "./menu-one-detail.component.html",
})
export class MenuMenuOneDetailComponent implements OnInit {
  constructor(
    private router: Router,
    private activeroute: ActivatedRoute,
    private food: Food,
    private sanitizer: DomSanitizer
  ) { }
  public fooddetail: any;
  image: any;
  public foodnoodle: any;
  public foodtopping: any;
  public foodnoodledetail: any = [];
  public foodnoodlename: any;
  public foodtoppingdetail: any = [];
  public foodtoppingname: any;
  public dry = false;
  public wet = false;
  public price = false;
  public topping = false;
  public noodle = false;
  ngOnInit(): void {
    this.getALLFooddata();
  }
  getALLFooddata() {
    this.food
      .getAllOneFoodDetail(this.activeroute.snapshot.params["id"])
      .then((rows: any) => {
        this.fooddetail = rows
        let i;
        for (i = 0; i < rows.length; i++) {
          var u8 = new Uint8Array(Buffer.from(this.fooddetail[i].imagepath))
          const STRING_CHAR = u8.reduce((data, byte) => {
            return data + String.fromCharCode(byte)
          }, '')
          let base64String = btoa(STRING_CHAR);
          this.image = this.sanitizer.bypassSecurityTrustUrl('data:' + this.fooddetail[i].filetype + ';base64,' + base64String);
          if (this.fooddetail[i].bigprice == "" && this.fooddetail[i].smallprice == "") {
            this.price = true
          } else {
            this.price = false
          }
          if(this.fooddetail[i].dry==0){
            this.dry =true
          }else{
            this.dry =false
          }
          if(this.fooddetail[i].wet==0){
            this.wet =true
          }else{
            this.wet =false
          }
        }
      })

    this.food
      .getAllOneFoodNoodleDetail(this.activeroute.snapshot.params["id"])
      .then((rowsone: any) => {
        this.foodnoodle = rowsone
        let i
        if(rowsone.length==0){
          this.noodle = true
        }else{
          this.noodle = false
        }
        for (i = 0; i < rowsone.length; i++) {
          this.food.getAllFoodNoodleNameDetail(this.foodnoodle[i].foodnoodleid).then((rowstwo: any) => {
            this.foodnoodledetail.push(rowstwo.shift())
          })
        }
        this.foodnoodlename = this.foodnoodledetail
      });


    this.food
      .getAllOneFoodToppingDetail(this.activeroute.snapshot.params["id"])
      .then((rowsone: any) => {
        this.foodtopping = rowsone
        let i
        if(rowsone.length==0){
          this.topping = true
        }else{
          this.topping = false
        }
        for (i = 0; i < rowsone.length; i++) {
          this.food.getAllFoodToppingNameDetail(this.foodtopping[i].foodtoppingid).then((rowstwo: any) => {
            this.foodtoppingdetail.push(rowstwo.shift())
          })
        }
        this.foodtoppingname = this.foodtoppingdetail
      });

  }

  editDetail(id: string) {
    this.router.navigateByUrl("Function/Menu/editMenu/"+id);
  }

  back(): void {
    this.router.navigateByUrl("Function/Menu/MenuDetail");
  }
}
