import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { MenuEditMenuComponent } from './edit-menu/edit-menu.component';
import { MenuInsertMenuComponent } from './insert-menu/insert-menu.component';
import { MenuMenuDetailComponent } from './menu-detail/menu-detail.component';
import { MenuMenuOneDetailComponent } from './menu-one-detail/menu-one-detail.component';

const routes: Routes = [
  { path: 'insertMenu', component: MenuInsertMenuComponent },
  { path: 'MenuDetail', component: MenuMenuDetailComponent },
  { path: 'editMenu/:id', component: MenuEditMenuComponent },
  { path: 'MenuOneDetail/:id', component: MenuMenuOneDetailComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MenuRoutingModule {}
