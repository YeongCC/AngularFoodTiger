import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA, Type } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatTableExporterModule } from 'mat-table-exporter';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { SharedModule } from 'src/app/shared';
import { MenuEditMenuComponent } from './edit-menu/edit-menu.component';
import { MenuInsertMenuComponent } from './insert-menu/insert-menu.component';
import { MenuMenuDetailComponent } from './menu-detail/menu-detail.component';
import { MenuMenuOneDetailComponent } from './menu-one-detail/menu-one-detail.component';
import { MenuRoutingModule } from './menu-routing.module';

const COMPONENTS: Array<Type<void>> = [MenuInsertMenuComponent, MenuMenuDetailComponent, MenuEditMenuComponent, MenuMenuOneDetailComponent];

@NgModule({
  imports: [
    SharedModule,
    MenuRoutingModule,
    MatProgressBarModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatTableExporterModule,
    MatButtonModule,
    MatDialogModule,
    NzIconModule
  ],
  declarations: COMPONENTS,
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
})
export class MenuModule {}
