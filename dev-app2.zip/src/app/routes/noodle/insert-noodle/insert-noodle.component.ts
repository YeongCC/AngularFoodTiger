import { Component } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { _HttpClient } from '@delon/theme';
import { NzMessageService } from "ng-zorro-antd/message";
import { Noodle } from 'src/app/model/noodle';

@Component({
  selector: 'app-noodle-insert-noodle',
  templateUrl: './insert-noodle.component.html',
})
export class NoodleInsertNoodleComponent {
  ngForm!: FormGroup;
  public noodledata = {
    noodle_name: "",
  };

  constructor(
    private router: Router,
    public msg: NzMessageService,
    private noodle: Noodle
  ) {}


  add(): void {
    this.createNoodle(this.noodledata)
  }

  cancel(): void {
    this.router.navigateByUrl("/Function/Noodle/NoodleDetail");
  }

  private createNoodle(data:any) {
    this.noodle.insert(data);
    alert("建立成功");
    this.router.navigateByUrl('/Function/Noodle/NoodleDetail');
  }

}
