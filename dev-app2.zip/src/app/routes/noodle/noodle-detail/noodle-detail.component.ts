import { Component, ViewChild, AfterViewInit } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { _HttpClient } from '@delon/theme';
import { noodleListData } from 'src/app/apiservice/class/noodle';
import { Noodle } from 'src/app/model/noodle';

@Component({
  selector: 'app-noodle-noodle-detail',
  templateUrl: './noodle-detail.component.html',
  styleUrls: ['./noodle-detail.component.css']
})
export class NoodleNoodleDetailComponent implements AfterViewInit {
  displayedColumns: string[] = ['number','noodlename','actions'];
  dataSource = new MatTableDataSource<noodleListData>();

  @ViewChild(MatPaginator)
  paginator!: MatPaginator;
  @ViewChild(MatSort)
  sort!: MatSort;

  constructor(
    private router: Router,
    private noodle: Noodle
     ) {}

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.getALLNoodledata();
  }

  getALLNoodledata() {
    this.noodle.getAll().then((rows) => {
      this.dataSource.data = rows as noodleListData[]
    });
  }

  add(): void {
    this.router.navigateByUrl('Function/Noodle/insertNoodle');
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  deleteNoodle(id: string) {
    this.noodle.delete(id);
    this.getALLNoodledata();
    alert("删除成功");
  }


}
