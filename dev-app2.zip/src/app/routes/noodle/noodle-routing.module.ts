import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NoodleNoodleDetailComponent } from './noodle-detail/noodle-detail.component';
import { NoodleInsertNoodleComponent } from './insert-noodle/insert-noodle.component';

const routes: Routes = [

  { path: 'NoodleDetail', component: NoodleNoodleDetailComponent },
  { path: 'insertNoodle', component: NoodleInsertNoodleComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class NoodleRoutingModule { }
