import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA, Type } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatTableExporterModule } from 'mat-table-exporter';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { OrderRoutingModule } from './order-routing.module';
import { OrderOrderDetailComponent } from './order-detail/order-detail.component';
import { SharedModule } from 'src/app/shared';

const COMPONENTS: Type<void>[] = [
  OrderOrderDetailComponent];

@NgModule({
  imports: [
    SharedModule,
    OrderRoutingModule,
    MatProgressBarModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatTableExporterModule,
    MatButtonModule,
    MatDialogModule,
    NzIconModule
  ],
  declarations: COMPONENTS,
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
})
export class OrderModule { }
