import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { _HttpClient } from "@delon/theme";
import { app, ipcRenderer, remote } from "electron";
import { MultiMonitor } from "electron-multi-monitor";
let BrowserWindow = remote.BrowserWindow;


@Component({
  selector: "app-routes-index-page",
  templateUrl: "./index-page.component.html",
})
export class RoutesIndexPageComponent{
  
  constructor(private router: Router) {
    remote.Menu.setApplicationMenu(null);
  }

  customer() {
    this.router.navigateByUrl("/mainpage");
    this.router.navigate(['/secondpage']);
  }

  admin() {
    this.router.navigateByUrl("/Admin/Login");
  }
}
