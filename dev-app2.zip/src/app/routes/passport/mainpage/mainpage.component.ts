import { Component, OnInit } from '@angular/core';
import { ModalHelper, _HttpClient } from '@delon/theme';

@Component({
  selector: 'app-routes-mainpage',
  templateUrl: './mainpage.component.html',
})
export class RoutesMainpageComponent implements OnInit {

  constructor(private http: _HttpClient, private modal: ModalHelper) { }

  ngOnInit(): void { 
    
  }

  add(): void {

  }

}
