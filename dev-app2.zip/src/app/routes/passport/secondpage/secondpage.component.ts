import { Component, OnInit } from '@angular/core';
import { ModalHelper, _HttpClient } from '@delon/theme';

@Component({
  selector: 'app-routes-secondpage',
  templateUrl: './secondpage.component.html',
})
export class RoutesSecondpageComponent implements OnInit {

  constructor(private http: _HttpClient, private modal: ModalHelper) { }

  ngOnInit(): void { }

  add(): void {

  }

}
