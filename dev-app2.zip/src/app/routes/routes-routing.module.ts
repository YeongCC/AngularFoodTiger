import { NgModule, NO_ERRORS_SCHEMA } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { environment } from "src/environments/environment";
import { LayoutBasicComponent } from "../layout/basic/basic.component";
import { DashboardComponent } from "./dashboard/dashboard.component";
import { RoutesIndexPageComponent } from "./passport/index-page/index-page.component";
import { UserLoginComponent } from "./passport/login/login.component";

const routes: Routes = [
  {
    path: "",
    data: { title: "首页" },
    component: RoutesIndexPageComponent,
  },
  {
    path: "Admin",
    children: [
      {
        path: "Login",
        component: UserLoginComponent,
        data: { title: "登录" },
      },
    { path: 'customer', loadChildren: () => import('./customer/customer.module').then((m) => m.CustomerModule) },],
  },
  {
    path: "Function",
    component: LayoutBasicComponent,
    children: [
      {
        path: "Dashboard",
        component: DashboardComponent,
        data: { title: "仪表盘" },
      },
      {
        path: "Menu",
        loadChildren: () =>
          import("./menu/menu.module").then((m) => m.MenuModule),
      },
      {
        path: "Noodle",
        loadChildren: () =>
          import("./noodle/noodle.module").then((m) => m.NoodleModule),
      },
      {
        path: "Topping",
        loadChildren: () =>
          import("./topping/topping.module").then((m) => m.ToppingModule),
      },
      {
        path: "Order",
        loadChildren: () =>
          import("./order/order.module").then((m) => m.OrderModule),
      },
    ],
  },
  { 
    path: "cus", 
    loadChildren: () =>
    import("./customer/customer.module").then((m) => m.CustomerModule),
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      useHash: environment.useHash,
      scrollPositionRestoration: "top",
    })
  ],
  exports: [RouterModule],
  schemas: [NO_ERRORS_SCHEMA],
})
export class RouteRoutingModule {}
