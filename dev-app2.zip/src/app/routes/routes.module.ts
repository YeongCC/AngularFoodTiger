import { NgModule, Type } from '@angular/core';
import { SharedModule } from '../shared';


// dashboard pages
import { DashboardComponent } from './dashboard/dashboard.component';
import { RoutesIndexPageComponent } from './passport/index-page/index-page.component';
// passport pages
import { UserLoginComponent } from './passport/login/login.component';
import { RoutesMainpageComponent } from './passport/mainpage/mainpage.component';
import { RoutesSecondpageComponent } from './passport/secondpage/secondpage.component';
import { RouteRoutingModule } from './routes-routing.module';



const COMPONENTS: Array<Type<void>> = [
  DashboardComponent,
  UserLoginComponent,
  RoutesIndexPageComponent,
  RoutesMainpageComponent,
  RoutesSecondpageComponent];

@NgModule({
  imports: [SharedModule, RouteRoutingModule],
  declarations: COMPONENTS
})
export class RoutesModule {}
