import { Component } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { Router } from "@angular/router";
import { _HttpClient } from "@delon/theme";
import { NzMessageService } from "ng-zorro-antd/message";
import { Topping } from "src/app/model/topping";
@Component({
  selector: "app-topping-insert-topping",
  templateUrl: "./insert-topping.component.html",
})
export class ToppingInsertToppingComponent {
  ngForm!: FormGroup;
  public toppingdata = {
    topping_name: "",
  };

  constructor(
    private router: Router,
    public msg: NzMessageService,
    private topping: Topping
  ) {}

  add(): void {
    this.createTopping(this.toppingdata)
  }

  cancel(): void {
    this.router.navigateByUrl("/Function/Topping/ToppingDetail");
  }
  
  private createTopping(data:any) {
    this.topping.insert(data);
    alert("建立成功");
    this.router.navigateByUrl('/Function/Topping/ToppingDetail');
  }
}
