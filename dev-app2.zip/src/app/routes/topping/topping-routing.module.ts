import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ToppingInsertToppingComponent } from './insert-topping/insert-topping.component';
import { ToppingToppingDetailComponent } from './topping-detail/topping-detail.component';

const routes: Routes = [

  { path: 'insertTopping', component: ToppingInsertToppingComponent },
  { path: 'ToppingDetail', component: ToppingToppingDetailComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ToppingRoutingModule { }
