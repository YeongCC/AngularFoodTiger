export class CartItem {
  foodid: string;
  foodname: string;
  drywetdata: string;
  sizedata: string;
  pricedata: number;
  noodledata:string;
  toppingdata:any;
  qty:any;

  constructor(data: any) {
    this.foodid = data.foodid
    this.foodname = data.foodname;
    this.drywetdata = data.drywetdata;
    this.sizedata = data.sizedata;
    this.pricedata = data.pricedata;
    this.noodledata = data.noodledata;
    this.toppingdata = data.toppingdata;
    this.qty = 1;
  }
}
