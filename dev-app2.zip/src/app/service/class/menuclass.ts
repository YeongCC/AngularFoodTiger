export interface menuListData {
  id:any;
  imagepath: any;
  foodname: string;
}
