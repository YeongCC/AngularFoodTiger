BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "user" (
	"id"	INTEGER,
	"username"	TEXT NOT NULL,
	"password"	TEXT,
	PRIMARY KEY("id")
);
CREATE TABLE IF NOT EXISTS "food" (
	"id"	TEXT,
	"foodname"	TEXT NOT NULL UNIQUE,
	"dry"	INTEGER,
	"wet"	INTEGER,
	"bigprice"	TEXT,
	"smallprice"	TEXT,
	"normalprice"	TEXT,
	"imagepath"	BLOB,
	"filetype"	TEXT
);
CREATE TABLE IF NOT EXISTS "noodle" (
	"id"	INTEGER PRIMARY KEY AUTOINCREMENT,
	"noodlename"	TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS "topping" (
	"id"	INTEGER PRIMARY KEY AUTOINCREMENT,
	"toppingname"	TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS "foodnoodle" (
	"foodid"	TEXT NOT NULL,
	"foodnoodleid"	TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS "foodtopping" (
	"foodid"	TEXT NOT NULL,
	"foodtoppingid"	TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS "orderhistory" (
	"id"	INTEGER PRIMARY KEY AUTOINCREMENT,
	"takeawayid"	TEXT,
	"eathereid"	TEXT,
	"fooddetail"	TEXT NOT NULL,
	"price"	TEXT NOT NULL,
	"date"	INTEGER NOT NULL
);
COMMIT;
