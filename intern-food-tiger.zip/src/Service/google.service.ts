import { BadRequestException, Injectable } from '@nestjs/common';
import * as firebase from 'firebase-admin';
import { SignInUserDto } from 'src/auth/dto/user.dto';
import { Response } from 'express';
@Injectable()
export class GoogleService {
    private defaultApp: any;
    constructor(
        ) {
            if (!firebase.apps.length) {
                this.defaultApp = firebase.initializeApp({
                    credential: firebase.credential.cert(process.env.GOOGLE_APPLICATION_CREDENTIALS_1),
                    databaseURL: process.env.FIRE_DATABASE_URL
                });
             }else {
                this.defaultApp = firebase.app(); // if already initialized, use that one
             }
        }

   async verifyUser(idToken:any){
    var data
    const verify = await this.defaultApp.auth().verifyIdToken(idToken).then((res) => {
        data=res.phone_number
    })
    .catch((error) => {
        throw new BadRequestException(error.message);
    });
     return data
   } 
   
   async verifyUserWallet(idToken:any){
    var data
    const verify = await this.defaultApp.auth().verifyIdToken(idToken).then((res) => {
        data=res.phone_number
    })
    .catch((error) => {
        throw new BadRequestException(error.message);
    });
     return data
   } 

   async signIn(signInUserDto: SignInUserDto,response: Response){
    const expiresIn = 60 * 60 * 24 * 5 * 1000;
    this.defaultApp
          .auth()
          .createSessionCookie(signInUserDto.idToken, { expiresIn })
          .then(
            (sessionCookie) => {
              const options = { maxAge: expiresIn, httpOnly: true };
              response.cookie("session", sessionCookie, options);
            return response.status(200).send({
                message: "success",
                user:{
                    token:signInUserDto.idToken,
                    time: +new Date()
                }
            });
            }
            ,
            (error) => {
            return response.status(401).send("UNAUTHORIZED REQUEST!");
            }
          );
   }
}
