import { Module } from '@nestjs/common';
import { MenusModule } from './menu/menu.module';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { OrderModule } from './order/order.module';
import { ConfigModule } from '@nestjs/config';
import configuration from './configuration';
import { pathOr } from 'ramda';
import { MongodbModule } from './Service/mongodb.module';
import { UserModule } from './auth/user.module';
import { KitchenModule } from './kitchen/kitchen.module';
import { WalletModule } from './wallet/Wallet/wallet.module';
import { ProcessModule } from './wallet/Process/process.module';
import { PaymentGatewayModule } from './wallet/Process/Payment_gateway/payment-gateway.module';

const isProduction = pathOr('dev', ['env', 'NODE_ENV'], process).toString() === 'production';

@Module({
  imports: [
    ConfigModule.forRoot({
      load: [configuration],
      ignoreEnvFile: isProduction,
      isGlobal: true,
      cache: true,
    }),
   MongodbModule,
   MenusModule,
   UserModule, 
   KitchenModule,
   OrderModule,
   WalletModule,
   ProcessModule,
   PaymentGatewayModule
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
