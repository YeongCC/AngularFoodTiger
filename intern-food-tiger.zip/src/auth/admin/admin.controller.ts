import { Body, Controller, Get, Param, Patch, Post ,Delete, Res, NotFoundException, HttpStatus, BadRequestException, Req, UnauthorizedException} from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import { JwtService } from "@nestjs/jwt";
import { Response, Request } from 'express';
import { AdminService } from './admin.service';
import { AdminsRepository } from './admin.respository';
import { CreateAdminDto, LoginAdminDto, UpdateAdminDto } from '../dto/admin.dto';
import { User } from '../schema/user.schema';

@Controller('apad')
export class AdminController {

    constructor(
    private readonly adminService: AdminService, 
    private readonly adminRepository: AdminsRepository, 
    private jwtService: JwtService
    ) {}

    @Get(':user_email')
    async geta(@Param('user_email') user_email: string): Promise<User> {
      return this.adminService.getloginAdmin(user_email);
    }

    @Get('user/detail/:userId')
    async getUser(@Param('userId') userId: string) {
      return this.adminService.getUserByUserId(userId);
    }

    @Get('admin/detail/:userId')
    async getAdmin(@Param('userId') userId: string){
      return this.adminService.getAdminByAdminId(userId);
    }

    // @Roles(Role.SUPERADMIN)
    // @UseGuards(RolesGuard)
    @Get('/admin/alladmins')
    getAdmins(): Promise<User[]> {
        return this.adminService.getAdmins();
    }

    @Post('create')
    async createAdmin(@Body() createAdminDto: CreateAdminDto,@Req() request: Request){
      try {
        const cookie = request.cookies['jwt'];
        const data = await this.jwtService.verifyAsync(cookie);
        if (!data) {
          throw new UnauthorizedException();
        }
        return this.adminService.createAdmin(createAdminDto.user_email ,createAdminDto.user_name , createAdminDto.user_password)
      } catch (e) {
          throw new UnauthorizedException();
      }
    }


    @Post('login')
    async login(@Body() loginAdminDto: LoginAdminDto, @Res({passthrough: true}) response: Response){
      const admin = await this.adminService.getloginAdmin(loginAdminDto.user_email);
      if (!admin) {
          throw new BadRequestException('Admin ID invalid credentials');
      }
      if (!await bcrypt.compare(loginAdminDto.user_password, admin.user_password)) {
          throw new BadRequestException('Admin Password invalid credentials');
      }
      const jwt = await this.jwtService.signAsync({adminId: admin.userId});
      response.cookie('jwt', jwt, {httpOnly: true});
      const data = await this.jwtService.verifyAsync(jwt);
      const adminAccount = await this.adminService.getloginAdminByAdminId(data['adminId']);
      return {
          message: 'success',
          user: {
            token:  jwt,
            name: adminAccount.user_name,
            email: adminAccount.user_email,
            id:  adminAccount.userId,
            role: adminAccount.role,
            time: +new Date(),
          },
      };
    }
  
    @Get('admin/coo')
    async admin(@Req() request: Request) {
        try {
            const cookie = request.cookies['jwt'];
            const data = await this.jwtService.verifyAsync(cookie);
            if (!data) {
                throw new UnauthorizedException();
            }
            const admin = await this.adminService.getloginAdminByAdminId(data['adminId']);
            const {user_password, ...result} = admin;
            return result;
        } catch (e) {
            throw new UnauthorizedException();
        }
     }

    @Post('logout')
    async logout(@Res({passthrough: true}) response: Response) {
        response.clearCookie('jwt');
        return {
            message: 'success'
        }
    }

    @Patch(':userId')
    async updateAdmin(@Param('userId') userId: string, @Body() updateAdminDto: UpdateAdminDto,@Req() request: Request){
      try {
        const cookie = request.cookies['jwt'];
        const data = await this.jwtService.verifyAsync(cookie);
        if (!data) {
          throw new UnauthorizedException();
        }
        return this.adminService.updateAdmin(userId, updateAdminDto);
      } catch (e) {
          throw new UnauthorizedException();
      }
    }

    @Delete('delete/:userId')
    async deleteUser(@Res() res,@Param('userId') userId: string,@Req() request: Request) {
      try {
        const cookie = request.cookies['jwt'];
        const data = await this.jwtService.verifyAsync(cookie);
        if (!data) {
          throw new UnauthorizedException();
        }
        if (!userId) {
          throw new NotFoundException('User does not exist');
        }
        const User = await this.adminRepository.remove(userId);
        return res.status(HttpStatus.OK).json({message: 'Admin has been deleted', User});
      } catch (e) {
          throw new UnauthorizedException();
      }
    }

}
