import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { FilterQuery, Model } from "mongoose";
import { User } from "../schema/user.schema";

@Injectable()
export class AdminsRepository {
    constructor(@InjectModel(User.name) private adminModel: Model<User>) {}

    async findOne(adminFilterQuery: FilterQuery<User>): Promise<User> {
        return this.adminModel.findOne(adminFilterQuery);
    }

    async find(adminsFilterQuery: FilterQuery<User>): Promise<User[]> {
        return this.adminModel.find(adminsFilterQuery)
    }

    async findByRole_Id(adminsFilterQuery: FilterQuery<User>){
        const user = await this.adminModel.find(adminsFilterQuery);
        const finaluser = user.shift()  
        return finaluser
    }

    async findByRole(adminsFilterQuery: FilterQuery<User>): Promise<User[]> {
        return this.adminModel.find(adminsFilterQuery);
    }

    async create(admin: User): Promise<User> {
        const newAdmin = new this.adminModel(admin);
        return newAdmin.save()
    }

    async findOneAndUpdate(adminFilterQuery: FilterQuery<User>, admin: Partial<User>): Promise<User> {
        return this.adminModel.findOneAndUpdate(adminFilterQuery, admin, { new: true });
    }

    async remove(userId: string): Promise<any> {
        const User = await this.adminModel.findByIdAndRemove(userId);
        return User;
      }
}