import { Injectable } from '@nestjs/common';
import { AdminsRepository } from './admin.respository';
import * as bcrypt from 'bcrypt';
import { v4 as uuidv4 } from 'uuid';
import { Role } from "../dto/role.dto";
import { DateTime } from 'luxon';
import { UpdateAdminDto } from '../dto/admin.dto';
import { User } from '../schema/user.schema';

@Injectable()
export class AdminService {
    constructor(private readonly adminsRepository: AdminsRepository) {}

    async getloginAdmin(user_email: any): Promise<User> {
        return this.adminsRepository.findOne({ user_email })
    }

    async getloginAdminByAdminId(userId: any): Promise<User> {
        return this.adminsRepository.findOne({ userId })
    }

    async getUserByUserId(userId: any){
       const user = await this.adminsRepository.findByRole_Id({role: "user",userId:userId});
       const create = DateTime.fromMillis(user.created_time).setZone('Asia/Kuala_Lumpur').toFormat("MM/dd/yyyy H:mm");
       const update = DateTime.fromMillis(user.updated_time).setZone('Asia/Kuala_Lumpur').toFormat("MM/dd/yyyy H:mm"); 
         return {
                    userId:  user.userId,
                    user_account: user.user_account,
                    user_phone: user.user_phone,
                    user_email: user.user_email,
                    user_name: user.user_name,
                    user_address: user.user_address,
                    user_area: user.user_area,
                    created_time: create,
                    updated_time: update
          }
    }

    async getAdminByAdminId(userId: any) {
        const admin = await  this.adminsRepository.findByRole_Id({role: "admin",userId:userId});
        const create = DateTime.fromMillis(admin.created_time).setZone('Asia/Kuala_Lumpur').toFormat("MM/dd/yyyy H:mm");
        const update = DateTime.fromMillis(admin.updated_time).setZone('Asia/Kuala_Lumpur').toFormat("MM/dd/yyyy H:mm");
        return {
                    userId: admin.userId,
                    user_account: admin.user_account,
                    user_phone: admin.user_phone,
                    user_email: admin.user_email,
                    user_name: admin.user_name,
                    user_address: admin.user_address,
                    user_area: admin.user_area,
                    role:admin.role,
                    created_time: create,
                    updated_time: update
            }
    }

    async getAdmins(): Promise<User[]> {
     return this.adminsRepository.findByRole({role: "admin"});
    }

    async createAdmin(user_email: string, user_name:string, user_password: string){
        const hashpassword = await bcrypt.hash(user_password,12);
        const admin = await this.adminsRepository.create({
            userId: uuidv4(),
            user_account : user_email,
            user_phone : '',
            user_email,
            user_name,
            user_address : '',
            user_country_code : '',
            user_country_name : '',
            user_country_currency : '',
            user_password : hashpassword,
            user_area : '',
            role:Role.ADMIN,
            created_time:DateTime.now(),
            updated_time: DateTime.now()
        })
        return {
            user: {
                user_email: admin.user_email,
                user_name: admin.user_name,
              }
        };
    }

    async updateAdmin(userId: string, adminUpdates: UpdateAdminDto){
        const hashpassword = await bcrypt.hash(adminUpdates.user_password,12);
        const newupdateadmin = {
           user_name: adminUpdates.user_name,
           user_password: hashpassword,
           updated_time: DateTime.now()
        }
        const admin = await this.adminsRepository.findOneAndUpdate({ userId }, newupdateadmin);
        return {
            user: {
                user_email: admin.user_email,
                user_name: admin.user_name,
              }
        };
    }
    
}
