import { IsEmail, IsPhoneNumber } from "class-validator";

export class CreateAdminDto {
    @IsEmail()
    user_email: string;
    user_name:string;
    user_password:string;
    role:string;
}

export class UpdateAdminDto {
    user_name:string;
    user_password: string;
}

export class LoginAdminDto {
    @IsEmail()
    user_email: string;
    user_password: string;
}

export class CreateDeliverDto {
    @IsEmail()
    user_email: string;
    user_name:string;
    @IsPhoneNumber('MY')
    user_phone:string;
    user_password: string;
}

export class UpdateDeliverDto {
    user_name:string;
    user_password: string;
}

export class LoginDeliverDto {
    @IsEmail()
    user_email: string;
    user_password: string;
}