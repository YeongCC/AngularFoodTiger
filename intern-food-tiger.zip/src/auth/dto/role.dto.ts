export enum Role {
    SUPERADMIN = 'superadmin',
    ADMIN = 'admin',
    USER = 'user',
}
  