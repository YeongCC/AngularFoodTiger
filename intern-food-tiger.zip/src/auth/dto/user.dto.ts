import { IsCurrency, IsEmail, IsPhoneNumber } from "class-validator";

export class IndentityUserDto {
    user_account: string;
    user_name:string;
    @IsPhoneNumber('MY')
    user_phone:string;
    @IsEmail()
    user_email:string;
    user_address:string;
    user_area:string;
    user_country_code: string;
    user_country_name: string;
    user_country_currency: string;
    idToken:string;
}

export class UpdateUserDto {
    user_account:string;
    user_name:string;
    user_address:string;
    idToken:string;
}

export class LoginUserDto {
    user_account:string;
    user_password:string;
}

export class VerifyUserDto {
    prefix:string;
    @IsPhoneNumber('MY')
    number:string;
    code: string;
    name: string;
    currency: string;
}

export class SignInUserDto {
    idToken:string;
    type:string;
}

