import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from 'mongoose';

export type UserDocument = User & Document;

@Schema()
export class User {
    @Prop()
    userId: string;

    @Prop({unique:true})
    user_account: string;

    @Prop()
    user_phone: string;
    
    @Prop()
    user_email: string;

    @Prop()
    user_name: string;

    @Prop()
    user_address: string;

    @Prop()
    user_country_code: string;
    
    @Prop()
    user_country_name: string;
    
    @Prop()
    user_country_currency: string;

    @Prop()
    user_password: string;

    @Prop()
    user_area: string;

    @Prop()
    role:string;
    
    @Prop()
    created_time:number;

    @Prop()
    updated_time:number;
}

export const UserSchema = SchemaFactory.createForClass(User);