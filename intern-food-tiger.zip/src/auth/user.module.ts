import { Module } from '@nestjs/common';
import { MongooseModule } from "@nestjs/mongoose";
import { JwtModule } from "@nestjs/jwt";
import { UserController } from './user/user.controller';
import { AdminController } from './admin/admin.controller';
import { User, UserSchema } from './schema/user.schema';
import { UserService } from './user/user.service';
import { UsersRepository } from './user/user.repository';
import { AdminService } from './admin/admin.service';
import { AdminsRepository } from './admin/admin.respository';
import { GoogleService } from 'src/Service/google.service';
import { Wallet, WalletSchema } from 'src/wallet/Wallet/schema/wallet.schema';
import { WalletService } from 'src/wallet/Wallet/wallet.service';
import { WalletsRepository } from 'src/wallet/Wallet/wallet.respository';
import { WalletModule } from 'src/wallet/Wallet/wallet.module';

@Module({
    imports: [
    MongooseModule.forFeature([{ name: User.name, schema: UserSchema }]),
    MongooseModule.forFeature([{ name: Wallet.name, schema: WalletSchema }]),
    JwtModule.register({
        secret: 'secret',
        signOptions: {expiresIn: '2d'}
    }),
    WalletModule],
    controllers: [UserController,AdminController],
    providers: [UserService,UsersRepository,AdminService,AdminsRepository,GoogleService]
})
export class UserModule {}
