import { Body, Controller, Get, Param, Patch, Post , Res, BadRequestException } from '@nestjs/common';
import { UserService } from './user.service';
import { Response } from 'express';
import { User } from '../schema/user.schema';
import { IndentityUserDto, SignInUserDto, UpdateUserDto, VerifyUserDto } from '../dto/user.dto';
import { GoogleService } from 'src/Service/google.service';

@Controller('apus')
export class UserController {
    constructor(
        private readonly userService: UserService, 
        private readonly googleService:GoogleService
        ) {}

    @Get('detail/:user_account/:idToken')
    async getUser(@Param('idToken') idToken: string,@Param('user_account') user_account: string){    
        const verify =await this.googleService.verifyUser(idToken)
        if(verify!=user_account){
            throw new BadRequestException("Cannot Authorized");
        }
        const user = await this.userService.getloginUser(user_account)
        return user        
    }

    @Get('/user/detail/:userId')
    getOneUsers(@Param('userId') userId: string){
        return this.userService.getUserByUserId(userId);
    }

    @Get('/user/allusers')
    getUsers(): Promise<User[]> {
        return this.userService.getUsers();
    }

    @Post('identity')
    async createUser(@Body() indentityUserDto: IndentityUserDto){
        const verify =await this.googleService.verifyUser(indentityUserDto.idToken)
        if(verify!= indentityUserDto.user_account){
            throw new BadRequestException("Cannot Authorized");
        }
        const user = await this.userService.identityUser(
            indentityUserDto.user_account,
            indentityUserDto.user_phone,
            indentityUserDto.user_email,
            indentityUserDto.user_name,
            indentityUserDto.user_address,
            indentityUserDto.user_country_code,
            indentityUserDto.user_country_name,
            indentityUserDto.user_country_currency,
            );
        return user   
    }

    @Patch('identity/update')
    async updateUser(@Body() updateUserDto: UpdateUserDto){
        const verify =await this.googleService.verifyUser(updateUserDto.idToken)
        if(verify!=updateUserDto.user_account){
            throw new BadRequestException("Cannot Authorized");
        }
        const user = await this.userService.updateUser(updateUserDto.user_account, updateUserDto);
        return user   
    }

    @Post('verify')
    async verifyUser(@Body() verifyUserDto: VerifyUserDto) {
        if (verifyUserDto.number.length == 8 || verifyUserDto.number.length == 9) {
            return {
                res : true,
                account: verifyUserDto.prefix+verifyUserDto.number,
                number: "0"+verifyUserDto.number,
                code: verifyUserDto.code,
                name: verifyUserDto.name,
                currency: verifyUserDto.currency
            }
          } else if (verifyUserDto.number.length == 10 || verifyUserDto.number.length == 11) {
            var newnumber = verifyUserDto.number.substring(1);
            return {
                res : true,
                account: verifyUserDto.prefix+newnumber,
                number: "0"+newnumber,
                code: verifyUserDto.code,
                name: verifyUserDto.name,
                currency: verifyUserDto.currency
            }
          } else {
            return {
                res : false
            }
          }
    }

    @Post('SignIn')
    async signIn(@Body() signInUserDto: SignInUserDto, @Res() response: Response) {
     return   this.googleService.signIn(signInUserDto,response)
    }

    @Post('sessionLogout')
    async sessionLogout(@Res({passthrough: true}) response: Response) {
        response.clearCookie("session");
        return {
            message: 'success'
        }
    }
}