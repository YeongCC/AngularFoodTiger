import { Injectable } from '@nestjs/common';
import { UsersRepository } from './user.repository';
import { v4 as uuidv4 } from 'uuid';
import { User } from '../schema/user.schema';
import { Role } from '../dto/role.dto';
import { UpdateUserDto } from '../dto/user.dto';
import { DateTime } from 'luxon';

@Injectable()
export class UserService {
    constructor(private readonly usersRepository: UsersRepository) {}

    async getloginUser(user_account: any){
        const user = await this.usersRepository.findOne({ user_account })
        if(user){
            return {
                user: {
                    user_account:  user.user_account,
                    user_phone: user.user_phone,
                    user_email: user.user_email,
                    user_name: user.user_name,
                    user_address: user.user_address,
                  }
            };
        }
    }

    async getUserByUserId(userId: any): Promise<User> {
        return this.usersRepository.findOne({ userId })
    }
    
    async getUsers(): Promise<User[]> {
        return this.usersRepository.findByRole({role: "user"});
    }

    async identityUser(user_account: string,user_phone: string,user_email: string,user_name:string,user_address:string,user_country_code:string,user_country_name:string,user_country_currency:string) {
        const user = await this.usersRepository.create({
            userId: uuidv4(),
            user_account,
            user_phone,
            user_email,
            user_name,
            user_address,
            user_country_code,
            user_country_name,
            user_country_currency,
            user_password : '',
            user_area : '',
            role:Role.USER,
            created_time:DateTime.now(),
            updated_time: DateTime.now()
        })
        return {
            user: {
                user_account:  user.user_account,
                user_phone: user.user_phone,
                user_email: user.user_email,
                user_name: user.user_name,
                user_address: user.user_address,
              }
        };
    }

    async updateUser(user_account: string, userUpdates: UpdateUserDto){
        const newupdateuser = {
            user_name: userUpdates.user_name,
            user_address: userUpdates.user_address,
            updated_time: DateTime.now()
         }
        const user = await this.usersRepository.findOneAndUpdate({ user_account }, newupdateuser);
        return {
            user: {
                user_account:  user.user_account,
                user_phone: user.user_phone,
                user_email: user.user_email,
                user_name: user.user_name,
                user_address: user.user_address
              }
        };
    }

}
