import { pathOr } from 'ramda';

export default async () => {
  return {
    port: parseInt(process.env.PORT, 10) || 3000,
    mongodb: {
      uri: pathOr('mongodb://localhost/mongodb', ['env', 'MONGODB_URI'], process),
    },
  };
};
