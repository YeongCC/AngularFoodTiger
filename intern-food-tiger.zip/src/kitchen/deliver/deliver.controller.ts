import { Body, Controller, Get, Param, Patch, Post ,Delete, Res, NotFoundException, HttpStatus, BadRequestException, Req, UnauthorizedException, UseGuards} from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import { JwtService } from "@nestjs/jwt";
import { Response, Request } from 'express';
import { DeliversRepository } from './deliver.respository';
import { DeliverService } from './deliver.service';
import { Kitchen } from '../schema/kitchen.schema';
import { CreateDeliverDto, LoginDeliverDto, UpdateDeliverDto } from '../dto/deliver.dto';


@Controller('apidel')
export class DeliverController {

    constructor(private readonly deliverService: DeliverService, private readonly deliverRepository: DeliversRepository, private jwtService: JwtService) {}

    @Get(':kitchen_user_account')
    async getUser(@Param('kitchen_user_account') kitchen_user_account: string): Promise<Kitchen> {
      return this.deliverService.getloginDeliver(kitchen_user_account);
    }
  
    @Get('/deliver/alldelivers')
    getDelivers(): Promise<Kitchen[]> {
        return this.deliverService.getDelivers();
    }


    @Post('register')
    async createDeliver(@Body() createDeliverDto: CreateDeliverDto){
        return this.deliverService.createDeliver(createDeliverDto)
    }


    @Post('login')
    async login(@Body() loginDeliverDto: LoginDeliverDto, @Res({passthrough: true}) response: Response){
      const deliver = await this.deliverService.getloginDeliver(loginDeliverDto.kitchen_user_account);
      if (!deliver) {
          throw new BadRequestException('invalid credentials');
      }
      if (!await bcrypt.compare(loginDeliverDto.kitchen_user_password, deliver.kitchen_user_password)) {
          throw new BadRequestException('invalid credentials');
      }
      const jwt = await this.jwtService.signAsync({kitchenId: deliver.kitchenId});
      response.cookie('jwt', jwt, {httpOnly: true});
      return {
          message: 'success'
      };
    }
  
    @Get('deliver/coo')
    async user(@Req() request: Request) {
        try {
            const cookie = request.cookies['jwt'];

            const data = await this.jwtService.verifyAsync(cookie);

            if (!data) {
                throw new UnauthorizedException();
            }
            const deliver = await this.deliverService.getloginDeliverByDeliverId(data['kitchenId']);
            const {kitchen_user_password, ...result} = deliver;
            return result;
        } catch (e) {
            throw new UnauthorizedException();
        }
     }

    @Post('logout')
    async logout(@Res({passthrough: true}) response: Response) {
        response.clearCookie('jwt');
        return {
            message: 'success'
        }
    }

    @Patch(':kitchenId')
    async updateDeliver(@Param('kitchenId') kitchenId: string, @Body() updateDeliverDto: UpdateDeliverDto){
        return this.deliverService.updateDeliver(kitchenId, updateDeliverDto);
    }

    @Delete('delete/:kitchenId')
    async deleteDeliver(@Res() res,@Param('kitchenId') kitchenId: string,) {
      if (!kitchenId) {
        throw new NotFoundException('Deliver Man ID does not exist');
      }
      const Deliver = await this.deliverRepository.remove(kitchenId);
      return res.status(HttpStatus.OK).json({message: 'Deliver Man has been deleted', Deliver});
    }

}
