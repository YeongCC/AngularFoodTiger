import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { FilterQuery, Model } from "mongoose";
import { Kitchen } from "../schema/kitchen.schema";

@Injectable()
export class DeliversRepository {
    constructor(@InjectModel(Kitchen.name) private deliverModel: Model<Kitchen>) {}

    async findOne(deliverFilterQuery: FilterQuery<Kitchen>): Promise<Kitchen> {
        return this.deliverModel.findOne(deliverFilterQuery);
    }

    async findByRole(deliversFilterQuery: FilterQuery<Kitchen>): Promise<Kitchen[]> {
        return this.deliverModel.find(deliversFilterQuery)
    }

    async create(deliver: Kitchen): Promise<Kitchen> {
        const newDeliver = new this.deliverModel(deliver);
        return newDeliver.save()
    }

    async findOneAndUpdate(deliverFilterQuery: FilterQuery<Kitchen>, deliver: Partial<Kitchen>): Promise<Kitchen> {
        return this.deliverModel.findOneAndUpdate(deliverFilterQuery, deliver, { new: true });
    }

    async remove(deliverId: string): Promise<any> {
        const Deliver = await this.deliverModel.findByIdAndRemove(deliverId);
        return Deliver;
      }
}