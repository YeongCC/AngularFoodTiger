import { Injectable } from '@nestjs/common';
import { DeliversRepository } from './deliver.respository';
import * as bcrypt from 'bcrypt';
import { Role } from '../dto/role.dto';
import { v4 as uuidv4 } from 'uuid';
import { DateTime } from 'luxon';
import { Kitchen } from '../schema/kitchen.schema';
import { CreateDeliverDto, UpdateDeliverDto } from '../dto/deliver.dto';

@Injectable()
export class DeliverService {
    constructor(private readonly deliversRepository: DeliversRepository) {}

    async getloginDeliver(kitchen_user_account: any): Promise<Kitchen> {
        return this.deliversRepository.findOne({ kitchen_user_account })
    }

    async getloginDeliverByDeliverId(userId: any): Promise<Kitchen> {
        return this.deliversRepository.findOne({ userId })
    }

    async getDelivers(): Promise<Kitchen[]> {
        return this.deliversRepository.findByRole({role: "deliver"});
    }

    async createDeliver(createDeliverDto : CreateDeliverDto){
        const hashpassword = await bcrypt.hash(createDeliverDto.kitchen_user_password,12);
        const deliver = await this.deliversRepository.create({
            kitchenId: uuidv4(),
            kitchen_user_account : createDeliverDto.kitchen_user_email,
            kitchen_name : createDeliverDto.kitchen_name,
            kitchen_user_name : createDeliverDto.kitchen_user_name,
            kitchen_user_email : createDeliverDto.kitchen_user_email,
            kitchen_user_phone : createDeliverDto.kitchen_user_phone,
            kitchen_user_password : hashpassword,
            kitchen_user_address : createDeliverDto.kitchen_user_address,
            kitchen_user_location : createDeliverDto.kitchen_user_location,
            role: Role.KITCHEN,
            created_time:DateTime.now(),
            updated_time: DateTime.now()
        })
        return deliver
    }

    async updateDeliver(kitchenId: string, deliverUpdates: UpdateDeliverDto){
        const hashpassword = await bcrypt.hash(deliverUpdates.kitchen_user_password,12);
        const newupdatedeliver = {
           kitchen_user_name: deliverUpdates.kitchen_user_name,
           kitchen_user_password: hashpassword,
           updated_time: DateTime.now()
        }
        const deliver = await this.deliversRepository.findOneAndUpdate({ kitchenId }, newupdatedeliver);
        return deliver
    }
    
}
