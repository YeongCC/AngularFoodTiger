import { IsEmail } from "class-validator";

export class CreateDeliverDto {
    kitchen_name: string;
    kitchen_user_name: string;
    @IsEmail()
    kitchen_user_email: string;
    kitchen_user_phone: string;
    kitchen_user_password : string;
    kitchen_user_address: string;
    kitchen_user_location: string;
}

export class UpdateDeliverDto {
    kitchen_user_name:string;
    kitchen_user_password: string;
}

export class LoginDeliverDto {
    @IsEmail()
    kitchen_user_account: string;
    kitchen_user_password: string;
}