import { IsEmail } from "class-validator";

export class CreateKicthenDto {
    kitchen_name: string;
    kitchen_user_name: string;
    @IsEmail()
    kitchen_user_email: string;
    kitchen_user_phone: string;
    kitchen_user_password : string;
    kitchen_user_address: string;
    kitchen_user_location: string;
}

export class UpdateKicthenDto {
    kitchen_user_name:string;
    kitchen_user_password: string;
}

export class LoginKicthenDto {
    @IsEmail()
    kitchen_user_account: string;
    kitchen_user_password: string;
}