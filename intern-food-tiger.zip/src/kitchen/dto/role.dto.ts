export enum Role {
    KITCHEN = 'kitchen',
    DELIVER = 'deliver',
  }
  