import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { MongooseModule } from '@nestjs/mongoose';
import { DeliverController } from './deliver/deliver.controller';
import { DeliversRepository } from './deliver/deliver.respository';
import { DeliverService } from './deliver/deliver.service';
import { KitchenController } from './kitchen/kitchen.controller';
import { KitchensRepository } from './kitchen/kitchen.respository';
import { KitchenService } from './kitchen/kitchen.service';
import { Kitchen, KitchenSchema } from './schema/kitchen.schema';


@Module({
    imports: [
        MongooseModule.forFeature([{ name: Kitchen.name, schema: KitchenSchema }]),
        JwtModule.register({
            secret: 'secret',
            signOptions: {expiresIn: '2d'}
        })
    ],
    controllers: [KitchenController,DeliverController],  
    providers: [KitchenService, KitchensRepository,DeliverService, DeliversRepository]
})
export class KitchenModule {}
