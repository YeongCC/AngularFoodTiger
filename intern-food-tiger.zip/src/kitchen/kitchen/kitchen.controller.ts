import { Body, Controller, Get, Param, Patch, Post ,Delete, Res, NotFoundException, HttpStatus, BadRequestException, Req, UnauthorizedException, UseGuards} from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import { JwtService } from "@nestjs/jwt";
import { Response, Request } from 'express';
import { KitchenService } from './kitchen.service';
import { KitchensRepository } from './kitchen.respository';
import { Kitchen } from '../schema/kitchen.schema';
import { CreateKicthenDto, LoginKicthenDto, UpdateKicthenDto } from '../dto/kitchen.dto';




@Controller('kitchen')
export class KitchenController {

    constructor(private readonly kitchenService: KitchenService, private readonly kitchenRepository: KitchensRepository, private jwtService: JwtService) {}

    @Get(':kitchen_user_account')
    async getUser(@Param('kitchen_user_account') kitchen_user_account: string): Promise<Kitchen> {
      return this.kitchenService.getloginKicthen(kitchen_user_account);
    }
  

    @Post('register')
    async createDeliver(@Body() createDeliverDto: CreateKicthenDto){
        return this.kitchenService.createKicthen(createDeliverDto)
    }


    @Post('login')
    async login(@Body() loginKithcenDto: LoginKicthenDto, @Res({passthrough: true}) response: Response){
      const kitchen = await this.kitchenService.getloginKicthen(loginKithcenDto.kitchen_user_account);
      if (!kitchen) {
          throw new BadRequestException('invalid credentials');
      }
      if (!await bcrypt.compare(loginKithcenDto.kitchen_user_password, kitchen.kitchen_user_password)) {
          throw new BadRequestException('invalid credentials');
      }
      const jwt = await this.jwtService.signAsync({kitchenId: kitchen.kitchenId});
      response.cookie('jwt', jwt, {httpOnly: true});
      return {
          message: 'success'
      };
    }
  
    @Get('deliver/coo')
    async user(@Req() request: Request) {
        try {
            const cookie = request.cookies['jwt'];
            const data = await this.jwtService.verifyAsync(cookie);
            if (!data) {
                throw new UnauthorizedException();
            }
            const kitchen = await this.kitchenService.getloginKicthenByKicthenId(data['kitchenId']);
            const {kitchen_user_password, ...result} = kitchen;
            return result;
        } catch (e) {
            throw new UnauthorizedException();
        }
     }

    @Post('logout')
    async logout(@Res({passthrough: true}) response: Response) {
        response.clearCookie('jwt');
        return {
            message: 'success'
        }
    }

    @Patch(':kitchenId')
    async updateDeliver(@Param('kitchenId') kitchenId: string, @Body() updateDeliverDto: UpdateKicthenDto){
        return this.kitchenService.updateKicthen(kitchenId, updateDeliverDto);
    }

    @Delete('delete/:kitchenId')
    async deleteKicthen(@Res() res,@Param('kitchenId') kitchenId: string,) {
      if (!kitchenId) {
        throw new NotFoundException('Kicthen does not exist');
      }
      const Deliver = await this.kitchenRepository.remove(kitchenId);
      return res.status(HttpStatus.OK).json({message: 'Kicthen has been deleted', Deliver});
    }

}
