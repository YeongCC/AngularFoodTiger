import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { FilterQuery, Model } from "mongoose";
import { Kitchen } from "../schema/kitchen.schema";


@Injectable()
export class KitchensRepository {
    constructor(@InjectModel(Kitchen.name) private kitchenModel: Model<Kitchen>) {}

    async findOne(kitchenFilterQuery: FilterQuery<Kitchen>): Promise<Kitchen> {
        return this.kitchenModel.findOne(kitchenFilterQuery);
    }

    async findByName(kitchenFilterQuery: FilterQuery<Kitchen>): Promise<Kitchen[]> {
        return this.kitchenModel.find(kitchenFilterQuery);
    }

    async find(kitchensFilterQuery: FilterQuery<Kitchen>): Promise<Kitchen[]> {
        return this.kitchenModel.find(kitchensFilterQuery)
    }

    async create(kitchen: Kitchen): Promise<Kitchen> {
        const newKitchen = new this.kitchenModel(kitchen);
        return newKitchen.save()
    }

    async findOneAndUpdate(kitchenFilterQuery: FilterQuery<Kitchen>, kitchen: Partial<Kitchen>): Promise<Kitchen> {
        return this.kitchenModel.findOneAndUpdate(kitchenFilterQuery, kitchen, { new: true });
    }

    async remove(kitchenId: string): Promise<any> {
        const Kitchen = await this.kitchenModel.findByIdAndRemove(kitchenId);
        return Kitchen;
    }
}