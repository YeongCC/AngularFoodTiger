import { Injectable } from '@nestjs/common';
import { KitchensRepository } from './kitchen.respository';
import { v4 as uuidv4 } from 'uuid';
import { DateTime } from 'luxon';
import * as bcrypt from 'bcrypt';
import { Kitchen } from '../schema/kitchen.schema';
import { CreateKicthenDto, UpdateKicthenDto } from '../dto/kitchen.dto';
import { Role } from '../dto/role.dto';


@Injectable()
export class KitchenService {
    constructor(private readonly kitchensRepository: KitchensRepository) {}

    async getloginKicthen(kitchen_user_account: any): Promise<Kitchen> {
        return this.kitchensRepository.findOne({ kitchen_user_account })
    }

    async getloginKicthenByKicthenId(kitchenId: any): Promise<Kitchen> {
        return this.kitchensRepository.findOne({ kitchenId })
    }

    async createKicthen(createKicthenDto : CreateKicthenDto){
        const hashpassword = await bcrypt.hash(createKicthenDto.kitchen_user_password,12);
        const kitchen = await this.kitchensRepository.create({
            kitchenId: uuidv4(),
            kitchen_user_account : createKicthenDto.kitchen_user_email,
            kitchen_name : createKicthenDto.kitchen_name,
            kitchen_user_name : createKicthenDto.kitchen_user_name,
            kitchen_user_email : createKicthenDto.kitchen_user_email,
            kitchen_user_phone : createKicthenDto.kitchen_user_phone,
            kitchen_user_password : hashpassword,
            kitchen_user_address : createKicthenDto.kitchen_user_address,
            kitchen_user_location : createKicthenDto.kitchen_user_location,
            role: Role.KITCHEN,
            created_time:DateTime.now(),
            updated_time: DateTime.now()
        })
        return kitchen
    }

    async updateKicthen(kitchenId: string, kitchenUpdates: UpdateKicthenDto){
        const hashpassword = await bcrypt.hash(kitchenUpdates.kitchen_user_password,12);
        const newupdatedeliver = {
           kitchen_user_name: kitchenUpdates.kitchen_user_name,
           kitchen_user_password: hashpassword,
           updated_time: DateTime.now()
        }
        const kitchen = await this.kitchensRepository.findOneAndUpdate({ kitchenId }, newupdatedeliver);
        return kitchen
    }

}
