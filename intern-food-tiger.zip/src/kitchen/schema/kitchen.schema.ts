import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from 'mongoose';

export type KitchenDocument = Kitchen & Document;

@Schema()
export class Kitchen {
    @Prop()
    kitchenId: string;

    @Prop({unique:true})
    kitchen_user_account: string;

    @Prop()
    kitchen_name: string;

    @Prop()
    kitchen_user_name: string;

    @Prop()
    kitchen_user_email: string;

    @Prop()
    kitchen_user_phone: string;

    @Prop()
    kitchen_user_password: string;

    @Prop()
    kitchen_user_address: string;

    @Prop()
    kitchen_user_location: string;

    @Prop()
    role: string;

    @Prop()
    created_time:number;

    @Prop()
    updated_time:number;
}

export const KitchenSchema = SchemaFactory.createForClass(Kitchen);