import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import * as cookieParser from "cookie-parser";
import { pathOr } from 'ramda';
import { Logger, ValidationPipe } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as firebase from 'firebase-admin';

const isProduction = pathOr('dev', ['env', 'NODE_ENV'], process).toString() === 'production';
async function bootstrap() {
  const app = await NestFactory.create(AppModule, {
    logger: isProduction
      ? ['log', 'error', 'warn']
      : ['verbose', 'debug', 'log', 'error', 'warn'],
  });
  app.use(cookieParser());
  app.useGlobalPipes(new ValidationPipe());
  const configService = app.get(ConfigService);
  const port = configService.get<number | string>('port');
  await app.listen(port, () => {
    if (isProduction) {
      Logger.log('Listening Production at http://localhost:' + port);
    } else {
      Logger.log('Listening Dev at http://localhost:' + port);
    }
  });
}
bootstrap();
