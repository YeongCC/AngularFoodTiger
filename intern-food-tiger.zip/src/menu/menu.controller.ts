import { Body, Controller, Get, Param, Patch, Post ,Delete, Res, UploadedFile, UseInterceptors, NotFoundException, HttpStatus, BadRequestException} from '@nestjs/common';
import { MenuService } from './menu.service';
import { CreateMenuDto, UpdateMenuDto } from './dto/menu.dto';
import { Menu } from './schema/menu.schema';
import { FileInterceptor } from '@nestjs/platform-express';
import { memoryStorage } from 'multer';
import { MenusRepository } from './menu.repository';
import { CloudStorageService } from 'src/Service/cloud-storage.service';

@Controller('menus')
export class MenuController {
    constructor(private readonly menuService: MenuService,private readonly menuRepository: MenusRepository, private cloudStorageService: CloudStorageService) {}

    @Get(':menuId')
    async getMenu(@Param('menuId') menuId: string): Promise<Menu> {
      return this.menuService.getMenuById(menuId);
    }
  
    @Get()
    async getMenus(): Promise<Menu[]> {
        return this.menuService.getMenus();
    }

    @Post()
    async createMenu(@Body() createMenuDto: CreateMenuDto): Promise<Menu> {
        return this.menuService.createMenu(createMenuDto.menu_name,createMenuDto.menu_detail,createMenuDto.menu_price,createMenuDto.menu_image_path,createMenuDto.menu_image)
    }
  
    @Patch(':menuId')
    async updateMenu(@Param('menuId') menuId: string, @Body() updateMenuDto: UpdateMenuDto): Promise<Menu> {
        return this.menuService.updateMenu(menuId, updateMenuDto);
    }
  
    @Post('upload/google')
    @UseInterceptors(
      FileInterceptor('file',{
        storage: memoryStorage(),
        limits: { fileSize: 10485760 }, // 2MB --- 2*2^20
        fileFilter: (req, file, callback) => {
          return file.mimetype.match(/image\/(jpg|jpeg|png|gif)$/)
            ? callback(null, true)
            : callback(new BadRequestException('Only image files are allowed'), false);
        }
    }))
    uploadFile(@UploadedFile() file){
    const filegoogle =this.cloudStorageService.uploadFile(file, '');
      return filegoogle;
    }

    @Delete('delete/:menuId')
    async deleteMenu(@Res() res,@Param('menuId') menuId: string,) {
      if (!menuId) {
        throw new NotFoundException('Menu ID does not exist');
      }
      const Menu = await this.menuRepository.remove(menuId);
      return res.status(HttpStatus.OK).json({message: 'Menu has been deleted', Menu});
    }

    @Delete('image/google/delete/:imagename')
    async deleteUploadFile(@Res() res,@Param('imagename') imagename: string,) {
      const Menu = await this.cloudStorageService.removeFile(imagename);
      return res.status(HttpStatus.OK).json({message: 'Menu Image has been deleted', Menu});
    }

    @Get('customer/allmenu')
    async getCuaAllMenus(): Promise<Menu[]> {
      return this.menuService.getMenus();
    }
    
}
