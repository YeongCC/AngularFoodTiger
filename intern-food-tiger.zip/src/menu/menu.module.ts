import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { Menu, MenuSchema } from "./schema/menu.schema";
import { MenuController } from "./menu.controller";
import { MenusRepository } from "./menu.repository";
import { MenuService } from "./menu.service";
import { CloudStorageService } from "src/Service/cloud-storage.service";

@Module({
    imports: [MongooseModule.forFeature([{ name: Menu.name, schema: MenuSchema }])],
    controllers: [MenuController],
    providers: [MenuService, MenusRepository,CloudStorageService]
})
export class MenusModule {}