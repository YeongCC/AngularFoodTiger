import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { FilterQuery, Model } from "mongoose";

import { Menu } from "./schema/menu.schema";

@Injectable()
export class MenusRepository {
    constructor(@InjectModel(Menu.name) private menuModel: Model<Menu>) {}

    async findOne(menuFilterQuery: FilterQuery<Menu>): Promise<Menu> {
        return this.menuModel.findOne(menuFilterQuery);
    }

    async find(menusFilterQuery: FilterQuery<Menu>): Promise<Menu[]> {
        return this.menuModel.find(menusFilterQuery)
    }

    async create(menu: Menu): Promise<Menu> {
        const newMenu = new this.menuModel(menu);
        return newMenu.save()
    }

    async findOneAndUpdate(menuFilterQuery: FilterQuery<Menu>, menu: Partial<Menu>): Promise<Menu> {
        return this.menuModel.findOneAndUpdate(menuFilterQuery, menu, { new: true });
    }

    async remove(menuId: string): Promise<any> {
        const Menu = await this.menuModel.findByIdAndRemove(menuId);
        return Menu;
      }
}