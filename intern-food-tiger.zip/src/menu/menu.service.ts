import { Injectable } from '@nestjs/common';
import { MenusRepository } from './menu.repository';
import { v4 as uuidv4 } from 'uuid';
import { Menu } from "./schema/menu.schema";
import { UpdateMenuDto } from './dto/menu.dto';
import { DateTime } from 'luxon';

@Injectable()
export class MenuService {
    constructor(private readonly menusRepository: MenusRepository) {}

    async getMenuById(menuId: string): Promise<Menu> {
        return this.menusRepository.findOne({ menuId })
    }

    async getMenus(): Promise<Menu[]> {
        return this.menusRepository.find({});
    }

    async createMenu(menu_name: string, menu_detail: string, menu_price: number,menu_image_path:string ,menu_image:string): Promise<Menu> {
        return this.menusRepository.create({
            menuId: uuidv4(),
            menu_name,
            menu_detail,
            menu_price,
            menu_image_path,
            menu_image,
            created_time:DateTime.now(),
            updated_time: DateTime.now()
        })
    }

    async updateMenu(menuId: string, menuUpdates: UpdateMenuDto): Promise<Menu> {
        return this.menusRepository.findOneAndUpdate({ menuId }, menuUpdates);
    }

}
