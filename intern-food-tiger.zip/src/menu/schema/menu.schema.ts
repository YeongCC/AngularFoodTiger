import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from 'mongoose';

export type MenuDocument = Menu & Document;

@Schema()
export class Menu {
    @Prop()
    menuId: string;

    @Prop({unique:true})
    menu_name: string;

    @Prop()
    menu_detail: string;

    @Prop()
    menu_price: number;

    @Prop()
    menu_image_path: string;

    @Prop()
    menu_image: string;

    @Prop()
    created_time:number;

    @Prop()
    updated_time:number;
}

export const MenuSchema = SchemaFactory.createForClass(Menu);