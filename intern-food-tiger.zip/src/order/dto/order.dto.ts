export class CreateOrderDto {
    user_account: string;
    wallet_currency: string;
    amount: string;
    user_name: string;
    user_phone: string;
    user_address: string;
    menu: any;
    total_price: string;
    payement_way: string;
}

