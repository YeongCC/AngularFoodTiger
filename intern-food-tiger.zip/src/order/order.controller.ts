import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { CreateOrderDto } from './dto/order.dto';
import { OrderService } from './order.service';
import { Order } from "./schema/order.schema";

@Controller('orders')
export class OrderController {
    constructor(private readonly orderService: OrderService) {}

    @Get()
    async getOrders(): Promise<Order[]> {
        return this.orderService.getOrders();
    }
    
    @Get('detailOne/:user_account/:orderId')
    async getOneOrder(@Param('user_account') user_account: string,@Param('orderId') orderId: string){
      return this.orderService.getOneOrderByUserAcc(user_account,orderId);
    }

    @Get('detail/:user_account')
    async getOrdersByUser(@Param('user_account') user_account: string){
      return this.orderService.getOrderByUserAcc(user_account);
    }

    @Post('createOrder')
    async createOrder(@Body() createOrderDto: CreateOrderDto){
        return this.orderService.checkPaymentWay(createOrderDto)
    }
}
