import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { WalletModule } from 'src/wallet/Wallet/wallet.module';
import { OrderController } from './order.controller';
import { OrdersRepository } from './order.respository';
import { OrderService } from './order.service';
import { Order, OrderSchema } from './schema/order.schema';

@Module({
    imports: [
        MongooseModule.forFeature([{ name: Order.name, schema: OrderSchema }]),
        WalletModule
    ],
    controllers: [OrderController],
    providers: [OrderService, OrdersRepository],
    exports: [OrderService,OrdersRepository]
})
export class OrderModule {}
