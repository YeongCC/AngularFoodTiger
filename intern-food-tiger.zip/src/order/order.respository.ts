import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { FilterQuery, Model } from "mongoose";
import { Order } from "./schema/order.schema";

@Injectable()
export class OrdersRepository {
    constructor(@InjectModel(Order.name) private orderModel: Model<Order>) {}

    async findOneOrderUserAcc(orderFilterQuery: FilterQuery<Order>){
        const order = await this.orderModel.find(orderFilterQuery);
        const finalorder = order.shift()  
        return finalorder
    }
        

    async findByAcc(orderFilterQuery: FilterQuery<Order>){
        return this.orderModel.find(orderFilterQuery);
    }

    async find(ordersFilterQuery: FilterQuery<Order>): Promise<Order[]> {
        return this.orderModel.find(ordersFilterQuery)
    }

    async create(order: Order): Promise<Order> {
        const newOrder = new this.orderModel(order);
        return newOrder.save()
    }

    async findOneAndUpdate(orderFilterQuery: FilterQuery<Order>, order: Partial<Order>): Promise<Order> {
        return this.orderModel.findOneAndUpdate(orderFilterQuery, order, { new: true });
    }

    async remove(orderId: string): Promise<any> {
        const Order = await this.orderModel.findByIdAndRemove(orderId);
        return Order;
    }
}