import { BadRequestException, Injectable } from '@nestjs/common';
import { DateTime } from 'luxon';
import { WalletService } from 'src/wallet/Wallet/wallet.service';
import { v4 as uuidv4 } from 'uuid';
import { CreateOrderDto } from './dto/order.dto';
import { OrdersRepository } from './order.respository';
import { Order } from "./schema/order.schema";

@Injectable()
export class OrderService {
    constructor(
        private readonly ordersRepository: OrdersRepository,
        private readonly walletService: WalletService
    ) { }

    async getOneOrderByUserAcc(user_account: any, orderId: any) {
        const order = await this.ordersRepository.findOneOrderUserAcc({ user_account: user_account, orderId: orderId })
        const ordertime = await DateTime.fromMillis(order.order_time).setZone('Asia/Kuala_Lumpur').toFormat("MM/dd/yyyy H:mm");
        return {
            orderId: order.orderId,
            user_name: order.user_name,
            user_phone: order.user_phone,
            user_account: order.user_account,
            user_address: order.user_address,
            menu: order.menu,
            total_price: order.total_price,
            payement_way: order.payement_way,
            order_time: ordertime
        }
    }

    async getOrderByUserAcc(user_account: any) {
        const order = await this.ordersRepository.findByAcc({ user_account: user_account })
        return order
    }

    async getOrders(): Promise<Order[]> {
        return this.ordersRepository.find({});
    }

    async createOrder(
        user_name: string,
        user_phone: string,
        user_account: string,
        user_address: string,
        menu: any,
        total_price: string,
        payement_way: string) {
        const order = await this.ordersRepository.create({
            orderId: uuidv4(),
            user_name,
            user_phone,
            user_account,
            user_address,
            menu: [menu],
            total_price,
            payement_way,
            order_time: DateTime.now()
        })
        const ordertime = DateTime.fromMillis(order.order_time).setZone('Asia/Kuala_Lumpur').toFormat("MM/dd/yyyy H:mm");
        return {
            user_name: order.user_name,
            user_phone: order.user_phone,
            user_address: order.user_address,
            menu: order.menu,
            total_price: order.total_price,
            payement_way: order.payement_way,
            order_time: ordertime
        }
    }

    async checkPaymentWay(usedWalletDto: CreateOrderDto) {
        if (usedWalletDto.payement_way == "Cash") {
            return this.useCash(usedWalletDto)
        } else if (usedWalletDto.payement_way == "Wallet") {
            return this.useWallet(usedWalletDto)
        }
    }

    async useWallet(usedWalletDto: CreateOrderDto) {
        let id = uuidv4()
        let amountwallet = {
            wallet_user_account_reference: usedWalletDto.user_account,
            process_wallet_amount: usedWalletDto.amount
        }
        const wallet_update = await this.walletService.minusAmountWallet(amountwallet)
        const wallet_process = await this.walletService.createMinusProcess(usedWalletDto.user_account, id, usedWalletDto.payement_way, usedWalletDto.wallet_currency, usedWalletDto.amount, "Success", "Pay For Order")
        const create_order = await this.createOrder(usedWalletDto.user_name, usedWalletDto.user_phone, usedWalletDto.user_account, usedWalletDto.user_address, usedWalletDto.menu, usedWalletDto.total_price, usedWalletDto.payement_way)
        return create_order
    }

    async useCash(usedWalletDto: CreateOrderDto) {
        const create_order = await this.createOrder(usedWalletDto.user_name, usedWalletDto.user_phone, usedWalletDto.user_account, usedWalletDto.user_address, usedWalletDto.menu, usedWalletDto.total_price, usedWalletDto.payement_way)
        return create_order
    }
}
