import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from 'mongoose';

export type OrderDocument = Order & Document;

@Schema()
export class Order {
    @Prop({unique:true})
    orderId: string;

    @Prop()
    user_name: string;

    @Prop()
    user_phone: string;

    @Prop()
    user_account: string;

    @Prop()
    user_address: string;

    @Prop()
    menu: {menu_name:string,menu_qty:number,menu_price:number}[];

    @Prop()
    total_price: string;

    @Prop()
    payement_way: string;

    @Prop()
    order_time: number;
}

export const OrderSchema = SchemaFactory.createForClass(Order);