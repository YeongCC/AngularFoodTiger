export class CreateFormDto {
    amount: string;
    currency: string;
    collection_id: string;
    customer_name: string;
    email: string;
    contact_number: string;
    address: string;
    postcode: string;
    city: string;
    state: string;
    country: string;
    shipping_name: string;
    shipping_email: string;
    shipping_contact_number: string;
    shipping_address: string;
    shipping_postcode: string;
    shipping_city: string;
    shipping_state: string;
    shipping_country: string;
    description: string;
}