import { Body, Controller, Get, Post, Redirect, Res, UnauthorizedException } from '@nestjs/common';
import { CreateFormDto } from './dto/payex.dto';
import { PayexService } from './payex.service';
import { Response, Request, request } from 'express';
@Controller('payex')
export class PayexController {

    constructor(
        private readonly payexService: PayexService,
    ) { }

    @Post('accept')
    @Redirect('http://localhost:4200/wallet/result')
    async test(@Body() response: any) {
        return this.payexService.completePay(response)
    }

    @Post('fail')
    @Redirect('http://localhost:4200/wallet/result')
    async test2(@Body() response: Response) {
        return this.payexService.completePay(response)
    }

    @Post('test')
    async test3(@Body() response: any) {
        return response
    }

}
