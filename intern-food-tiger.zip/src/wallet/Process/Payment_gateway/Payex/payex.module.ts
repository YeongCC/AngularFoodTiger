import { HttpModule } from '@nestjs/axios';
import { Module } from '@nestjs/common';
import { WalletModule } from 'src/wallet/Wallet/wallet.module';
import { PaymentProcessModule } from '../../Payment_process/payment-process.module';
import { PaymentResultModule } from '../../Payment_result/payment-result.module';
import { PayexController } from './payex.controller';
import { PayexService } from './payex.service';

@Module({
  imports: [
    HttpModule,
    PaymentProcessModule,
    PaymentResultModule,
    WalletModule
  ],
  controllers: [PayexController],
  providers: [PayexService],
})
export class PayexModule { }
