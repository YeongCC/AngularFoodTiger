import { BadRequestException, Injectable } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { catchError, firstValueFrom, map, of, timeout } from 'rxjs';
import { v4 as uuidv4 } from 'uuid';
import { PaymentProcessService } from '../../Payment_process/payment-process.service';
import { PaymentResultService } from '../../Payment_result/payment-result.service';
import { WalletService } from 'src/wallet/Wallet/wallet.service';
import { pathOr } from 'ramda';


@Injectable()
export class PayexService {
  public token: string | undefined
  constructor(
    private readonly http: HttpService,
    private readonly paymentProcessService: PaymentProcessService,
    private readonly paymentResultService: PaymentResultService,
    private readonly walletService: WalletService
  ) { }

  async GetForm(data: any, payment_gateway: any, userAcc: any) {
    let token;
    const myJSON = await this.GetToken().then(function (result) {
      token = result
    });
    let order_id = uuidv4();
    let form_data = [{
      amount: data.amount,
      currency: data.currency,
      collection_id: uuidv4(),
      capture: true,
      customer_name: data.customer_name,
      email: data.email,
      contact_number: data.contact_number,
      address: data.address,
      postcode: data.postcode,
      city: data.city,
      state: data.state,
      country: data.country,
      shipping_name: data.shipping_name,
      shipping_email: data.shipping_email,
      shipping_contact_number: data.shipping_contact_number,
      shipping_address: data.shipping_address,
      shipping_postcode: data.shipping_postcode,
      shipping_city: data.shipping_city,
      shipping_state: data.shipping_state,
      shipping_country: data.shipping_country,
      description: data.description,
      reference_number: order_id,
      items: [
        {
          product_id: 1,
          product_name: "test product",
          price: 10,
          weight: 5
        }
      ],
      metadata: {
        id: 1,
        color: "blue"
      },
      payment_type: "card",
      payment_types: [
        "card"
      ],
      show_payment_types: false,
      tokenize: false,
      card_on_file: "string",
      return_url: "http://localhost:3000/payex/accept",
      callback_url: "http://localhost:3000/payex/accept",
      accept_url: "http://localhost:3000/payex/accept",
      reject_url: "http://localhost:3000/payex/fail",
      nonce: "string",
      source: "string",
      expiry_date: "2021-11-30",
      splits: [
        {
          amount: 1000,
          split_type: "abs",
          destination: "contact@payex.io",
          type: "platform",
          description: "Platform commission fees"
        }
      ]
    }]
    const result = await firstValueFrom(this.http.post('https://sandbox-payexapi.azurewebsites.net/api/v1/PaymentIntents', form_data, {
      headers: {
        "Authorization": 'Bearer ' + token,
      }
    }).pipe(
      timeout(5000),
      map((res) => res.data.result.shift()),
      catchError(error => of({ success: false, error: error }))
    ));
    const success = pathOr(true, ['success'], result) as boolean;

    if (success === true) {
      const jsondata = JSON.stringify(form_data);
      const process_data = await this.paymentProcessService.createRechargeProcess(order_id, userAcc, payment_gateway, jsondata)
    }

    return result
  }

  async GetToken() {
    const result = await firstValueFrom(this.http.post('https://sandbox-payexapi.azurewebsites.net/api/Auth/Token', { timeout: 5000 }, {
      headers: {
        'accept': 'application/json',
        "Authorization": "Basic " + process.env.PAYEX_AUTH,
      }
    }).pipe(map((res) =>
      res.data.token
    ), catchError(error => of({ success: false, error: error.toJSON() }))))

    return result
  }

  async completePay(response: any) {
    if (response.response == 'Approved') {
      return this.succesPay(response)
    } else {
      return this.failPay(response)
    }
  }

  async succesPay(data: any) {
    const jsondata = JSON.stringify(data);
    const checkid = await this.checkValid(data.reference_number)
    if (!checkid) {
      throw new BadRequestException('Invalid !');
    }
    this.paymentResultService.createRechargeResult(data.reference_number, jsondata, data.customer_name, "Payex", data.response)
    this.walletService.createAddProcess(data.customer_name, data.reference_number, "Payex", data.currency, data.amount, "Success", "Recharge to Wallet")
    let amountwallet = {
      wallet_user_account_reference: data.customer_name,
      process_wallet_amount: data.amount
    }
    this.walletService.addAmountWallet(amountwallet)
    return data
  }

  async failPay(data: any) {
    const jsondata = JSON.stringify(data);
    this.paymentResultService.createRechargeResult(data.reference_number, jsondata, data.customer_name, "Payex", data.response)
    this.walletService.createAddProcess(data.customer_name, data.reference_number, "Payex", data.currency, data.amount, "Failed", "Recharge to Wallet")
    return data
  }

  async checkValid(data: any) {
    return this.paymentProcessService.checkValid(data)
  }
}


