export class PaymentGatewayDto {
    user_account:string;
    payment_gateway:string;
    data:[]
}