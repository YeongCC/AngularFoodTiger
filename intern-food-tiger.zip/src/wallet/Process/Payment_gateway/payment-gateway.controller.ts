import { Body, Controller, Post } from '@nestjs/common';
import { PaymentGatewayDto } from './dto/payment-gateway.dto';
import { PaymentGatewayService } from './payment-gateway.service';

@Controller('payment-gateway')
export class PaymentGatewayController {

    constructor(
        private readonly paymentGatewayService: PaymentGatewayService
    ) { }

    @Post('check')
    async checkPaymentType(@Body() data:PaymentGatewayDto ) {
        return this.paymentGatewayService.checkPaymentWay(data)
    }
}
