import { HttpModule } from '@nestjs/axios';
import { Module } from '@nestjs/common';
import { WalletModule } from 'src/wallet/Wallet/wallet.module';
import { PaymentProcessModule } from '../Payment_process/payment-process.module';
import { PaymentResultModule } from '../Payment_result/payment-result.module';
import { PayexModule } from './Payex/payex.module';
import { PayexService } from './Payex/payex.service';
import { PaymentGatewayController } from './payment-gateway.controller';
import { PaymentGatewayService } from './payment-gateway.service';

@Module({
  imports: [
    HttpModule,
    PaymentProcessModule,
    PaymentResultModule,
    WalletModule,
    PayexModule,
  ],
  controllers: [PaymentGatewayController],
  providers: [PaymentGatewayService, PayexService]
})
export class PaymentGatewayModule { }
