import { Injectable } from '@nestjs/common';
import { PaymentGatewayDto } from './dto/payment-gateway.dto';
import { PayexService } from './Payex/payex.service';

@Injectable()
export class PaymentGatewayService {

    constructor(
        private readonly payexService: PayexService,
    ) { }

    async checkPaymentWay(data: PaymentGatewayDto) {
        if (data.payment_gateway == "Payex") {
            return this.payexService.GetForm(data.data, data.payment_gateway, data.user_account)
        } else {
            return "no"
        }
    }


}
