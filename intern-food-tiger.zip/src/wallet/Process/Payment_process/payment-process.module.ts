import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { PaymentProcessRepository } from './payment-process.respository';
import { PaymentProcessService } from './payment-process.service';
import { Payement_Process, Payement_Process_Schema } from './schema/payment_process.schema';

@Module({
    imports: [
        MongooseModule.forFeature([{ name: Payement_Process.name, schema: Payement_Process_Schema }])
    ],
    providers: [PaymentProcessService,PaymentProcessRepository],
    exports: [PaymentProcessService,PaymentProcessRepository],
})
export class PaymentProcessModule {}
