import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { FilterQuery, Model } from 'mongoose';
import { Payement_Process } from './schema/payment_process.schema';

@Injectable()
export class PaymentProcessRepository {
    constructor(@InjectModel(Payement_Process.name) private payement_processModel: Model<Payement_Process>) {}

    async find(payement_processesFilterQuery: FilterQuery<Payement_Process>): Promise<Payement_Process[]> {
        return this.payement_processModel.find(payement_processesFilterQuery)
    }

    async findOne(payement_processFilterQuery: FilterQuery<Payement_Process>){
        return this.payement_processModel.findOne(payement_processFilterQuery);
    }

    async create(payement_process: Payement_Process): Promise<Payement_Process> {
        const newPayement_Process = new this.payement_processModel(payement_process);
        return newPayement_Process.save()
    }

    async remove(payement_process: string): Promise<any> {
        const Payement_Process = await this.payement_processModel.findByIdAndRemove(payement_process);
        return Payement_Process;
    }


}
