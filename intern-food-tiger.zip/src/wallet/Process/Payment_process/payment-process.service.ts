import { Injectable } from '@nestjs/common';
import { PaymentProcessRepository } from './payment-process.respository';
import { DateTime } from 'luxon';

@Injectable()
export class PaymentProcessService {
    proccess_id: any[] = [];
    constructor(private readonly paymentProcessRepository: PaymentProcessRepository) { }

    async createRechargeProcess(
        Payement_Process_Id: string,
        Payement_Process_reference_user_account: string,
        Payement_Process_gateway: string,
        Payement_Process_data: string
    ) {
        const payement_process = await this.paymentProcessRepository.create({
            Payement_Process_Id,
            Payement_Process_reference_user_account,
            Payement_Process_gateway,
            Payement_Process_data,
            Payement_Process_created_time:DateTime.now(),
        })
    }

    async checkValid(Payement_Process_Id:any){
        return this.paymentProcessRepository.findOne({ Payement_Process_Id })
    }

    async getPaymentProcessHistory(user_account: any) {
        const payment_process = await this.paymentProcessRepository.find({ user_account })

        for (let i = 0; i < payment_process.length; i++) {
            this.proccess_id.push(payment_process[i].Payement_Process_Id);
            // console.log(payment_process[i].Payement_Process_Id)
        }
        
        return this.proccess_id
    }
}
