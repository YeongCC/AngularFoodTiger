import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from 'mongoose';

export type Payement_Process_Document = Payement_Process & Document;

@Schema()
export class Payement_Process {
    @Prop({unique:true})
    Payement_Process_Id: string;

    @Prop()
    Payement_Process_reference_user_account: string;

    @Prop()
    Payement_Process_gateway: string;
    
    @Prop()
    Payement_Process_data: string;
    
    @Prop()
    Payement_Process_created_time:number;
}

export const Payement_Process_Schema = SchemaFactory.createForClass(Payement_Process);