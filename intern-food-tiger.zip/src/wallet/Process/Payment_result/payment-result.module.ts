import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { PaymentResultRepository } from './payment-result.respository';
import { PaymentResultService } from './payment-result.service';
import { Payement_Result, Payement_Result_Schema } from './schema/payment_result.schema';

@Module({
    imports: [
        MongooseModule.forFeature([{ name: Payement_Result.name, schema: Payement_Result_Schema }])
    ],
    providers: [PaymentResultService,PaymentResultRepository],
    exports: [PaymentResultService,PaymentResultRepository]
})
export class PaymentResultModule {}
