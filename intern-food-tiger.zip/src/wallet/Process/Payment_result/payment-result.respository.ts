import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { FilterQuery, Model } from 'mongoose';
import { Payement_Result } from './schema/payment_result.schema';

@Injectable()
export class PaymentResultRepository {
    constructor(@InjectModel(Payement_Result.name) private payement_resultModel: Model<Payement_Result>) {}

    async find(payement_resultsFilterQuery: FilterQuery<Payement_Result>): Promise<Payement_Result[]> {
        return this.payement_resultModel.find(payement_resultsFilterQuery)
    }

    async findOne(payement_resultFilterQuery: FilterQuery<Payement_Result>){
        return this.payement_resultModel.findOne(payement_resultFilterQuery);
    }

    async create(payement_result: Payement_Result): Promise<Payement_Result> {
        const newPayement_Process = new this.payement_resultModel(payement_result);
        return newPayement_Process.save()
    }

    async remove(payement_result: string): Promise<any> {
        const Payement_Result = await this.payement_resultModel.findByIdAndRemove(payement_result);
        return Payement_Result;
    }
}
