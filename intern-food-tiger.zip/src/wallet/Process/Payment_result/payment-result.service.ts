import { Injectable } from '@nestjs/common';
import { PaymentResultRepository } from './payment-result.respository';
import { DateTime } from 'luxon';

@Injectable()
export class PaymentResultService {
    result_id: any[] = [];
    constructor(private readonly paymentResultRepository: PaymentResultRepository) { }

    async createRechargeResult(
        Payement_Result_refrence_Process_Id: string,
        Payement_Result_data: string,
        Payement_Result_reference_user_account:string,
        Payement_Result_gateway:string,
        Payement_Result_response:string
    ) {
        const payement_process = await this.paymentResultRepository.create({
            Payement_Result_refrence_Process_Id,
            Payement_Result_reference_user_account,
            Payement_Result_gateway,
            Payement_Result_data,
            Payement_Result_response,
            Payement_Result_created_time:DateTime.now(),
        })
    }

    async getResultProcessHistory(user_account: any) {
        const result_process = await this.paymentResultRepository.find({ user_account })

        for (let i = 0; i < result_process.length; i++) {
            this.result_id.push(result_process[i].Payement_Result_refrence_Process_Id);
            // console.log(result_process[i].Payement_Result_refrence_Process_Id)
        }
        
        return this.result_id
    }
}
