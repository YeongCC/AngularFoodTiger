import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from 'mongoose';

export type Payement_Result_Document = Payement_Result & Document;

@Schema()
export class Payement_Result {
    @Prop({unique:true})
    Payement_Result_refrence_Process_Id: string;
    
    @Prop()
    Payement_Result_reference_user_account: string;

    @Prop()
    Payement_Result_gateway: string;

    @Prop()
    Payement_Result_data: string;

    @Prop()
    Payement_Result_response: string;
    
    @Prop()
    Payement_Result_created_time:number;
}

export const Payement_Result_Schema = SchemaFactory.createForClass(Payement_Result);