import { Module } from '@nestjs/common';
import { PaymentGatewayModule } from './Payment_gateway/payment-gateway.module';
import { PaymentProcessModule } from './Payment_process/payment-process.module';
import { PaymentResultModule } from './Payment_result/payment-result.module';

@Module({
    imports: [
        PaymentGatewayModule,
        PaymentProcessModule,
        PaymentResultModule,
      ],
    providers: [],
    controllers: []
})
export class ProcessModule {}
