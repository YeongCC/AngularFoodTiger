export class IndentityUserWalletDto {
    user_account: string;
    wallet_currency: string;
    idToken: string;
}

export class UpdatedWalletDto {
    wallet_user_account_reference: string;
    process_wallet_amount: string;
}
