import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from 'mongoose';

export type WalletProcessMenuDocument = WalletProcess & Document;

@Schema()
export class WalletProcess {
    @Prop({unique:true})
    process_wallet_id: string;

    @Prop()
    process_wallet_reference_user_account: string;

    @Prop()
    process_wallet_refrence_Process_Result_id: string;

    @Prop()
    reference_gateway: string;

    @Prop()
    process_wallet_currency: string;

    @Prop()
    process_wallet_action: string;

    @Prop()
    process_wallet_amount: string;

    @Prop()
    process_wallet_response: string;

    @Prop()
    process_wallet_statement: string;

    @Prop()
    process_wallet_created_time:number;
}

export const WalletProcessSchema = SchemaFactory.createForClass(WalletProcess);