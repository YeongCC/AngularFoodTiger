import { BadRequestException, Body, Controller, Get, Param, Post } from '@nestjs/common';
import { GoogleService } from 'src/Service/google.service';
import { IndentityUserWalletDto } from './dto/wallet.dto';
import { WalletService } from './wallet.service';

@Controller('wallet')
export class WalletController {
    constructor(
        private readonly walletService: WalletService, 
        private readonly googleService:GoogleService
        ) {}
    
    @Post('new')
    async createUser(@Body() indentityUserWalletDto: IndentityUserWalletDto){
        const verify =await this.googleService.verifyUserWallet(indentityUserWalletDto.idToken)
        if(verify!= indentityUserWalletDto.user_account){
            throw new BadRequestException("Cannot Authorized");
        }
        const wallet = await this.walletService.createWallet(
            indentityUserWalletDto.user_account,
            indentityUserWalletDto.wallet_currency);
        return wallet   
    }


    @Get('detail/:user_account/:idToken')
    async getUser(@Param('idToken') idToken: string,@Param('user_account') wallet_user_account_reference: string){
        const verify =await this.googleService.verifyUserWallet(idToken)
        if(verify!=wallet_user_account_reference){
            throw new BadRequestException("Cannot Authorized");
        }
        const user = await this.walletService.getUserWallet(wallet_user_account_reference)
        return user 
    }
    
    @Get('result/:user_account')
    async getPaymentResultReceipt(@Param('user_account') user_account: string){
        const result = await this.walletService.getOnePaymentResultProccess(user_account)
        return result 
    }

    @Get('update/:user_account')
    async getUpdateWallet(@Param('user_account') wallet_user_account_reference: string){
        const wallet = await this.walletService.getUserWallet(wallet_user_account_reference)
        return wallet 
    }

    @Get('user/history/:user_account')
    async getHistoryWallet(@Param('user_account') wallet_user_account_reference: string){
        const history = await this.walletService.getHistory(wallet_user_account_reference)
        return history
    }

    @Get('user/onehistory/:user_account/:process_wallet_id')
    async getOneHistoryWallet(@Param('user_account') wallet_user_account_reference: string,@Param('process_wallet_id') process_wallet_id: string){
        const history = await this.walletService.getOneHistory(wallet_user_account_reference,process_wallet_id)
        return history.shift()
    }

}
