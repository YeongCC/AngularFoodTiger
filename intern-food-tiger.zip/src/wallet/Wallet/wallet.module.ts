import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { OrderModule } from 'src/order/order.module';
import { GoogleService } from 'src/Service/google.service';
import { Wallet, WalletSchema, } from './schema/wallet.schema';
import { WalletProcess, WalletProcessSchema } from './schema/wallet_process.schema';
import { WalletController } from './wallet.controller';
import { WalletsRepository } from './wallet.respository';
import { WalletService } from './wallet.service';

@Module({
    imports: [
        MongooseModule.forFeature([{ name: Wallet.name, schema: WalletSchema }]),
        MongooseModule.forFeature([{ name: WalletProcess.name, schema: WalletProcessSchema }]),
    ],
    controllers: [WalletController],
    providers: [WalletService, WalletsRepository,GoogleService],
    exports: [WalletService,WalletsRepository]
})
export class WalletModule {}
