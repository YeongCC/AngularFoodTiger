import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { FilterQuery, Model } from "mongoose";
import { Wallet } from "./schema/wallet.schema";
import { WalletProcess } from "./schema/wallet_process.schema";

@Injectable()
export class WalletsRepository {
    constructor(
        @InjectModel(Wallet.name) private walletModel: Model<Wallet>,
        @InjectModel(WalletProcess.name) private walletProcessModel: Model<WalletProcess>
        ) {}

    async findOne(walletFilterQuery: FilterQuery<Wallet>){
        return this.walletModel.findOne(walletFilterQuery);
    }

    async create(wallet: Wallet): Promise<Wallet> {
        const newWallet = new this.walletModel(wallet);
        return newWallet.save()
    }

    async findOneAndUpdate(walletFilterQuery: FilterQuery<Wallet>, wallet: Partial<Wallet>){
        return this.walletModel.findOneAndUpdate(walletFilterQuery, wallet, { new: true });
    }

    async createProcesses(process: WalletProcess): Promise<WalletProcess> {
        const newProcess = new this.walletProcessModel(process);
        return newProcess.save()
    }


    async findPaymentResultProccess(walletFilterQuery: FilterQuery<WalletProcess>){
        return this.walletProcessModel.find(walletFilterQuery).limit(1).sort({$natural:-1});
    }

    async findhistory(walletFilterQuery: FilterQuery<WalletProcess>){
        return this.walletProcessModel.find(walletFilterQuery);
    }

    async findOneHistory(walletFilterQuery: FilterQuery<WalletProcess>){
        return this.walletProcessModel.find(walletFilterQuery);
    }

}