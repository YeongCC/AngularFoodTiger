import { BadRequestException, Injectable } from '@nestjs/common';
import { WalletsRepository } from './wallet.respository';
import { v4 as uuidv4 } from 'uuid';
import { DateTime } from 'luxon';
import { UpdatedWalletDto } from './dto/wallet.dto';

@Injectable()
export class WalletService {
    proccess_id: any[] = [];
    constructor(
        private readonly walletsRepository: WalletsRepository,
    ) { }

    async createWallet(
        wallet_user_account_reference: string,
        wallet_currency: string) {
        const wallet = await this.walletsRepository.create({
            wallet_id: uuidv4(),
            wallet_user_account_reference,
            wallet_balance: '0.00',
            wallet_currency,
        })
        return {
            wallet: {
                wallet_currency: wallet.wallet_currency,
                wallet_balance: wallet.wallet_balance,
                wallet_user_account_reference: wallet.wallet_user_account_reference,
            }
        };
    }

    async getUserWallet(wallet_user_account_reference: any) {
        const wallet = await this.walletsRepository.findOne({ wallet_user_account_reference })
        if (wallet) {
            return {
                wallet: {
                    wallet_currency: wallet.wallet_currency,
                    wallet_balance: wallet.wallet_balance,
                    wallet_user_account_reference: wallet.wallet_user_account_reference,
                }
            };
        }
    }

    async getWalletAmount(wallet_user_account_reference: any) {
        const wallet = await this.walletsRepository.findOne({ wallet_user_account_reference })
        return wallet.wallet_balance
    }

    async addAmountWallet(walletUpdates: UpdatedWalletDto) {
        const getamount = await this.getWalletAmount(walletUpdates.wallet_user_account_reference)
        const ownamount = await parseFloat(getamount)
        const addamount = await parseFloat(walletUpdates.process_wallet_amount)
        const newamount = await ownamount + addamount
        const newAmount = {
            wallet_balance: String(newamount)
        }

        const wallet = await this.walletsRepository.findOneAndUpdate({ wallet_user_account_reference: walletUpdates.wallet_user_account_reference }, newAmount);
        return {
            wallet: {
                wallet_currency: wallet.wallet_currency,
                wallet_balance: wallet.wallet_balance,
                wallet_user_account_reference: wallet.wallet_user_account_reference,
            }
        };
    }

    async minusAmountWallet(walletUpdates: UpdatedWalletDto) {
        const getamount = await this.getWalletAmount(walletUpdates.wallet_user_account_reference)
        const ownamount = await parseFloat(getamount)
        const addamount = await parseFloat(walletUpdates.process_wallet_amount)
        if(ownamount<addamount){
            throw new BadRequestException('No Enough Money, Please Recharge !')
        }
        const newamount = await ownamount - addamount
        const newAmount = {
            wallet_balance: String(newamount)
        }

        const wallet = await this.walletsRepository.findOneAndUpdate({ wallet_user_account_reference: walletUpdates.wallet_user_account_reference }, newAmount);
        return {
            wallet: {
                wallet_currency: wallet.wallet_currency,
                wallet_balance: wallet.wallet_balance,
                wallet_user_account_reference: wallet.wallet_user_account_reference,
            }
        };
    }

    async createAddProcess(
        process_wallet_reference_user_account: string,
        process_wallet_refrence_Process_Result_id: string,
        reference_gateway: string,
        process_wallet_currency: string,
        process_wallet_amount: string,
        process_wallet_response: string,
        process_wallet_statement: string) {
        const process = await this.walletsRepository.createProcesses({
            process_wallet_id: uuidv4(),
            process_wallet_reference_user_account,
            process_wallet_refrence_Process_Result_id,
            reference_gateway,
            process_wallet_currency,
            process_wallet_action: "+",
            process_wallet_amount,
            process_wallet_response,
            process_wallet_statement,
            process_wallet_created_time: DateTime.now()
        })
    }

    async createMinusProcess(
        process_wallet_reference_user_account: string,
        process_wallet_refrence_Process_Result_id: string,
        reference_gateway: string,
        process_wallet_currency: string,
        process_wallet_amount: string,
        process_wallet_response: string,
        process_wallet_statement: string) {
        const process = await this.walletsRepository.createProcesses({
            process_wallet_id: uuidv4(),
            process_wallet_reference_user_account,
            process_wallet_refrence_Process_Result_id,
            reference_gateway,
            process_wallet_currency,
            process_wallet_action: "-",
            process_wallet_amount,
            process_wallet_response,
            process_wallet_statement,
            process_wallet_created_time: DateTime.now()
        })
    }

    async getOnePaymentResultProccess(user_account: any) {
        return this.walletsRepository.findPaymentResultProccess({ user_account })
    }

    async getHistory(user_account: any) {
        const wallet_process = await this.walletsRepository.findhistory({ user_account })
        return wallet_process
    }

    async getOneHistory(user_account: any, process_wallet_id: any) {
        const wallet_process = await this.walletsRepository.findOneHistory({ user_account: user_account, process_wallet_id: process_wallet_id })
        return wallet_process
    }


}
