export interface noodleListData {
  noodlename: string;
}
