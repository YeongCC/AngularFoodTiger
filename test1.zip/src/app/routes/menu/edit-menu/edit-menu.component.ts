import { Location } from "@angular/common";
import { Component } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { DomSanitizer } from "@angular/platform-browser";
import { ActivatedRoute, Router } from "@angular/router";
import { XLSX_COLS } from "mat-table-exporter";
import { NzMessageService } from "ng-zorro-antd/message";
import { Food } from "src/app/model/food";

@Component({
  selector: "app-menu-edit-menu",
  templateUrl: "./edit-menu.component.html",
  styleUrls: ["./edit-menu.component.css"],
})
export class MenuEditMenuComponent {
  ngForm!: FormGroup;
  public fooddata = {
    food_name: "",
    food_big_price: "",
    food_normal_price: "",
    food_small_price: "",
    food_dry: "",
    food_wet: "",
    food_noodle: [],
    food_topping: [],
    food_image_input: "",
  };

  public noodledata: any = [];
  public noodledata1: any = [];
  public noodledata2: any = [];
  public toppingdata: any = [];
  public toppingdata1: any = [];
  public toppingdata2: any = [];
  public checkedIDsNoodle: any[] = [];
  public selectedItemsListNoodle: any[] = [];
  public checkedIDsTopping: any[] = [];
  public selectedItemsListTopping: any[] = [];
  public noodleid: any;
  public toppingid: any;
  public topping = false;
  public noodle = false;
  public foodnoodle: any;
  public foodnoodledetail: any = [];
  public finalfoodnoodledetail: any;
  public foodtopping: any;
  public foodtoppingdetail: any = [];
  public finalfoodtoppingname: any;
  constructor(
    private _location: Location,
    fb: FormBuilder,
    public msg: NzMessageService,
    private activeroute: ActivatedRoute,
    private food: Food,
    private router: Router,
    private sanitizer: DomSanitizer
  ) {
    this.getALLFooddata();
    this.getALLNoodledata();
    this.getALLToppingdata();
  }
  public fooddetail: any;
  public url: any;
  public file: File;
  public imageBuffer: any;
  public bufferValue: any;
  public confirmbufferValue: any;
  public confirmfiletype: any;

  onselectFile(event: any) {
    this.file = event.target.files[0];
    const allowedMimeTypes = ["image/png", "image/jpeg", "image/jpg"];
    if (this.file && allowedMimeTypes.includes(this.file.type)) {
      this.confirmfiletype = this.file.type;
      var reader = new FileReader();
      reader.readAsDataURL(this.file);
      reader.onload = () => {
        this.url = reader.result as string;
        this.imageBuffer = reader.result as string;
        this.bufferValue = Buffer.from(
          this.imageBuffer.split(",")[1],
          "base64"
        );
        this.confirmbufferValue = this.bufferValue;
      };
    } else {
      this.url = "./assets/tmp/img/unknown.png";
      event.target.value = null;
      alert("格式错误!");
    }
  }

  update(): void {
    if (
      this.fooddata.food_big_price != "" &&
      this.fooddata.food_small_price != "" &&
      this.fooddata.food_normal_price == ""
    ) {
      if (this.fooddata.food_small_price >= this.fooddata.food_big_price) {
        alert("价格（大、小）有问题，请检查");
      } else {
        this.fooddata.food_big_price = parseFloat(
          this.fooddata.food_big_price
        ).toFixed(2);
        this.fooddata.food_small_price = parseFloat(
          this.fooddata.food_small_price
        ).toFixed(2);
        this.processdata();
      }
    } else if (
      this.fooddata.food_normal_price != "" &&
      this.fooddata.food_big_price == "" &&
      this.fooddata.food_small_price == ""
    ) {
      this.fooddata.food_normal_price = parseFloat(
        this.fooddata.food_normal_price
      ).toFixed(2);
      this.processdata();
    } else {
      alert("填写错误，请查看价钱框 !");
    }
  }

  async processdata() {
    let datanoodle;
    let datatopping;
    this.changeSelectionNoodle().then((res) => {
      datanoodle = res;
      this.changeSelectionTopping().then((res) => {
        datatopping = res;
        this.food.updateFood(this.activeroute.snapshot.params["id"],this.fooddata,this.confirmbufferValue,this.confirmfiletype,datanoodle,datatopping)
        alert("更新成功 !");
        this.router.navigateByUrl("/Function/Menu/MenuDetail");
      });
    });
  }

  cancel(): void {
    this._location.back();
  }

  getALLNoodledata() {
    this.food.getAllNoodle().then(async (rows: any) => {
      let i;
      if (rows.length == 0) {
        this.noodle = await true;
      } else {
        this.noodle = await false;
      }
      this.noodledata = await rows;
      this.noodledata2 = await rows;
      for (i = 0; i < rows.length; i++) {
        this.noodledata1.push({
          id: this.noodledata[i].id,
          noodlename: this.noodledata[i].noodlename,
          checked: false,
        });
      }
      this.food
        .getAllOneFoodNoodleDetail(this.activeroute.snapshot.params["id"])
        .then(async (rowsone: any) => {
          this.foodnoodle = rowsone;
          for (i = 0; i < rowsone.length; i++) {
            this.food
              .getAllFoodNoodleDetail(this.foodnoodle[i].foodnoodleid)
              .then(async (rowstwo: any) => {
                this.foodnoodledetail = rowstwo;
                for (i = 0; i < rowstwo.length; i++) {
                  this.noodledata1
                    .filter(
                      (x: { id: number }) =>
                        x.id == Number(this.foodnoodledetail[i].id)
                    )
                    .map((x: { checked: boolean }) => (x.checked = true));
                }
              });
          }
        });
    });
  }

  getALLToppingdata() {
    this.food.getAllTopping().then(async (rows: any) => {
      let i;
      if (rows.length == 0) {
        this.topping = await true;
      } else {
        this.topping = await false;
      }
      this.toppingdata = await rows;
      this.toppingdata2 = await rows;
      for (i = 0; i < rows.length; i++) {
        this.toppingdata1.push({
          id: this.toppingdata[i].id,
          toppingname: this.toppingdata[i].toppingname,
          checked: false,
        });
      }
      this.food
        .getAllOneFoodToppingDetail(this.activeroute.snapshot.params["id"])
        .then((rowsone: any) => {
          this.foodtopping = rowsone;
          for (i = 0; i < rowsone.length; i++) {
            this.food
              .getAllFoodToppingDetail(this.foodtopping[i].foodtoppingid)
              .then((rowstwo: any) => {
                this.foodtoppingdetail = rowstwo;
                for (i = 0; i < rowstwo.length; i++) {
                  this.toppingdata1
                    .filter(
                      (x: { id: number }) =>
                        x.id == Number(this.foodtoppingdetail[i].id)
                    )
                    .map((x: { checked: boolean }) => (x.checked = true));
                }
              });
          }
        });
    });
  }

  async changeSelectionNoodle() {
    this.checkedIDsNoodle = [];
    let i;
    this.selectedItemsListNoodle = await this.noodledata1.filter((value) => {
      return value.checked;
    });

    for (i = 0; i < this.selectedItemsListNoodle.length; i++) {
      await this.checkedIDsNoodle.push(this.selectedItemsListNoodle[i].id);
    }
    const matches = await this.noodledata2.filter((object) =>
      this.checkedIDsNoodle.includes(object.id)
    );
    return matches;
  }

  async changeSelectionTopping() {
    this.checkedIDsTopping = [];
    let i;
    this.selectedItemsListTopping = await this.toppingdata1.filter((value) => {
      return value.checked;
    });

    for (i = 0; i < this.selectedItemsListTopping.length; i++) {
      await this.checkedIDsTopping.push(this.selectedItemsListTopping[i].id);
    }
    const matches = await this.toppingdata2.filter((object) =>
      this.checkedIDsTopping.includes(object.id)
    );
    return matches;
  }

  getALLFooddata() {
    this.food
      .getAllOneFoodDetail(this.activeroute.snapshot.params["id"])
      .then(async (rows: any) => {
        this.fooddetail = rows;
        let i;
        for (i = 0; i < rows.length; i++) {
          this.fooddata.food_name = await this.fooddetail[i].foodname;
          this.fooddata.food_dry = await this.fooddetail[i].dry;
          this.fooddata.food_wet = await this.fooddetail[i].wet;
          this.fooddata.food_big_price = await this.fooddetail[i].bigprice;
          this.fooddata.food_small_price = await this.fooddetail[i].smallprice;
          this.fooddata.food_normal_price = await this.fooddetail[i]
            .normalprice;
          this.confirmfiletype = await this.fooddetail[i].filetype;
          var u8 = new Uint8Array(Buffer.from(this.fooddetail[i].imagepath));
          const STRING_CHAR = u8.reduce((data, byte) => {
            return data + String.fromCharCode(byte);
          }, "");
          let base64String = btoa(STRING_CHAR);
          this.confirmbufferValue = this.fooddetail[i].imagepath;
          this.url = await this.sanitizer.bypassSecurityTrustUrl(
            "data:" + this.fooddetail[i].filetype + ";base64," + base64String
          );
        }
      });
  }
}
