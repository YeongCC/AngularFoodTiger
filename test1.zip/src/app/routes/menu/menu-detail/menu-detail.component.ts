import { Component, ViewChild, AfterViewInit } from "@angular/core";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { DomSanitizer } from "@angular/platform-browser";
import { Router } from "@angular/router";
import { _HttpClient } from "@delon/theme";
import { Food } from "src/app/model/food";

@Component({
  selector: "app-menu-menu-detail",
  templateUrl: "./menu-detail.component.html",
  styleUrls: ["./menu-detail.component.css"],
})
export class MenuMenuDetailComponent implements AfterViewInit {
  displayedColumns: string[] = [
    "number",
    // "imagepath",
    "foodname",
    "actions",
  ];
  dataSource= new MatTableDataSource<any>()

  @ViewChild(MatPaginator)
  paginator!: MatPaginator;
  @ViewChild(MatSort)
  sort!: MatSort;

  constructor(
    private router: Router, 
    private food: Food,
    // private sanitizer: DomSanitizer
    ) {}


  foodlist:any;
  foodimage:any;
  foodimagetype:any;
  fooddata:any;
  final:any = [];
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.getALLMenudata();
  }

  getALLMenudata() {
    this.food.getAllFood().then((rows) => {
      this.foodlist = rows
      // let i
      // let u8: any
      // let STRING_CHAR :any
      // let base64String:any
      // for (i = 0; i < rows.length; i++) {
      //   let test =this.foodlist[i].imagepath
      //    u8 = new Uint8Array(Buffer.from(test))
      //    STRING_CHAR = u8.reduce((data, byte)=> {
      //     return data + String.fromCharCode(byte)
      //     }, '')
      //    base64String = btoa(STRING_CHAR);
      //    this.foodimage = this.sanitizer.bypassSecurityTrustUrl('data:'+this.foodlist[i].filetype+';base64,' + base64String);
      //   this.fooddata = {
      //     id:this.foodlist[i].id,
      //     imagepath:this.foodimage,
      //     foodname:this.foodlist[i].foodname
      //   }
      //   this.final.push(this.fooddata)
      //   }
      // this.dataSource = new MatTableDataSource(this.final)
        this.dataSource = new MatTableDataSource(this.foodlist)
    });
  
  }

  add(): void {
    this.router.navigateByUrl("Function/Menu/insertMenu");
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  deleteMenu(id: string) {
    this.food.delete(id);
    alert("删除成功");
    this.final=[];
    this.getALLMenudata();
  }

  selectDetail(id: string) {
    this.router.navigateByUrl("Function/Menu/MenuOneDetail/"+id);
  }

}
