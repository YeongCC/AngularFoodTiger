import { Component, ViewChild, AfterViewInit } from "@angular/core";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { Router } from "@angular/router";
import { _HttpClient } from "@delon/theme";
import { toppingListData } from "src/app/apiservice/class/toppingclass";
import { Topping } from "src/app/model/topping";

@Component({
  selector: "app-topping-topping-detail",
  templateUrl: "./topping-detail.component.html",
  styleUrls: ["./topping-detail.component.css"],
})
export class ToppingToppingDetailComponent implements AfterViewInit {
  displayedColumns: string[] = ["number","toppingname", "actions"];
  dataSource = new MatTableDataSource<toppingListData>();

  @ViewChild(MatPaginator)
  paginator!: MatPaginator;
  @ViewChild(MatSort)
  sort!: MatSort;

  constructor(
    private router: Router,
    private topping: Topping
  ) {}

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.getALLToppingdata();
  }

  getALLToppingdata() {
    this.topping.getAll().then((rows) => {
      this.dataSource.data = rows as toppingListData[]
    });
  }

  add(): void {
    this.router.navigateByUrl("Function/Topping/insertTopping");
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  deleteTopping(id: string) {
    this.topping.delete(id);
    this.getALLToppingdata();
    alert("删除成功");
  }
}
