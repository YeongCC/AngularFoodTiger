BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "orderhistory" (
	"id"	INTEGER,
	"takeawayid"	TEXT,
	"eathereid"	TEXT,
	"fooddetail"	TEXT NOT NULL,
	"price"	TEXT NOT NULL,
	"date"	INTEGER NOT NULL,
	PRIMARY KEY("id" AUTOINCREMENT)
);
CREATE TABLE IF NOT EXISTS "foodtopping" (
	"foodid"	TEXT NOT NULL,
	"foodtoppingid"	TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS "foodnoodle" (
	"foodid"	TEXT NOT NULL,
	"foodnoodleid"	TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS "topping" (
	"id"	INTEGER,
	"toppingname"	TEXT NOT NULL,
	PRIMARY KEY("id" AUTOINCREMENT)
);
CREATE TABLE IF NOT EXISTS "noodle" (
	"id"	INTEGER,
	"noodlename"	TEXT NOT NULL,
	PRIMARY KEY("id" AUTOINCREMENT)
);
CREATE TABLE IF NOT EXISTS "food" (
	"id"	TEXT,
	"foodname"	TEXT NOT NULL UNIQUE,
	"dry"	INTEGER,
	"wet"	INTEGER,
	"bigprice"	TEXT,
	"smallprice"	TEXT,
	"normalprice"	TEXT,
	"imagepath"	BLOB,
	"filetype"	TEXT
);
COMMIT;
